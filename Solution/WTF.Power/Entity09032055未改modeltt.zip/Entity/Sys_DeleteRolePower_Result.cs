﻿namespace WTF.Power.Entity
{
    using System;
    using System.Data.Objects.DataClasses;
    using System.Runtime.Serialization;

    [Serializable, EdmComplexType(NamespaceName="UserModel", Name="Sys_DeleteRolePower_Result"), DataContract(IsReference=true)]
    public class Sys_DeleteRolePower_Result : ComplexObject
    {
    }
}


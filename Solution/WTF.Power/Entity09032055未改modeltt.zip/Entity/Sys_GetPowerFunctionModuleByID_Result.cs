﻿namespace WTF.Power.Entity
{
    using System;
    using System.Data.Objects.DataClasses;
    using System.Runtime.Serialization;

    [Serializable, EdmComplexType(NamespaceName="ModuleModel", Name="Sys_GetPowerFunctionModuleByID_Result"), DataContract(IsReference=true)]
    public class Sys_GetPowerFunctionModuleByID_Result : ComplexObject
    {
    }
}


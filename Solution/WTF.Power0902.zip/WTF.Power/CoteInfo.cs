﻿// Decompiled with JetBrains decompiler
// Type: WTF.Power.CoteInfo
// Assembly: WTF.Power, Version=1.0.5451.23978, Culture=neutral, PublicKeyToken=null
// MVID: ACB99369-F466-4579-86CC-C2D259CAF828
// Assembly location: C:\F盘\天棣互联\Gao7CMS\SevenFramework\SevenDLL\WTF.Power.dll

namespace WTF.Power
{
  public class CoteInfo
  {
    public string Name { get; set; }

    public string ID { get; set; }

    public string ParentID { get; set; }

    public CoteInfo()
    {
      this.Name = "";
      this.ID = "";
      this.ParentID = "";
    }
  }
}

﻿// Decompiled with JetBrains decompiler
// Type: WTF.Power.CoteInfoComparer
// Assembly: WTF.Power, Version=1.0.5451.23978, Culture=neutral, PublicKeyToken=null
// MVID: ACB99369-F466-4579-86CC-C2D259CAF828
// Assembly location: C:\F盘\天棣互联\Gao7CMS\SevenFramework\SevenDLL\WTF.Power.dll

using System.Collections.Generic;

namespace WTF.Power
{
  public class CoteInfoComparer : IEqualityComparer<CoteInfo>
  {
    public bool Equals(CoteInfo x, CoteInfo y)
    {
      return x.ID == y.ID;
    }

    public int GetHashCode(CoteInfo obj)
    {
      if (obj == null)
        return 0;
      return obj.ToString().GetHashCode();
    }
  }
}

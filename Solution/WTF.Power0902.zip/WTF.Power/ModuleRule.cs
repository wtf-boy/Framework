﻿// Decompiled with JetBrains decompiler
// Type: WTF.Power.ModuleRule
// Assembly: WTF.Power, Version=1.0.5451.23978, Culture=neutral, PublicKeyToken=null
// MVID: ACB99369-F466-4579-86CC-C2D259CAF828
// Assembly location: C:\F盘\天棣互联\Gao7CMS\SevenFramework\SevenDLL\WTF.Power.dll

using WTF.Framework;
using WTF.Logging;
using WTF.Power.Entity;
using System;
using System.Collections.Generic;
using System.Data.Objects;
using System.Linq;
using System.Linq.Expressions;
using System.Xml;

namespace WTF.Power
{
  public class ModuleRule
  {
    private ModuleEntities objCurrentEntities;

    public ObjectQuery<WTF.Power.Entity.sys_modulecote> Sys_ModuleCote
    {
      get
      {
        return (ObjectQuery<WTF.Power.Entity.sys_modulecote>) this.CurrentEntities.sys_modulecote;
      }
    }

    public ModuleEntities CurrentEntities
    {
      get
      {
        if (this.objCurrentEntities == null)
          this.objCurrentEntities = new ModuleEntities(EntitiesHelper.GetConnectionString<ModuleEntities>("WTF.Power.ConnectionString"));
        return this.objCurrentEntities;
      }
    }

    public ObjectQuery<WTF.Power.Entity.sys_module> Sys_Module
    {
      get
      {
        return (ObjectQuery<WTF.Power.Entity.sys_module>) this.CurrentEntities.sys_module;
      }
    }

    public ObjectQuery<WTF.Power.Entity.sys_modulecheckdata> Sys_ModuleCheckData
    {
      get
      {
        return (ObjectQuery<WTF.Power.Entity.sys_modulecheckdata>) this.CurrentEntities.sys_modulecheckdata;
      }
    }

    public ObjectQuery<WTF.Power.Entity.sys_moduletype> Sys_ModuleType
    {
      get
      {
        return (ObjectQuery<WTF.Power.Entity.sys_moduletype>) this.CurrentEntities.sys_moduletype;
      }
    }

    public ObjectQuery<WTF.Power.Entity.sys_moduledata> Sys_ModuleData
    {
      get
      {
        return (ObjectQuery<WTF.Power.Entity.sys_moduledata>) this.CurrentEntities.sys_moduledata;
      }
    }

    public ObjectQuery<WTF.Power.Entity.sys_modulehelp> Sys_ModuleHelp
    {
      get
      {
        return (ObjectQuery<WTF.Power.Entity.sys_modulehelp>) this.CurrentEntities.sys_modulehelp;
      }
    }

    public void InsertModuleCote(WTF.Power.Entity.sys_modulecote objSys_ModuleCote)
    {
      objSys_ModuleCote.CoteTitle.CheckIsNull<string>("请输入栏目名称", "ModuleLog");
      this.CurrentEntities.sys_modulecote.Add(objSys_ModuleCote);
      this.CurrentEntities.SaveChanges();
    }

    public void UpdateModuleCote(WTF.Power.Entity.sys_modulecote objSys_ModuleCote)
    {
      objSys_ModuleCote.CoteTitle.CheckIsNull<string>("请输入栏目名称", "ModuleLog");
      this.CurrentEntities.SaveChanges();
    }

    public void DeleteModuleCoteByKey(string primaryKey)
    {
      this.CurrentEntities.sys_modulecote.DeleteDataPrimaryKey<WTF.Power.Entity.sys_modulecote>(primaryKey);
    }

    public void DeleteModuleCote(string condition)
    {
      this.CurrentEntities.sys_modulecote.DeleteData<WTF.Power.Entity.sys_modulecote>(condition, new ObjectParameter[0]);
    }

    public void InsertModule(WTF.Power.Entity.sys_module objModule)
    {
      SysAssert.CheckIsNull(objModule.ModuleCode, "请输入模块编码", LogModuleType.ModuleLog);
      if (this.CurrentEntities.sys_module.Any<WTF.Power.Entity.sys_module>((Expression<Func<WTF.Power.Entity.sys_module, bool>>) (p => p.ModuleID == objModule.ParentModuleID)))
      {
        WTF.Power.Entity.sys_module sysModule = this.Sys_Module.FirstOrDefault<WTF.Power.Entity.sys_module>((Expression<Func<WTF.Power.Entity.sys_module, bool>>) (p => p.ModuleID == objModule.ParentModuleID));
        sysModule.Sys_ModuleTypeReference.Load();
        objModule.SortIndex = this.Sys_Module.Where<WTF.Power.Entity.sys_module>((Expression<Func<WTF.Power.Entity.sys_module, bool>>) (p => p.ParentModuleID == objModule.ParentModuleID)).Count<WTF.Power.Entity.sys_module>() + 1;
        objModule.ModuleIDPath = sysModule.ModuleIDPath + "," + objModule.ModuleID.ToString();
        objModule.ModuleLevel = sysModule.ModuleLevel + 1;
        sysModule.sys_moduletype.Sys_Module.Add(objModule);
      }
      else
      {
        WTF.Power.Entity.sys_moduletype objModuleType = this.Sys_ModuleType.FirstOrDefault<WTF.Power.Entity.sys_moduletype>((Expression<Func<WTF.Power.Entity.sys_moduletype, bool>>) (p => p.ModuleTypeID == objModule.ParentModuleID));
        objModule.ModuleIDPath = objModule.ModuleID.ToString();
        objModule.SortIndex = this.Sys_Module.Where<WTF.Power.Entity.sys_module>((Expression<Func<WTF.Power.Entity.sys_module, bool>>) (p => p.ParentModuleID == objModuleType.ModuleTypeID)).Count<WTF.Power.Entity.sys_module>() + 1;
        objModule.ModuleLevel = 1;
        objModuleType.sys_module.Add(objModule);
      }
      this.CurrentEntities.SaveChanges();
    }

    public void UpdateModule(WTF.Power.Entity.sys_module objModule)
    {
      this.SaveChanges();
    }

    public void ModeuleQuickCopy(string quickModulename, string moduleCode, int logModuleID, string moduleID, List<string> quickModuleIDList)
    {
      List<WTF.Power.Entity.sys_module> list = this.CurrentEntities.sys_module.Where<WTF.Power.Entity.sys_module>((Expression<Func<WTF.Power.Entity.sys_module, bool>>) (s => quickModuleIDList.Contains(s.ModuleID))).ToList<WTF.Power.Entity.sys_module>();
      if (list.Count == 0)
        return;
      string moduleTypeID = list.First<WTF.Power.Entity.sys_module>().ModuleTypeID;
      List<string> objAddModuleIDList = list.Select<WTF.Power.Entity.sys_module, string>((Func<WTF.Power.Entity.sys_module, string>) (S => S.ModuleID)).ToList<string>();
      foreach (WTF.Power.Entity.sys_module sysModule in (IEnumerable<WTF.Power.Entity.sys_module>) list.Where<WTF.Power.Entity.sys_module>((Func<WTF.Power.Entity.sys_module, bool>) (S => S.ParentModuleID == moduleTypeID)).OrderBy<WTF.Power.Entity.sys_module, int>((Func<WTF.Power.Entity.sys_module, int>) (s => s.SortIndex)))
      {
        WTF.Power.Entity.sys_module objModule = new WTF.Power.Entity.sys_module();
        objModule.ModuleID = Guid.NewGuid().ToString();
        objModule.LogCategoryID = "新增".IndexOf(sysModule.ModuleName) < 0 ? sysModule.LogCategoryID : logModuleID;
        objModule.ModuleCode = "新增,修改".IndexOf(sysModule.ModuleName) < 0 ? sysModule.ModuleCode : (string.IsNullOrWhiteSpace(moduleCode) ? sysModule.ModuleCode : moduleCode);
        if ("新增,修改,删除".IndexOf(sysModule.ModuleName) >= 0)
        {
          objModule.ModuleName = sysModule.ModuleName + quickModulename;
          objModule.ToolTip = sysModule.ToolTip + quickModulename;
        }
        else
        {
          objModule.ModuleName = sysModule.ModuleName;
          objModule.ToolTip = sysModule.ToolTip;
        }
        objModule.ModuleShow = sysModule.ModuleShow;
        objModule.ModuleFunID = sysModule.ModuleFunID;
        objModule.OperateTypeID = sysModule.OperateTypeID;
        objModule.ParentModuleID = moduleID;
        objModule.IsDispose = sysModule.IsDispose;
        objModule.PlaceType = sysModule.PlaceType;
        objModule.Remark = sysModule.Remark;
        objModule.ValGroupName = sysModule.ValGroupName;
        objModule.ClickScriptFun = sysModule.ClickScriptFun;
        objModule.CommandArgument = sysModule.CommandArgument;
        objModule.CommandName = sysModule.CommandName;
        objModule.IsMvc = false;
        objModule.IsController = false;
        objModule.ImageUrl = sysModule.ImageUrl;
        objModule.MenuField = sysModule.MenuField;
        objModule.MenuCal = sysModule.MenuCal;
        objModule.MenuValue = sysModule.MenuValue;
        objModule.IsCheckPowerData = false;
        objModule.TargetUrl = sysModule.TargetUrl;
        objModule.ModuleCoteID = sysModule.ModuleCoteID;
        objModule.IsEdit = sysModule.IsEdit;
        objModule.ShareModuleID = sysModule.ShareModuleID;
        objModule.IsPower = sysModule.IsPower;
        objModule.CoteKeyID = sysModule.CoteKeyID;
        objModule.IsSupperPower = sysModule.IsSupperPower;
        this.InsertModule(objModule);
        objAddModuleIDList.Remove(sysModule.ModuleID);
        this.ModuleQuickChildCopy(quickModulename, moduleCode, logModuleID, objModule.ModuleID, sysModule.ModuleID, list, objAddModuleIDList);
      }
      if (objAddModuleIDList.Count <= 0)
        return;
      foreach (WTF.Power.Entity.sys_module sysModule in (IEnumerable<WTF.Power.Entity.sys_module>) list.Where<WTF.Power.Entity.sys_module>((Func<WTF.Power.Entity.sys_module, bool>) (s => objAddModuleIDList.Contains(s.ModuleID))).OrderBy<WTF.Power.Entity.sys_module, int>((Func<WTF.Power.Entity.sys_module, int>) (s => s.SortIndex)))
      {
        WTF.Power.Entity.sys_module objModule = new WTF.Power.Entity.sys_module();
        objModule.ModuleID = Guid.NewGuid().ToString();
        objModule.LogCategoryID = "新增".IndexOf(sysModule.ModuleName) < 0 ? sysModule.LogCategoryID : logModuleID;
        objModule.ModuleCode = "新增,修改".IndexOf(sysModule.ModuleName) < 0 ? sysModule.ModuleCode : (string.IsNullOrWhiteSpace(moduleCode) ? sysModule.ModuleCode : moduleCode);
        if ("新增,修改,删除".IndexOf(sysModule.ModuleName) >= 0)
        {
          objModule.ModuleName = sysModule.ModuleName + quickModulename;
          objModule.ToolTip = sysModule.ToolTip + quickModulename;
        }
        else
        {
          objModule.ModuleName = sysModule.ModuleName;
          objModule.ToolTip = sysModule.ToolTip;
        }
        objModule.ModuleShow = sysModule.ModuleShow;
        objModule.ModuleFunID = sysModule.ModuleFunID;
        objModule.OperateTypeID = sysModule.OperateTypeID;
        objModule.ParentModuleID = moduleID;
        objModule.IsDispose = sysModule.IsDispose;
        objModule.PlaceType = sysModule.PlaceType;
        objModule.Remark = sysModule.Remark;
        objModule.ValGroupName = sysModule.ValGroupName;
        objModule.ClickScriptFun = sysModule.ClickScriptFun;
        objModule.CommandArgument = sysModule.CommandArgument;
        objModule.CommandName = sysModule.CommandName;
        objModule.IsMvc = false;
        objModule.IsController = false;
        objModule.ImageUrl = sysModule.ImageUrl;
        objModule.MenuField = sysModule.MenuField;
        objModule.MenuCal = sysModule.MenuCal;
        objModule.MenuValue = sysModule.MenuValue;
        objModule.IsCheckPowerData = false;
        objModule.TargetUrl = sysModule.TargetUrl;
        objModule.ModuleCoteID = sysModule.ModuleCoteID;
        objModule.IsEdit = sysModule.IsEdit;
        objModule.ShareModuleID = sysModule.ShareModuleID;
        objModule.IsPower = sysModule.IsPower;
        objModule.CoteKeyID = sysModule.CoteKeyID;
        objModule.IsSupperPower = sysModule.IsSupperPower;
        this.InsertModule(objModule);
      }
    }

    private void ModuleQuickChildCopy(string quickModulename, string moduleCode, int logModuleID, string parmentModuleID, string moduleID, List<WTF.Power.Entity.sys_module> objModuleList, List<string> objAddModuleIDList)
    {
      foreach (WTF.Power.Entity.sys_module sysModule in (IEnumerable<WTF.Power.Entity.sys_module>) objModuleList.Where<WTF.Power.Entity.sys_module>((Func<WTF.Power.Entity.sys_module, bool>) (s => s.ParentModuleID == moduleID)).OrderBy<WTF.Power.Entity.sys_module, int>((Func<WTF.Power.Entity.sys_module, int>) (s => s.SortIndex)))
      {
        WTF.Power.Entity.sys_module objModule = new WTF.Power.Entity.sys_module();
        objModule.ModuleID = Guid.NewGuid().ToString();
        objModule.LogCategoryID = "新增".IndexOf(sysModule.ModuleName) < 0 ? sysModule.LogCategoryID : logModuleID;
        objModule.ModuleCode = "新增,修改".IndexOf(sysModule.ModuleName) < 0 ? sysModule.ModuleCode : (string.IsNullOrWhiteSpace(moduleCode) ? sysModule.ModuleCode : moduleCode);
        if ("新增,修改,删除".IndexOf(sysModule.ModuleName) >= 0)
        {
          objModule.ModuleName = sysModule.ModuleName + quickModulename;
          objModule.ToolTip = sysModule.ToolTip + quickModulename;
        }
        else
        {
          objModule.ModuleName = sysModule.ModuleName;
          objModule.ToolTip = sysModule.ToolTip;
        }
        objModule.ModuleShow = sysModule.ModuleShow;
        objModule.ModuleFunID = sysModule.ModuleFunID;
        objModule.OperateTypeID = sysModule.OperateTypeID;
        objModule.ParentModuleID = parmentModuleID;
        objModule.LogCategoryID = sysModule.LogCategoryID;
        objModule.IsDispose = sysModule.IsDispose;
        objModule.PlaceType = sysModule.PlaceType;
        objModule.Remark = sysModule.Remark;
        objModule.ValGroupName = sysModule.ValGroupName;
        objModule.ClickScriptFun = sysModule.ClickScriptFun;
        objModule.CommandArgument = sysModule.CommandArgument;
        objModule.CommandName = sysModule.CommandName;
        objModule.IsMvc = false;
        objModule.IsController = false;
        objModule.ImageUrl = sysModule.ImageUrl;
        objModule.MenuField = sysModule.MenuField;
        objModule.MenuCal = sysModule.MenuCal;
        objModule.MenuValue = sysModule.MenuValue;
        objModule.IsCheckPowerData = false;
        objModule.TargetUrl = sysModule.TargetUrl;
        objModule.ModuleCoteID = sysModule.ModuleCoteID;
        objModule.IsEdit = sysModule.IsEdit;
        objModule.ShareModuleID = sysModule.ShareModuleID;
        objModule.IsPower = sysModule.IsPower;
        objModule.CoteKeyID = sysModule.CoteKeyID;
        objModule.IsSupperPower = sysModule.IsSupperPower;
        this.InsertModule(objModule);
        objAddModuleIDList.Remove(sysModule.ModuleID);
        this.ModuleQuickChildCopy(quickModulename, moduleCode, logModuleID, objModule.ModuleID, sysModule.ModuleID, objModuleList, objAddModuleIDList);
      }
    }

    public void UpdateModuleCheckData(string moduleID, string moduleDataIDstring)
    {
      List<string> stringList = moduleDataIDstring.ConvertListString();
      string str1 = "";
      ObjectSet<WTF.Power.Entity.sys_modulecheckdata> sysModulecheckdata = this.CurrentEntities.sys_modulecheckdata;
      Expression<Func<WTF.Power.Entity.sys_modulecheckdata, bool>> predicate = (Expression<Func<WTF.Power.Entity.sys_modulecheckdata, bool>>) (s => s.ModuleID == moduleID);
      foreach (WTF.Power.Entity.sys_modulecheckdata sysModuleCheckData in (IEnumerable<WTF.Power.Entity.sys_modulecheckdata>) sysModulecheckdata.Where<WTF.Power.Entity.sys_modulecheckdata>(predicate))
      {
        if (stringList.Contains(sysModuleCheckData.ModuleDataID))
        {
          stringList.Remove(sysModuleCheckData.ModuleDataID);
        }
        else
        {
          str1 = str1 + sysModuleCheckData.ModuleDataID.ToString() + ",";
          this.CurrentEntities.DeleteObject((object) sysModuleCheckData);
        }
      }
      this.CurrentEntities.SaveChanges();
      if (stringList.Count > 0)
      {
        foreach (string str2 in stringList)
          this.CurrentEntities.AddTosys_modulecheckdata(new WTF.Power.Entity.sys_modulecheckdata()
          {
            ModuleCheckDataID = Guid.NewGuid().ToString(),
            ModuleID = moduleID,
            ModuleDataID = str2
          });
        this.CurrentEntities.SaveChanges();
      }
      string inputString = str1.TrimEndComma();
      if (!StringHelper.IsNoNull(inputString))
        return;
      new UserRule().DeleteRoleData("it.ModuleDataID in {" + inputString.ConvertStringID() + "}");
    }

    public void InsertModuleType(WTF.Power.Entity.sys_moduletype objModuleType)
    {
      this.CurrentEntities.AddTosys_moduletype(objModuleType);
      this.CurrentEntities.SaveChanges();
    }

    public void UpdateoduleType(WTF.Power.Entity.sys_moduletype objModuleType)
    {
      this.CurrentEntities.SaveChanges();
    }

    public void DeleteModuleType(string moduleTypeIDList)
    {
      foreach (object entity in (IEnumerable<WTF.Power.Entity.sys_moduletype>) this.CurrentEntities.sys_moduletype.Where("it.ModuleTypeID in {" + moduleTypeIDList.ConvertStringID() + "}"))
        this.CurrentEntities.DeleteObject(entity);
      this.CurrentEntities.SaveChanges();
      this.CurrentEntities.sys_moduledata.DeleteData<WTF.Power.Entity.sys_moduledata>("it.ModuleID in {" + moduleTypeIDList.ConvertStringID() + "}", new ObjectParameter[0]);
    }

    public void UpdateModuleSort(string moduleIDstring)
    {
      SysAssert.CheckIsNull(moduleIDstring, "请选择要排序的模块", LogModuleType.ModuleLog);
      List<string> stringList = moduleIDstring.ConvertListString();
      foreach (WTF.Power.Entity.sys_module sysModule in (IEnumerable<WTF.Power.Entity.sys_module>) this.Sys_Module.Where("it.ModuleID in {" + moduleIDstring.ConvertStringID() + "}"))
        sysModule.SortIndex = stringList.IndexOf(sysModule.ModuleID) + 1;
      this.CurrentEntities.SaveChanges();
    }

    public void DeleteModule(string moduleID)
    {
      this.CurrentEntities.DeleteModule(moduleID);
    }

    public void ModeuleMove(string ModuleID, string tagModuleID)
    {
      WTF.Power.Entity.sys_module sysModule1 = this.CurrentEntities.sys_module.First<WTF.Power.Entity.sys_module>((Expression<Func<WTF.Power.Entity.sys_module, bool>>) (s => s.ModuleID == ModuleID));
      string moduleIdPath = sysModule1.ModuleIDPath;
      int moduleLevel = sysModule1.ModuleLevel;
      ObjectQuery<WTF.Power.Entity.sys_module> objectQuery = this.CurrentEntities.sys_module.Where("it.ModuleIDPath like '" + moduleIdPath + "%'");
      WTF.Power.Entity.sys_module sysModule2 = this.CurrentEntities.sys_module.Where<WTF.Power.Entity.sys_module>((Expression<Func<WTF.Power.Entity.sys_module, bool>>) (s => s.ModuleID == tagModuleID)).FirstOrDefault<WTF.Power.Entity.sys_module>();
      string newValue = sysModule2 == null ? ModuleID.ToString() : sysModule2.ModuleIDPath + "," + ModuleID.ToString();
      int num = sysModule2 == null ? 0 : sysModule2.ModuleLevel;
      foreach (WTF.Power.Entity.sys_module sysModule3 in (IEnumerable<WTF.Power.Entity.sys_module>) objectQuery)
      {
        sysModule3.ModuleIDPath = sysModule3.ModuleIDPath.Replace(moduleIdPath, newValue);
        sysModule3.ModuleLevel = sysModule3.ModuleLevel - moduleLevel + 1 + num;
        if (sysModule3.ModuleID == ModuleID)
          sysModule3.ParentModuleID = tagModuleID;
      }
      this.SaveChanges();
    }

    public string ModeuleCopy(string ModuleID, string tagModuleID)
    {
      List<WTF.Power.Entity.sys_module> list = this.CurrentEntities.sys_module.Where("it.ModuleIDPath like '" + this.CurrentEntities.sys_module.First<WTF.Power.Entity.sys_module>((Expression<Func<WTF.Power.Entity.sys_module, bool>>) (s => s.ModuleID == ModuleID)).ModuleIDPath + "%'").ToList<WTF.Power.Entity.sys_module>();
      WTF.Power.Entity.sys_module sysModule = list.First<WTF.Power.Entity.sys_module>((Func<WTF.Power.Entity.sys_module, bool>) (s => s.ModuleID == ModuleID));
      WTF.Power.Entity.sys_module objModule = new WTF.Power.Entity.sys_module();
      objModule.ModuleCode = sysModule.ModuleCode;
      objModule.ModuleName = sysModule.ModuleName + (sysModule.ModuleFunID != 3 ? "-新复制的节点" : "");
      objModule.ModuleShow = sysModule.ModuleShow;
      objModule.ModuleFunID = sysModule.ModuleFunID;
      objModule.OperateTypeID = sysModule.OperateTypeID;
      objModule.ParentModuleID = tagModuleID;
      objModule.LogCategoryID = sysModule.LogCategoryID;
      objModule.IsDispose = sysModule.IsDispose;
      objModule.PlaceType = sysModule.PlaceType;
      objModule.Remark = sysModule.Remark;
      objModule.ToolTip = sysModule.ToolTip;
      objModule.ValGroupName = sysModule.ValGroupName;
      objModule.ClickScriptFun = sysModule.ClickScriptFun;
      objModule.CommandArgument = sysModule.CommandArgument;
      objModule.CommandName = sysModule.CommandName;
      objModule.IsMvc = sysModule.IsMvc;
      objModule.IsController = sysModule.IsController;
      objModule.ImageUrl = sysModule.ImageUrl;
      objModule.ModuleID = Guid.NewGuid().ToString();
      objModule.MenuField = sysModule.MenuField;
      objModule.MenuCal = sysModule.MenuCal;
      objModule.MenuValue = sysModule.MenuValue;
      objModule.IsCheckPowerData = false;
      objModule.ModuleCoteID = sysModule.ModuleCoteID;
      objModule.TargetUrl = sysModule.TargetUrl;
      objModule.IsEdit = sysModule.IsEdit;
      objModule.ShareModuleID = sysModule.ShareModuleID;
      objModule.IsPower = sysModule.IsPower;
      objModule.IsSupperPower = sysModule.IsSupperPower;
      objModule.CoteKeyID = sysModule.CoteKeyID;
      if (objModule.CoteKeyID > 0)
        objModule.CoteKeyID = this.Sys_Module.Max<WTF.Power.Entity.sys_module, int>((Expression<Func<WTF.Power.Entity.sys_module, int>>) (s => s.CoteKeyID)) + 1;
      this.InsertModule(objModule);
      this.ModeuleChildCopy(objModule.ModuleID, ModuleID, list);
      return objModule.ModuleID;
    }

    private void ModeuleChildCopy(string ParmentModuleID, string moduleID, List<WTF.Power.Entity.sys_module> objSys_ModuleList)
    {
      foreach (WTF.Power.Entity.sys_module sysModule in (IEnumerable<WTF.Power.Entity.sys_module>) objSys_ModuleList.Where<WTF.Power.Entity.sys_module>((Func<WTF.Power.Entity.sys_module, bool>) (s => s.ParentModuleID == moduleID)).OrderBy<WTF.Power.Entity.sys_module, int>((Func<WTF.Power.Entity.sys_module, int>) (p => p.SortIndex)))
      {
        WTF.Power.Entity.sys_module objModule = new WTF.Power.Entity.sys_module();
        objModule.ModuleCode = sysModule.ModuleCode;
        objModule.ModuleName = sysModule.ModuleName;
        objModule.ModuleShow = sysModule.ModuleShow;
        objModule.ModuleFunID = sysModule.ModuleFunID;
        objModule.OperateTypeID = sysModule.OperateTypeID;
        objModule.ParentModuleID = ParmentModuleID;
        objModule.LogCategoryID = sysModule.LogCategoryID;
        objModule.IsDispose = sysModule.IsDispose;
        objModule.PlaceType = sysModule.PlaceType;
        objModule.Remark = sysModule.Remark;
        objModule.ToolTip = sysModule.ToolTip;
        objModule.ValGroupName = sysModule.ValGroupName;
        objModule.ClickScriptFun = sysModule.ClickScriptFun;
        objModule.CommandArgument = sysModule.CommandArgument;
        objModule.CommandName = sysModule.CommandName;
        objModule.IsMvc = sysModule.IsMvc;
        objModule.IsController = sysModule.IsController;
        objModule.ImageUrl = sysModule.ImageUrl;
        objModule.IsEdit = sysModule.IsEdit;
        objModule.ModuleID = Guid.NewGuid().ToString();
        objModule.MenuField = sysModule.MenuField;
        objModule.MenuCal = sysModule.MenuCal;
        objModule.MenuValue = sysModule.MenuValue;
        objModule.IsCheckPowerData = false;
        objModule.ModuleCoteID = sysModule.ModuleCoteID;
        objModule.TargetUrl = sysModule.TargetUrl;
        objModule.ShareModuleID = sysModule.ShareModuleID;
        objModule.IsPower = sysModule.IsPower;
        objModule.IsSupperPower = sysModule.IsSupperPower;
        objModule.CoteKeyID = sysModule.CoteKeyID;
        if (objModule.CoteKeyID > 0)
          objModule.CoteKeyID = this.Sys_Module.Max<WTF.Power.Entity.sys_module, int>((Expression<Func<WTF.Power.Entity.sys_module, int>>) (s => s.CoteKeyID)) + 1;
        this.InsertModule(objModule);
        this.ModeuleChildCopy(objModule.ModuleID, sysModule.ModuleID, objSys_ModuleList);
      }
    }

    public ObjectQuery<WTF.Power.Entity.sys_module> GetUpdateSqlModuleInfo(string moduleId)
    {
      return this.CurrentEntities.sys_module.Where("it.ModuleIDPath like '" + this.CurrentEntities.sys_module.First<WTF.Power.Entity.sys_module>((Expression<Func<WTF.Power.Entity.sys_module, bool>>) (s => s.ModuleID == moduleId)).ModuleIDPath + "%'");
    }

    public void UpdateModuleIco(int operateTypeID, string icoPath)
    {
      ObjectSet<WTF.Power.Entity.sys_module> sysModule1 = this.CurrentEntities.sys_module;
      Expression<Func<WTF.Power.Entity.sys_module, bool>> predicate = (Expression<Func<WTF.Power.Entity.sys_module, bool>>) (p => p.OperateTypeID == operateTypeID);
      foreach (WTF.Power.Entity.sys_module sysModule2 in (IEnumerable<WTF.Power.Entity.sys_module>) sysModule1.Where<WTF.Power.Entity.sys_module>(predicate))
        sysModule2.ImageUrl = icoPath;
      this.CurrentEntities.SaveChanges();
    }

    public void InsertModuleHelp(string moduleID, string helpTitle, string helpContent, string fileTextResourceID, string fileResourceID)
    {
      if (this.Sys_ModuleHelp.Where<WTF.Power.Entity.sys_modulehelp>((Expression<Func<WTF.Power.Entity.sys_modulehelp, bool>>) (p => p.ModuleID == moduleID)).Count<WTF.Power.Entity.sys_modulehelp>() > 0)
      {
        WTF.Power.Entity.sys_modulehelp sysModuleHelp = this.Sys_ModuleHelp.Single<WTF.Power.Entity.sys_modulehelp>((Expression<Func<WTF.Power.Entity.sys_modulehelp, bool>>) (p => p.ModuleID == moduleID));
        sysModuleHelp.HelpContent = helpContent;
        sysModuleHelp.HelpTitle = helpTitle;
        sysModuleHelp.FileResourceID = fileResourceID;
        sysModuleHelp.FileTextResourceID = fileTextResourceID;
      }
      else
          this.CurrentEntities.sys_modulehelp.Add(new WTF.Power.Entity.sys_modulehelp()
        {
          ModuleID = moduleID,
          HelpContent = helpContent,
          HelpTitle = helpTitle,
          CreateDate = DateTime.Now,
          FileResourceID = fileResourceID,
          FileTextResourceID = fileTextResourceID
        });
      this.CurrentEntities.SaveChanges();
    }

    public void InsertModuleData(WTF.Power.Entity.sys_moduledata objSys_ModuleData)
    {
      objSys_ModuleData.DataName.CheckIsNull<string>("请输入数据名称", "ModuleLog");
      objSys_ModuleData.FieldName.CheckIsNull<string>("请输入字段名", "ModuleLog");
      objSys_ModuleData.DataSelect.CheckIsNull<string>("请输入数据查询", "ModuleLog");
      this.CurrentEntities.sys_moduledata.Add(objSys_ModuleData);
      this.CurrentEntities.SaveChanges();
    }

    public void UpdateModuleData(WTF.Power.Entity.sys_moduledata objSys_ModuleData)
    {
      objSys_ModuleData.DataName.CheckIsNull<string>("请输入数据名称", "ModuleLog");
      objSys_ModuleData.FieldName.CheckIsNull<string>("请输入字段名", "ModuleLog");
      objSys_ModuleData.DataSelect.CheckIsNull<string>("请输入数据查询", "ModuleLog");
      this.CurrentEntities.SaveChanges();
    }

    public void DeleteModuleDataByKey(string primaryKey)
    {
      if (StringHelper.IsNull(primaryKey))
        return;
      this.CurrentEntities.sys_moduledata.DeleteDataPrimaryKey<WTF.Power.Entity.sys_moduledata>(primaryKey);
      new UserRule().DeleteRoleData("it.ModuleDataID in {" + primaryKey.ConvertStringID() + "}");
      this.CurrentEntities.sys_modulecheckdata.DeleteData<WTF.Power.Entity.sys_modulecheckdata>("it.ModuleDataID in {" + primaryKey.ConvertStringID() + "}", new ObjectParameter[0]);
    }

    public bool CheckIsPowerData(string moduleTypeID, string pageName)
    {
      return this.CurrentEntities.sys_module.Any<WTF.Power.Entity.sys_module>((Expression<Func<WTF.Power.Entity.sys_module, bool>>) (s => s.ModuleTypeID == moduleTypeID && s.ModuleCode == pageName && s.IsCheckPowerData == true));
    }

    public List<WTF.Power.Entity.sys_module> GetPowerOperateModule(string moduleTypeID, string moduleCode, string userID, OperatePlaceType operatePlaceType)
    {
      return this.CurrentEntities.GetPowerOperateModuleByID(moduleTypeID, moduleCode, userID, ((int) operatePlaceType).ToString()).ToList<WTF.Power.Entity.sys_module>();
    }

    public bool GetPowerOperateButton(string moduleTypeID, string moduleCode, string userID, string commandName)
    {
      int? nullable = this.CurrentEntities.GetPowerOperateCommandByID(moduleTypeID, moduleCode, userID, commandName).First<int?>();
      if (nullable.GetValueOrDefault() > 0)
        return nullable.HasValue;
      return false;
    }

    public bool GetPowerOperateButton(string moduleTypeID, string moduleCode, string userID, string coteModuleID, string coteID, string commandName)
    {
      int? nullable = this.CurrentEntities.GetPowerCoteOperateCommandByID(moduleTypeID, moduleCode, userID, coteModuleID, coteID, commandName).First<int?>();
      if (nullable.GetValueOrDefault() > 0)
        return nullable.HasValue;
      return false;
    }

    public List<WTF.Power.Entity.sys_module> GetPowerOperateModule(string moduleTypeID, string moduleCode, string userID)
    {
      return this.CurrentEntities.GetPowerOperateModuleByID(moduleTypeID, moduleCode, userID, "").ToList<WTF.Power.Entity.sys_module>();
    }

    public List<WTF.Power.Entity.sys_module> GetPowerOperateModule(string moduleTypeID, string moduleCode, string userID, OperatePlaceType operatePlaceType, string coteModuleID, string coteID)
    {
      return this.CurrentEntities.GetPowerCoteOperateModuleByID(moduleTypeID, moduleCode, userID, ((int) operatePlaceType).ToString(), coteModuleID, coteID).ToList<WTF.Power.Entity.sys_module>();
    }

    public List<WTF.Power.Entity.sys_module> GetPowerOperateModule(string moduleTypeID, string moduleCode, string userID, string coteModuleID, string coteID)
    {
      return this.CurrentEntities.GetPowerCoteOperateModuleByID(moduleTypeID, moduleCode, userID, "", coteModuleID, coteID).ToList<WTF.Power.Entity.sys_module>();
    }

    public IEnumerable<WTF.Power.Entity.sys_module> GetPowerFunctionModule(string moduleTypeID, string moduleCode, bool containChild)
    {
      UserRule userRule = new UserRule();
      return this.CurrentEntities.GetPowerFunctionModuleByID(moduleTypeID, moduleCode, userRule.CurrentUser.UserID, new bool?(containChild)).OfType<WTF.Power.Entity.sys_module>();
    }

    public List<WTF.Power.Entity.sys_moduledata> GetRolePowerModuleData(string ModuleID, string Rolid)
    {
      if (this.CurrentEntities.sys_moduletype.Any<WTF.Power.Entity.sys_moduletype>((Expression<Func<WTF.Power.Entity.sys_moduletype, bool>>) (s => s.ModuleTypeID == ModuleID)))
        return this.CurrentEntities.ExecuteStoreQuery<WTF.Power.Entity.sys_moduledata>(string.Format("select distinct Sys_ModuleData.*   from Sys_ModuleData  ,Sys_RolePower,\r\n\r\nSys_ModuleCheckData where \r\n Sys_RolePower.RoleID='{0}'  and Sys_ModuleData.Moduleid='{1}' and \r\n  Sys_ModuleCheckData.Moduleid=Sys_RolePower.Moduleid\r\nand   Sys_ModuleData.ModuleDataID=Sys_ModuleCheckData.ModuleDataID", (object) Rolid.ToString(), (object) ModuleID.ToString())).ToList<WTF.Power.Entity.sys_moduledata>();
      return this.CurrentEntities.sys_moduledata.Where<WTF.Power.Entity.sys_moduledata>((Expression<Func<WTF.Power.Entity.sys_moduledata, bool>>) (s => s.ModuleID == ModuleID)).ToList<WTF.Power.Entity.sys_moduledata>();
    }

    public List<WTF.Power.Entity.sys_moduledata> GetUserRolePowerModuleData(string ModuleID, string userID)
    {
      if (this.CurrentEntities.sys_moduletype.Any<WTF.Power.Entity.sys_moduletype>((Expression<Func<WTF.Power.Entity.sys_moduletype, bool>>) (s => s.ModuleTypeID == ModuleID)))
        return this.CurrentEntities.ExecuteStoreQuery<WTF.Power.Entity.sys_moduledata>(string.Format("select distinct Sys_ModuleData.*   from Sys_ModuleData  ,Sys_RolePower,\r\n\r\nSys_ModuleCheckData,Sys_RoleUser where Sys_RoleUser.UserID='{0}' and \r\n Sys_RolePower.RoleID=Sys_RoleUser.RoleID   and Sys_ModuleData.Moduleid='{1}' and \r\n  Sys_ModuleCheckData.Moduleid=Sys_RolePower.Moduleid\r\nand   Sys_ModuleData.ModuleDataID=Sys_ModuleCheckData.ModuleDataID", (object) userID, (object) ModuleID.ToString())).ToList<WTF.Power.Entity.sys_moduledata>();
      return this.CurrentEntities.ExecuteStoreQuery<WTF.Power.Entity.sys_moduledata>(string.Format(" select distinct Sys_ModuleData.* from Sys_ModuleData,Sys_RoleData,Sys_RoleUser\r\n where Sys_ModuleData.ModuleDataID=Sys_RoleData.ModuleDataID\r\nand Sys_RoleData.RoleID=Sys_RoleUser.RoleID AND Sys_RoleUser.UserID='{0}'\r\nAND Sys_ModuleData.ModuleID='{1}'", (object) userID, (object) ModuleID)).ToList<WTF.Power.Entity.sys_moduledata>();
    }

    public List<WTF.Power.Entity.sys_moduledata> GetCheckPageModuleData(string moduleTypeID, string pageName)
    {
      return this.CurrentEntities.ExecuteStoreQuery<WTF.Power.Entity.sys_moduledata>(string.Format(" \r\n  set @ModuleID='';\r\nSELECT    Sys_Module.MODULEID into @ModuleID\r\n    from    Sys_Module\r\n     where   Sys_Module.ModuleTypeID='{0}' \r\n and Sys_Module.ModuleCode='{1}';\r\n\r\nselect   distinct Sys_ModuleData.* from  Sys_ModuleData\r\n where  \r\n   (Sys_ModuleData.ModuleID=@ModuleID\r\n     or   Sys_ModuleData.ModuleDataID in (select  ModuleDataID from Sys_ModuleCheckData where  Sys_ModuleCheckData.ModuleID=@ModuleID));", (object) moduleTypeID, (object) pageName)).ToList<WTF.Power.Entity.sys_moduledata>();
    }

    public List<WTF.Power.Entity.sys_moduledata> GetCheckPageFieldModuleData(string moduleTypeID, string pageName, string fieldName)
    {
      return this.CurrentEntities.ExecuteStoreQuery<WTF.Power.Entity.sys_moduledata>(string.Format("\r\n   set @ModuleID='';\r\nSELECT    Sys_Module.MODULEID into @ModuleID\r\n    from    Sys_Module\r\n     where   Sys_Module.ModuleTypeID='{0}' \r\n and Sys_Module.ModuleCode='{1}';\r\n\r\nselect  distinct  Sys_ModuleData.* from  Sys_ModuleData\r\n where  Sys_ModuleData.FieldName='{2}' and \r\n   (Sys_ModuleData.ModuleID=@ModuleID  or   Sys_ModuleData.ModuleDataID in (select  ModuleDataID from Sys_ModuleCheckData where  Sys_ModuleCheckData.ModuleID=@ModuleID));", (object) moduleTypeID, (object) pageName, (object) fieldName)).ToList<WTF.Power.Entity.sys_moduledata>();
    }

    public void SaveChanges()
    {
      this.objCurrentEntities.SaveChanges();
    }

    public string GetModeuleManageTreeXmlText()
    {
      XmlDocument xmlDocSource = new XmlDocument();
      List<WTF.Power.Entity.sys_moduletype> list = this.Sys_ModuleType.Include("Sys_Module").OrderByDescending<WTF.Power.Entity.sys_moduletype, string>((Expression<Func<WTF.Power.Entity.sys_moduletype, string>>) (s => s.ModuleTypeName)).ToList<WTF.Power.Entity.sys_moduletype>();
      XmlElement element1 = xmlDocSource.CreateElement("Module");
      element1.SetAttribute("ModuleID", Guid.Empty.ToString());
      element1.SetAttribute("ModuleName", "平台模块分类管理");
      element1.SetAttribute("NavigateUrl", string.Format("~/ServiceLayer/Module/ModuleTypeList.aspx"));
      xmlDocSource.AppendChild((XmlNode) element1);
      foreach (WTF.Power.Entity.sys_moduletype sysModuleType in list)
      {
        XmlElement element2 = xmlDocSource.CreateElement("Module");
        element2.SetAttribute("ModuleID", sysModuleType.ModuleTypeID.ToString());
        element2.SetAttribute("ModuleName", sysModuleType.ModuleTypeName);
        element2.SetAttribute("NavigateUrl", string.Format("~/ServiceLayer/Module/ModuleTypeInfo.aspx?ModuleID={0}", (object) sysModuleType.ModuleTypeID.ToString()).EncryptModuleQuery());
        element1.AppendChild((XmlNode) element2);
        this.CreateChildModeuleManageXmlElement(xmlDocSource, sysModuleType.ModuleTypeID, element2, sysModuleType.Sys_Module.ToList<WTF.Power.Entity.sys_module>());
      }
      return xmlDocSource.InnerXml;
    }

    private void CreateChildModeuleManageXmlElement(XmlDocument xmlDocSource, string ModuleID, XmlElement objXmlElement, List<WTF.Power.Entity.sys_module> objSys_ModuleList)
    {
      foreach (WTF.Power.Entity.sys_module sysModule in (IEnumerable<WTF.Power.Entity.sys_module>) objSys_ModuleList.Where<WTF.Power.Entity.sys_module>((Func<WTF.Power.Entity.sys_module, bool>) (s => s.ParentModuleID == ModuleID)).OrderBy<WTF.Power.Entity.sys_module, int>((Func<WTF.Power.Entity.sys_module, int>) (p => p.SortIndex)))
      {
        XmlElement element = xmlDocSource.CreateElement("Module");
        element.SetAttribute("ModuleID", sysModule.ModuleID.ToString());
        element.SetAttribute("ModuleName", sysModule.ModuleName);
        if (sysModule.IsMvc)
          element.SetAttribute("NavigateUrl", string.Format("~/ServiceLayer/Module/ModuleMvcInfo.aspx?ModuleID={0}", (object) sysModule.ModuleID.ToString()).EncryptModuleQuery());
        else
          element.SetAttribute("NavigateUrl", string.Format("~/ServiceLayer/Module/ModuleInfo.aspx?ModuleID={0}", (object) sysModule.ModuleID.ToString()).EncryptModuleQuery());
        objXmlElement.AppendChild((XmlNode) element);
        this.CreateChildModeuleManageXmlElement(xmlDocSource, sysModule.ModuleID, element, objSys_ModuleList);
      }
    }

    public string GetModeuleMoveTreexXml(string ModuleID)
    {
      XmlDocument xmlDocSource = new XmlDocument();
      WTF.Power.Entity.sys_module objSys_Module = this.CurrentEntities.sys_module.First<WTF.Power.Entity.sys_module>((Expression<Func<WTF.Power.Entity.sys_module, bool>>) (s => s.ModuleID == ModuleID));
      WTF.Power.Entity.sys_moduletype sysModuleType = this.CurrentEntities.sys_moduletype.Where("it.ModuleTypeID =='" + objSys_Module.ModuleTypeID.ToString() + "'").Include("Sys_Module").First<WTF.Power.Entity.sys_moduletype>();
      XmlElement element = xmlDocSource.CreateElement("Module");
      element.SetAttribute("ModuleID", sysModuleType.ModuleTypeID.ToString());
      element.SetAttribute("ModuleName", sysModuleType.ModuleTypeName);
      element.SetAttribute("NavigateUrl", sysModuleType.ModuleTypeID.ToString());
      xmlDocSource.AppendChild((XmlNode) element);
      List<WTF.Power.Entity.sys_module> list = sysModuleType.Sys_Module.Where<WTF.Power.Entity.sys_module>((Func<WTF.Power.Entity.sys_module, bool>) (s => !s.ModuleIDPath.StartsWith(objSys_Module.ModuleIDPath))).ToList<WTF.Power.Entity.sys_module>();
      this.CreateChildModeuleXmlElement(xmlDocSource, sysModuleType.ModuleTypeID, element, list);
      return xmlDocSource.InnerXml;
    }

    public string GetModeuleCopyTreexXml(string ModuleID)
    {
      WTF.Power.Entity.sys_module objSys_Module = this.CurrentEntities.sys_module.First<WTF.Power.Entity.sys_module>((Expression<Func<WTF.Power.Entity.sys_module, bool>>) (s => s.ModuleID == ModuleID));
      XmlDocument xmlDocSource = new XmlDocument();
      List<WTF.Power.Entity.sys_moduletype> list = this.Sys_ModuleType.Include("Sys_Module").ToList<WTF.Power.Entity.sys_moduletype>();
      XmlElement element1 = xmlDocSource.CreateElement("Module");
      element1.SetAttribute("ModuleID", Guid.Empty.ToString());
      element1.SetAttribute("ModuleName", "平台复制管理");
      element1.SetAttribute("NavigateUrl", "");
      xmlDocSource.AppendChild((XmlNode) element1);
      foreach (WTF.Power.Entity.sys_moduletype sysModuleType in list)
      {
        XmlElement element2 = xmlDocSource.CreateElement("Module");
        element2.SetAttribute("ModuleID", sysModuleType.ModuleTypeID.ToString());
        element2.SetAttribute("ModuleName", sysModuleType.ModuleTypeName);
        element2.SetAttribute("NavigateUrl", "ModuleType");
        element1.AppendChild((XmlNode) element2);
        this.CreateChildModeuleXmlElement(xmlDocSource, sysModuleType.ModuleTypeID, element2, sysModuleType.Sys_Module.Where<WTF.Power.Entity.sys_module>((Func<WTF.Power.Entity.sys_module, bool>) (s => !s.ModuleIDPath.StartsWith(objSys_Module.ModuleIDPath))).ToList<WTF.Power.Entity.sys_module>());
      }
      return xmlDocSource.InnerXml;
    }

    public string GetQuickModuleTreexXml()
    {
      XmlDocument xmlDocSource = new XmlDocument();
      WTF.Power.Entity.sys_moduletype sysModuleType = this.CurrentEntities.sys_moduletype.Where("it.ModuleTypeCode == 'ModuleTemplate'").Include("Sys_Module").First<WTF.Power.Entity.sys_moduletype>();
      XmlElement element = xmlDocSource.CreateElement("Module");
      element.SetAttribute("ModuleID", sysModuleType.ModuleTypeID.ToString());
      element.SetAttribute("ModuleName", "请选择以下结点");
      element.SetAttribute("NavigateUrl", sysModuleType.ModuleTypeID.ToString());
      xmlDocSource.AppendChild((XmlNode) element);
      this.CreateChildModeuleXmlElement(xmlDocSource, sysModuleType.ModuleTypeID, element, sysModuleType.Sys_Module.OrderBy<WTF.Power.Entity.sys_module, int>((Func<WTF.Power.Entity.sys_module, int>) (s => s.SortIndex)).ToList<WTF.Power.Entity.sys_module>());
      return xmlDocSource.InnerXml;
    }

    private void CreateChildModeuleXmlElement(XmlDocument xmlDocSource, string ModuleID, XmlElement objXmlElement, List<WTF.Power.Entity.sys_module> objSys_ModuleList)
    {
      foreach (WTF.Power.Entity.sys_module sysModule in (IEnumerable<WTF.Power.Entity.sys_module>) objSys_ModuleList.Where<WTF.Power.Entity.sys_module>((Func<WTF.Power.Entity.sys_module, bool>) (s => s.ParentModuleID == ModuleID)).OrderBy<WTF.Power.Entity.sys_module, int>((Func<WTF.Power.Entity.sys_module, int>) (p => p.SortIndex)))
      {
        XmlElement element = xmlDocSource.CreateElement("Module");
        element.SetAttribute("ModuleID", sysModule.ModuleID.ToString());
        element.SetAttribute("ModuleName", sysModule.ModuleName);
        element.SetAttribute("NavigateUrl", sysModule.ModuleID.ToString());
        objXmlElement.AppendChild((XmlNode) element);
        this.CreateChildModeuleXmlElement(xmlDocSource, sysModule.ModuleID, element, objSys_ModuleList);
      }
    }

    public string GetModeuleTypeDataTreexXmlText(string moduleTypeID, string RoleID)
    {
      string str1 = "RoleDataPower.aspx?ModuleID={0}&RoleID=" + RoleID.ToString();
      UserRule userRule = new UserRule();
      XmlDocument xmlDocSource = new XmlDocument();
      WTF.Power.Entity.sys_moduletype sysModuleType = this.CurrentEntities.sys_moduletype.FirstOrDefault<WTF.Power.Entity.sys_moduletype>((Expression<Func<WTF.Power.Entity.sys_moduletype, bool>>) (s => s.ModuleTypeID == moduleTypeID));
      XmlElement element = xmlDocSource.CreateElement("Module");
      element.SetAttribute("ModuleID", sysModuleType.ModuleTypeID.ToString());
      element.SetAttribute("ModuleName", sysModuleType.ModuleTypeName);
      element.SetAttribute("NavigateUrl", string.Format(str1, (object) sysModuleType.ModuleTypeID.ToString()).EncryptModuleQuery());
      xmlDocSource.AppendChild((XmlNode) element);
      string str2 = "";
      List<WTF.Power.Entity.sys_module> list = this.CurrentEntities.ExecuteStoreQuery<WTF.Power.Entity.sys_module>(string.Format("SELECT   Sys_Module.* FROM   Sys_ModuleData INNER JOIN  Sys_Module ON  Sys_ModuleData.ModuleID =Sys_Module.ModuleID INNER JOIN  Sys_RolePower on  Sys_Module.ModuleID=Sys_RolePower.ModuleID where  Sys_Module.IsCheckPowerData=1 \r\nand Sys_Module.ModuleTypeID='{0}' AND  Sys_RolePower.RoleID='{1}'", (object) moduleTypeID.ToString(), (object) RoleID.ToString())).ToList<WTF.Power.Entity.sys_module>();
      foreach (WTF.Power.Entity.sys_module sysModule in list)
        str2 = str2 + sysModule.ModuleIDPath + ",";
      string IdString = str2.TrimEndComma().ConvertListString().Distinct<string>().ToList<string>().ConvertListToString<string>();
      if (StringHelper.IsNoNull(IdString))
        this.CreateChildModeuleUrlXmlElement(xmlDocSource, sysModuleType.ModuleTypeID, element, this.CurrentEntities.sys_module.WhereKey<WTF.Power.Entity.sys_module>(IdString).ToList<WTF.Power.Entity.sys_module>(), list, str1);
      return xmlDocSource.InnerXml;
    }

    private void CreateChildModeuleUrlXmlElement(XmlDocument xmlDocSource, string ModuleID, XmlElement objXmlElement, List<WTF.Power.Entity.sys_module> objSys_ModuleList, List<WTF.Power.Entity.sys_module> objDataSys_ModuleList, string urlFormant)
    {
      foreach (WTF.Power.Entity.sys_module sysModule in (IEnumerable<WTF.Power.Entity.sys_module>) objSys_ModuleList.Where<WTF.Power.Entity.sys_module>((Func<WTF.Power.Entity.sys_module, bool>) (s => s.ParentModuleID == ModuleID)).OrderBy<WTF.Power.Entity.sys_module, int>((Func<WTF.Power.Entity.sys_module, int>) (p => p.SortIndex)))
      {
        WTF.Power.Entity.sys_module objModule = sysModule;
        XmlElement element = xmlDocSource.CreateElement("Module");
        element.SetAttribute("ModuleID", objModule.ModuleID.ToString());
        element.SetAttribute("ModuleName", objModule.ModuleName);
        element.SetAttribute("NavigateUrl", objDataSys_ModuleList.Any<WTF.Power.Entity.sys_module>((Func<WTF.Power.Entity.sys_module, bool>) (s => s.ModuleID == objModule.ModuleID)) ? string.Format(urlFormant, (object) objModule.ModuleID.ToString()).EncryptModuleQuery() : "javascript:void();");
        objXmlElement.AppendChild((XmlNode) element);
        this.CreateChildModeuleUrlXmlElement(xmlDocSource, objModule.ModuleID, element, objSys_ModuleList, objDataSys_ModuleList, urlFormant);
      }
    }
  }
}

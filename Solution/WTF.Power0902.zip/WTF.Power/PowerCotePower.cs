﻿// Decompiled with JetBrains decompiler
// Type: WTF.Power.PowerCotePower
// Assembly: WTF.Power, Version=1.0.5451.23978, Culture=neutral, PublicKeyToken=null
// MVID: ACB99369-F466-4579-86CC-C2D259CAF828
// Assembly location: C:\F盘\天棣互联\Gao7CMS\SevenFramework\SevenDLL\WTF.Power.dll

using MySql.Data.MySqlClient;
using WTF.Power.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Xml;
using WTF.Framework;
using WTF.Logging;

namespace WTF.Power
{
  public class PowerCotePower
  {
    public string CoteTableName { get; set; }

    public string IDName { get; set; }

    public string Name { get; set; }

    public string ConnectionStringName { get; set; }

    public string DefalutCondition { get; set; }

    public string SortExpression { get; set; }

    public string ModuleTypeID { get; set; }

    public int IDDataType { get; set; }

    public bool IsParentUrl { get; set; }

    public string GetTabeleSql
    {
      get
      {
        return " select DISTINCT " + this.IDName + "," + this.Name + " from " + this.CoteTableName + " ";
      }
    }

    public PowerCotePower(sys_modulecote objSys_ModuleCote, string moduleTypeID)
    {
      this.CoteTableName = objSys_ModuleCote.CoteTableName;
      this.IDName = objSys_ModuleCote.IDName;
      this.Name = objSys_ModuleCote.Name;
      this.ConnectionStringName = objSys_ModuleCote.ConnectionStringName;
      this.IDDataType = objSys_ModuleCote.IDDataType;
      this.IsParentUrl = objSys_ModuleCote.IsParentUrl;
      this.ModuleTypeID = moduleTypeID;
      this.DefalutCondition = objSys_ModuleCote.Condtion;
      this.DefalutCondition = this.DefalutCondition.Replace("{ModuleTypeID}", this.ModuleTypeID);
      this.SortExpression = objSys_ModuleCote.SortExpression;
    }

    public CoteInfo GetCoteInfoKeyID(string key)
    {
      return this.GetCoteInfoKeyList(key)[0];
    }

    private List<CoteInfo> ConvertCoteInfo(MySqlDataReader reader)
    {
      List<CoteInfo> coteInfoList = new List<CoteInfo>();
      try
      {
        while (reader.Read())
        {
          CoteInfo coteInfo = new CoteInfo();
          coteInfo.ParentID = "";
          if (reader[this.IDName] != DBNull.Value)
            coteInfo.ID = Convert.ToString(reader[this.IDName]);
          if (reader[this.Name] != DBNull.Value)
            coteInfo.Name = Convert.ToString(reader[this.Name]);
          coteInfoList.Add(coteInfo);
        }
      }
      catch (Exception ex)
      {
        LogHelper<LogModuleType>.Write(LogModuleType.ModuleLog, ex, "");
        return coteInfoList;
      }
      finally
      {
        reader.Close();
      }
      return coteInfoList;
    }

    public List<CoteInfo> GetCoteInfoKeyList(string key)
    {
      string str = this.IDDataType != 1 ? this.IDName + " in (" + key.ConvertStringID() + ")" : this.IDName + " in (" + key + ")";
      if (!string.IsNullOrWhiteSpace(this.DefalutCondition))
        str = str + " and " + this.DefalutCondition;
      WTF.Framework.MySqlHelper mySqlHelper = new WTF.Framework.MySqlHelper(this.ConnectionStringName);
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.Append(this.GetTabeleSql);
      if (!string.IsNullOrWhiteSpace(str))
        stringBuilder.Append(" where " + str + " ");
      if (key.Split(',').Length > 1 && !string.IsNullOrWhiteSpace(this.SortExpression))
        stringBuilder.Append(" order by " + this.SortExpression);
      return this.ConvertCoteInfo(mySqlHelper.ExecuteReader(stringBuilder.ToString()));
    }

    public List<CoteInfo> GetAllCoteInfoList()
    {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.Append(this.GetTabeleSql);
      if (!string.IsNullOrWhiteSpace(this.DefalutCondition))
        stringBuilder.Append(" where " + this.DefalutCondition + " ");
      if (!string.IsNullOrWhiteSpace(this.SortExpression))
        stringBuilder.Append(" order by " + this.SortExpression);
      return this.ConvertCoteInfo(new WTF.Framework.MySqlHelper(this.ConnectionStringName).ExecuteReader(stringBuilder.ToString()));
    }

    protected List<sys_authorizegrouppower> GetAuthorizeGroupCotePower(string AuthorizeGroupID, string moduleID)
    {
      return new UserRule().CurrentEntities.ExecuteStoreQuery<sys_authorizegrouppower>(string.Format(" SELECT *  FROM  sys_authorizegrouppower  WHERE AuthorizeGroupID='{0}'  AND CoteModuleID='{1}'", (object) AuthorizeGroupID, (object) moduleID)).ToList<sys_authorizegrouppower>();
    }

    protected List<sys_rolepower> GetUserCoteRolePower(string userID, string moduleID)
    {
      return new UserRule().CurrentEntities.ExecuteStoreQuery<sys_rolepower>(string.Format(" SELECT  Sys_RolePower.*\r\n                              FROM  Sys_RoleUser \r\n                             ,   Sys_RolePower WHERE Sys_RoleUser.UserID='{0}'   \r\n                             AND Sys_RolePower.CoteModuleID='{1}' and Sys_RoleUser.RoleID=Sys_RolePower.RoleID", (object) userID, (object) moduleID)).ToList<sys_rolepower>();
    }

    public List<CoteInfo> GetCotePowerList(UserInfo objUserInfo, string CoteModuleID)
    {
      List<CoteInfo> coteInfoList;
      if (objUserInfo.IsSuper)
      {
        coteInfoList = this.GetAllCoteInfoList();
      }
      else
      {
        List<sys_rolepower> list = this.GetUserCoteRolePower(objUserInfo.UserID, CoteModuleID).ToList<sys_rolepower>();
        if (list.Count == 0)
          return (List<CoteInfo>) null;
        coteInfoList = !list.Any<sys_rolepower>((Func<sys_rolepower, bool>) (s => s.IsCoteSupper)) ? this.GetCoteInfoKeyList(list.Select<sys_rolepower, string>((Func<sys_rolepower, string>) (s => s.CoteID)).ToList<string>().ConvertListToString<string>()) : this.GetAllCoteInfoList();
      }
      return coteInfoList;
    }

    public XmlElement GetCotePowerMenuXmlElement(XmlDocument xmlDocSource, UserInfo objUserInfo, sys_module objModule)
    {
      List<CoteInfo> coteInfoList;
      if (objUserInfo.IsSuper)
      {
        coteInfoList = this.GetAllCoteInfoList();
      }
      else
      {
        List<sys_rolepower> list = this.GetUserCoteRolePower(objUserInfo.UserID, objModule.ModuleID).ToList<sys_rolepower>();
        if (list.Count == 0)
          return (XmlElement) null;
        coteInfoList = !list.Any<sys_rolepower>((Func<sys_rolepower, bool>) (s => s.IsCoteSupper)) ? this.GetCoteInfoKeyList(list.Select<Sys_RolePower, string>((Func<sys_rolepower, string>) (s => s.CoteID)).ToList<string>().ConvertListToString<string>()) : this.GetAllCoteInfoList();
      }
      string format1 = "javascript:opentreemodule('{0}','{1}','{2}','{3}');";
      string format2 = objModule.CommandArgument + (objModule.CommandArgument.IndexOf("?") >= 0 ? "&" : "?") + this.IDName + "={0}&CoteID={0}&CoteModuleID=" + objModule.ModuleID + "&PowerName={1}";
      XmlElement element1 = xmlDocSource.CreateElement("Module");
      element1.SetAttribute("ModuleID", objModule.ModuleID.ToString());
      element1.SetAttribute("ModuleName", objModule.ModuleName);
      element1.SetAttribute("ToolTip", objModule.ToolTip);
      element1.SetAttribute("ImageUrl", objModule.ImageUrl);
      element1.SetAttribute("ModuleLevel", objModule.ModuleLevel.ToString());
      element1.SetAttribute("NavigateUrl", "");
      foreach (CoteInfo coteInfo in coteInfoList)
      {
        XmlElement element2 = xmlDocSource.CreateElement("Module");
        element2.SetAttribute("ModuleID", coteInfo.ID.ToString());
        element2.SetAttribute("ModuleName", coteInfo.Name);
        element2.SetAttribute("ToolTip", coteInfo.Name);
        element2.SetAttribute("ImageUrl", objModule.ImageUrl);
        element2.SetAttribute("ModuleLevel", (objModule.ModuleLevel + 1).ToString());
        element2.SetAttribute("NavigateUrl", string.Format(format1, (object) (objModule.ModuleID.ToString() + coteInfo.ID), (object) objModule.ImageUrl, (object) string.Format(format2, (object) coteInfo.ID, (object) coteInfo.Name).EncryptModuleQuery(), (object) coteInfo.Name));
        element1.AppendChild((XmlNode) element2);
      }
      return element1;
    }

    public XmlElement GetCotePowerXmlElement(XmlDocument xmlDocSource, string AuthorizeGroupID, sys_module objCoteModule, List<sys_module> objSys_ModuleList, List<sys_module> AddSys_ModuleList)
    {
      List<CoteInfo> coteInfoList1 = (List<CoteInfo>) null;
      List<sys_authorizegrouppower> authorizegrouppowerList = (List<sys_authorizegrouppower>) null;
      coteInfoList1 = this.GetAllCoteInfoList();
      List<CoteInfo> coteInfoList2;
      if (StringHelper.IsNull(AuthorizeGroupID))
      {
        coteInfoList2 = this.GetAllCoteInfoList();
      }
      else
      {
        authorizegrouppowerList = this.GetAuthorizeGroupCotePower(AuthorizeGroupID, objCoteModule.ModuleID);
        if (authorizegrouppowerList.Count == 0)
          return (XmlElement) null;
        if (authorizegrouppowerList.Any<sys_authorizegrouppower>((Func<sys_authorizegrouppower, bool>) (s => s.IsCoteSupper)))
        {
          coteInfoList2 = this.GetAllCoteInfoList();
          authorizegrouppowerList = (List<sys_authorizegrouppower>) null;
          ModuleRule moduleRule = new ModuleRule();
          string ModuleIDPath = moduleRule.Sys_Module.FirstOrDefault<sys_module>((Expression<Func<sys_module, bool>>) (s => s.ModuleID == objCoteModule.ModuleID)).ModuleIDPath;
          objSys_ModuleList.RemoveAll((Predicate<sys_module>) (s => s.ModuleIDPath.StartsWith(ModuleIDPath)));
          objSys_ModuleList.AddRange((IEnumerable<sys_module>) moduleRule.Sys_Module.Where<sys_module>((Expression<Func<sys_module, bool>>) (s => s.ModuleIDPath.StartsWith(ModuleIDPath) && s.IsPower == true && s.IsSupperPower == false)));
        }
        else
          coteInfoList2 = this.GetCoteInfoKeyList(authorizegrouppowerList.Select<sys_authorizegrouppower, string>((Func<sys_authorizegrouppower, string>) (s => s.CoteID)).Distinct<string>().ToList<string>().ConvertListToString<string>());
      }
      XmlElement element1 = xmlDocSource.CreateElement("Module");
      element1.SetAttribute("ModuleID", RolePowerKey.Create(objCoteModule.ModuleID).ToKey);
      element1.SetAttribute("ModuleName", objCoteModule.ModuleName);
      if (StringHelper.IsNull(AuthorizeGroupID) || authorizegrouppowerList == null)
      {
        XmlElement element2 = xmlDocSource.CreateElement("Module");
        element2.SetAttribute("ModuleID", RolePowerKey.Create(objCoteModule.ModuleID, objCoteModule.ModuleID, objCoteModule.ModuleID, false, true).ToKey);
        element2.SetAttribute("ModuleName", "***" + objCoteModule.ModuleName + "***所有权限");
        element1.AppendChild((XmlNode) element2);
      }
      foreach (CoteInfo coteInfo in coteInfoList2)
      {
        XmlElement element2 = xmlDocSource.CreateElement("Module");
        element2.SetAttribute("ModuleID", RolePowerKey.Create(objCoteModule.ModuleID, coteInfo.ID, objCoteModule.ModuleID, false).ToKey);
        element2.SetAttribute("ModuleName", coteInfo.Name);
        element1.AppendChild((XmlNode) element2);
        this.CreateEachModeuleXmlElement(xmlDocSource, coteInfo.ID, objCoteModule.ModuleID, objCoteModule, element2, objSys_ModuleList, authorizegrouppowerList, AddSys_ModuleList);
      }
      return element1;
    }

    private void CreateEachModeuleXmlElement(XmlDocument xmlDocSource, string coteID, string CoteModuleID, sys_module objSys_Module, XmlElement objXmlElement, List<sys_module> objSys_ModuleList, List<sys_authorizegrouppower> objCoteRolePowerList, List<sys_module> AddSys_ModuleList)
    {
      string SearchModuleID = objSys_Module.ModuleID;
      if (objSys_Module.IsEdit)
      {
        sys_module sysModule1 = objSys_ModuleList.FirstOrDefault<sys_module>((Func<sys_module, bool>) (s =>
        {
          if (!s.IsEdit && s.ParentModuleID == objSys_Module.ParentModuleID)
            return s.ModuleCode == objSys_Module.ModuleCode;
          return false;
        }));
        if (sysModule1 != null)
          SearchModuleID = sysModule1.ModuleID;
        else if (AddSys_ModuleList != null)
        {
          sys_module sysModule2 = AddSys_ModuleList.FirstOrDefault<sys_module>((Func<sys_module, bool>) (s =>
          {
            if (!s.IsEdit && s.ParentModuleID == objSys_Module.ParentModuleID)
              return s.ModuleCode == objSys_Module.ModuleCode;
            return false;
          }));
          if (sysModule2 != null)
            SearchModuleID = sysModule2.ModuleID;
        }
      }
      List<string> stringList = (List<string>) null;
      if (objCoteRolePowerList != null)
        stringList = objCoteRolePowerList.Where<sys_authorizegrouppower>((Func<sys_authorizegrouppower, bool>) (s => s.CoteID == coteID)).Select<sys_authorizegrouppower, string>((Func<sys_authorizegrouppower, string>) (s => s.ModuleID)).ToList<string>();
      foreach (Sys_Module objSys_Module1 in (IEnumerable<sys_module>) objSys_ModuleList.Where<sys_module>((Func<sys_module, bool>) (s => s.ParentModuleID == SearchModuleID)).OrderBy<Sys_Module, int>((Func<sys_module, int>) (p => p.SortIndex)))
      {
        if (stringList == null || stringList.Contains(objSys_Module1.ModuleID))
        {
          XmlElement element = xmlDocSource.CreateElement("Module");
          element.SetAttribute("ModuleID", RolePowerKey.Create(CoteModuleID, coteID, objSys_Module1.ModuleID, false).ToKey);
          element.SetAttribute("ModuleName", objSys_Module1.ModuleName);
          objXmlElement.AppendChild((XmlNode) element);
          this.CreateEachModeuleXmlElement(xmlDocSource, coteID, CoteModuleID, objSys_Module1, element, objSys_ModuleList, objCoteRolePowerList, AddSys_ModuleList);
        }
      }
    }
  }
}

﻿// Decompiled with JetBrains decompiler
// Type: WTF.Power.PowerCoteTreePower
// Assembly: WTF.Power, Version=1.0.5451.23978, Culture=neutral, PublicKeyToken=null
// MVID: ACB99369-F466-4579-86CC-C2D259CAF828
// Assembly location: C:\F盘\天棣互联\Gao7CMS\SevenFramework\SevenDLL\WTF.Power.dll

using MySql.Data.MySqlClient;
using WTF.Power.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Xml;
using WTF.Framework;
using WTF.Logging;

namespace WTF.Power
{
  public class PowerCoteTreePower
  {
    private string CurrentAuthorizeGroupID = string.Empty;
    private bool CurrentIsSuper;

    public string CoteTableName { get; set; }

    public string IDName { get; set; }

    public string Name { get; set; }

    public string ParentIDName { get; set; }

    public string IDPathName { get; set; }

    public string ConnectionStringName { get; set; }

    public string RootIDValue { get; set; }

    public string DefalutCondition { get; set; }

    public string SortExpression { get; set; }

    public int IDDataType { get; set; }

    public string ModuleTypeID { get; set; }

    public bool IsParentUrl { get; set; }

    public string GetTabeleSql
    {
      get
      {
        return " select  DISTINCT " + this.IDName + "," + this.ParentIDName + "," + this.Name + " from " + this.CoteTableName + " ";
      }
    }

    public PowerCoteTreePower(sys_modulecote objSys_ModuleCote, string moduleTypeID)
    {
      this.CoteTableName = objSys_ModuleCote.CoteTableName;
      this.IDName = objSys_ModuleCote.IDName;
      this.ParentIDName = objSys_ModuleCote.ParentIDName;
      this.IDPathName = objSys_ModuleCote.IDPathName;
      this.Name = objSys_ModuleCote.Name;
      this.ConnectionStringName = objSys_ModuleCote.ConnectionStringName;
      this.RootIDValue = objSys_ModuleCote.RootIDValue.ToLower();
      this.IDDataType = objSys_ModuleCote.IDDataType;
      this.IsParentUrl = objSys_ModuleCote.IsParentUrl;
      this.ModuleTypeID = moduleTypeID;
      this.DefalutCondition = objSys_ModuleCote.Condtion;
      this.DefalutCondition = this.DefalutCondition.Replace("{ModuleTypeID}", this.ModuleTypeID);
      this.SortExpression = objSys_ModuleCote.SortExpression;
    }

    public CoteInfo GetCoteInfoKeyID(string key)
    {
      return this.GetCoteInfoKeyList(key)[0];
    }

    private List<CoteInfo> ConvertCoteInfo(MySqlDataReader reader)
    {
      List<CoteInfo> coteInfoList = new List<CoteInfo>();
      try
      {
        while (reader.Read())
        {
          CoteInfo coteInfo = new CoteInfo();
          if (reader[this.IDName] != DBNull.Value)
            coteInfo.ID = Convert.ToString(reader[this.IDName]);
          if (reader[this.ParentIDName] != DBNull.Value)
            coteInfo.ParentID = Convert.ToString(reader[this.ParentIDName]);
          if (reader[this.Name] != DBNull.Value)
            coteInfo.Name = Convert.ToString(reader[this.Name]);
          coteInfoList.Add(coteInfo);
        }
      }
      catch (Exception ex)
      {
        LogHelper<LogModuleType>.Write(LogModuleType.ModuleLog, ex, "");
        return coteInfoList;
      }
      finally
      {
        reader.Close();
      }
      return coteInfoList;
    }

    public List<CoteInfo> GetCoteInfoKeyList(string key)
    {
      if (string.IsNullOrWhiteSpace(key))
        return new List<CoteInfo>();
      string str1;
      if (this.IDDataType == 1)
      {
        string str2 = "";
        string str3 = key;
        char[] separator = new char[1]{ ',' };
        int num = 1;
        foreach (string input in str3.Split(separator, (StringSplitOptions) num))
        {
          if (input.IsMatch("\\d+"))
            str2 = str2 + input + ",";
        }
        str1 = this.IDName + " in (" + str2.TrimEndComma() + ")";
      }
      else
        str1 = this.IDName + " in (" + key.ConvertStringID() + ")";
      if (!string.IsNullOrWhiteSpace(this.DefalutCondition))
        str1 = str1 + " and " + this.DefalutCondition;
      WTF.Framework.MySqlHelper mySqlHelper = new WTF.Framework.MySqlHelper(this.ConnectionStringName);
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.Append(this.GetTabeleSql);
      if (!string.IsNullOrWhiteSpace(str1))
        stringBuilder.Append(" where " + str1 + " ");
      if (key.Split(',').Length > 1 && !string.IsNullOrWhiteSpace(this.SortExpression))
        stringBuilder.Append(" order by " + this.SortExpression);
      return this.ConvertCoteInfo(mySqlHelper.ExecuteReader(stringBuilder.ToString()));
    }

    public List<CoteInfo> GetAllCoteInfoList()
    {
      StringBuilder stringBuilder = new StringBuilder();
      if (string.IsNullOrWhiteSpace(this.IDPathName))
      {
        stringBuilder.Append(this.GetTabeleSql);
        if (!string.IsNullOrWhiteSpace(this.DefalutCondition))
          stringBuilder.Append(" where " + this.DefalutCondition + " ");
        if (!string.IsNullOrWhiteSpace(this.SortExpression))
          stringBuilder.Append(" order by " + this.SortExpression);
      }
      else
      {
        stringBuilder.AppendLine("SET @IDPath='';");
        string str = this.IDDataType != 1 ? this.IDName + "='" + this.RootIDValue.Trim() + "'" : this.IDName + "=" + this.RootIDValue;
        stringBuilder.AppendLine("SELECT " + this.IDPathName + " INTO @IDPath  FROM " + this.CoteTableName + " WHERE " + str + ";");
        stringBuilder.AppendLine(this.GetTabeleSql + " WHERE   " + this.IDPathName + " LIKE   CONCAT( @IDPath,'%') ");
        if (!string.IsNullOrWhiteSpace(this.DefalutCondition))
          stringBuilder.Append(" AND  " + this.DefalutCondition + " ");
        if (!string.IsNullOrWhiteSpace(this.SortExpression))
          stringBuilder.Append(" order by " + this.SortExpression);
      }
      return this.ConvertCoteInfo(new WTF.Framework.MySqlHelper(this.ConnectionStringName).ExecuteReader(stringBuilder.ToString()));
    }

    public List<CoteInfo> GetAllCoteInfoList(string RootIDValue)
    {
      if (this.IDDataType == 1 && !RootIDValue.IsMatch("\\d+"))
        return new List<CoteInfo>();
      StringBuilder stringBuilder = new StringBuilder();
      if (string.IsNullOrWhiteSpace(this.IDPathName))
      {
        stringBuilder.Append(this.GetTabeleSql);
        if (!string.IsNullOrWhiteSpace(this.DefalutCondition))
          stringBuilder.Append(" where " + this.DefalutCondition + " ");
        if (!string.IsNullOrWhiteSpace(this.SortExpression))
          stringBuilder.Append(" order by " + this.SortExpression);
      }
      else
      {
        stringBuilder.AppendLine("SET @IDPath='';");
        string str = this.IDDataType != 1 ? this.IDName + "='" + RootIDValue.Trim() + "'" : this.IDName + "=" + RootIDValue;
        stringBuilder.AppendLine("SELECT " + this.IDPathName + " INTO @IDPath  FROM " + this.CoteTableName + " WHERE " + str + ";");
        stringBuilder.AppendLine(this.GetTabeleSql + " WHERE   " + this.IDPathName + " LIKE   CONCAT( @IDPath,'%') ");
        if (!string.IsNullOrWhiteSpace(this.DefalutCondition))
          stringBuilder.Append(" AND  " + this.DefalutCondition + " ");
        if (!string.IsNullOrWhiteSpace(this.SortExpression))
          stringBuilder.Append(" order by " + this.SortExpression);
      }
      return this.ConvertCoteInfo(new WTF.Framework.MySqlHelper(this.ConnectionStringName).ExecuteReader(stringBuilder.ToString()));
    }

    protected List<sys_authorizegrouppower> GetAuthorizeGroupCotePower(string AuthorizeGroupID, string moduleID)
    {
      return new UserRule().CurrentEntities.ExecuteStoreQuery<sys_authorizegrouppower>(string.Format(" SELECT *  FROM  sys_authorizegrouppower  WHERE AuthorizeGroupID='{0}'  AND CoteModuleID='{1}'", (object) AuthorizeGroupID, (object) moduleID)).ToList<sys_authorizegrouppower>();
    }

    protected List<sys_rolepower> GetUserCoteRolePower(string userID, string moduleID)
    {
      return new UserRule().CurrentEntities.ExecuteStoreQuery<sys_rolepower>(string.Format(" SELECT  Sys_RolePower.*\r\n                              FROM  Sys_RoleUser \r\n                             ,   Sys_RolePower WHERE Sys_RoleUser.UserID='{0}'   \r\n                             AND Sys_RolePower.CoteModuleID='{1}' and Sys_RoleUser.RoleID=Sys_RolePower.RoleID", (object) userID, (object) moduleID)).ToList<sys_rolepower>();
    }

    public List<CoteInfo> GetCotePowerList(UserInfo objUserInfo, string CoteModuleID)
    {
      List<CoteInfo> source;
      if (objUserInfo.IsSuper)
      {
        source = this.GetAllCoteInfoList();
      }
      else
      {
        List<sys_rolepower> list = this.GetUserCoteRolePower(objUserInfo.UserID, CoteModuleID).ToList<sys_rolepower>();
        if (list.Count == 0)
          return (List<CoteInfo>) null;
        if (list.Any<sys_rolepower>((Func<sys_rolepower, bool>) (s => s.IsCoteSupper)))
        {
          source = new List<CoteInfo>();
          foreach (string RootIDValue in list.Where<sys_rolepower>((Func<sys_rolepower, bool>) (s => s.IsCoteSupper)).Select<sys_rolepower, string>((Func<sys_rolepower, string>) (s => s.CoteID)).Distinct<string>())
            source.AddRange((IEnumerable<CoteInfo>) this.GetAllCoteInfoList(RootIDValue));
          source.AddRange((IEnumerable<CoteInfo>) this.GetCoteInfoKeyList(list.Where<sys_rolepower>((Func<sys_rolepower, bool>) (s => !s.IsCoteSupper)).Select<sys_rolepower, string>((Func<sys_rolepower, string>) (s => s.CoteID)).Distinct<string>().ToList<string>().ConvertListToString<string>()));
        }
        else
          source = this.GetCoteInfoKeyList(list.Select<sys_rolepower, string>((Func<sys_rolepower, string>) (s => s.CoteID)).ToList<string>().ConvertListToString<string>());
      }
      return source.Distinct<CoteInfo>((IEqualityComparer<CoteInfo>) new CoteInfoComparer()).ToList<CoteInfo>();
    }

    public XmlElement GetCotePowerMenuXmlElement(XmlDocument xmlDocSource, UserInfo objUserInfo, sys_module objModule)
    {
      List<sys_rolepower> sysRolePowerList = (List<sys_rolepower>) null;
      this.CurrentIsSuper = objUserInfo.IsSuper;
      List<CoteInfo> source;
      if (objUserInfo.IsSuper)
      {
        source = this.GetAllCoteInfoList();
      }
      else
      {
        sysRolePowerList = this.GetUserCoteRolePower(objUserInfo.UserID, objModule.ModuleID).ToList<sys_rolepower>();
        if (sysRolePowerList.Count == 0)
          return (XmlElement) null;
        if (sysRolePowerList.Any<sys_rolepower>((Func<sys_rolepower, bool>) (s => s.IsCoteSupper)))
        {
          source = new List<CoteInfo>();
          foreach (string RootIDValue in sysRolePowerList.Where<sys_rolepower>((Func<sys_rolepower, bool>) (s => s.IsCoteSupper)).Select<sys_rolepower, string>((Func<sys_rolepower, string>) (s => s.CoteID)).Distinct<string>())
            source.AddRange((IEnumerable<CoteInfo>) this.GetAllCoteInfoList(RootIDValue));
          source.AddRange((IEnumerable<CoteInfo>) this.GetCoteInfoKeyList(sysRolePowerList.Where<sys_rolepower>((Func<sys_rolepower, bool>) (s => !s.IsCoteSupper)).Select<sys_rolepower, string>((Func<sys_rolepower, string>) (s => s.CoteID)).Distinct<string>().ToList<string>().ConvertListToString<string>()));
        }
        else
          source = this.GetCoteInfoKeyList(sysRolePowerList.Select<sys_rolepower, string>((Func<sys_rolepower, string>) (s => s.CoteID)).ToList<string>().ConvertListToString<string>());
      }
      List<CoteInfo> list = source.Distinct<CoteInfo>((IEqualityComparer<CoteInfo>) new CoteInfoComparer()).ToList<CoteInfo>();
      CoteInfo objCoteInfo = list.FirstOrDefault<CoteInfo>((Func<CoteInfo, bool>) (s => s.ID == this.RootIDValue));
      if (objCoteInfo == null)
        return (XmlElement) null;
      string format = "javascript:opentreemodule('{0}','{1}','{2}','{3}');";
      string str = objModule.CommandArgument + (objModule.CommandArgument.IndexOf("?") >= 0 ? "&" : "?") + this.IDName + "={0}&" + this.ParentIDName + "={1}&CoteIsParent={2}&CoteID={0}&CoteModuleID=" + objModule.ModuleID + "&PowerName={3}";
      XmlElement element = xmlDocSource.CreateElement("Module");
      element.SetAttribute("ModuleID", objCoteInfo.ID.ToString());
      element.SetAttribute("ModuleName", objModule.ModuleName);
      element.SetAttribute("ToolTip", objModule.ToolTip);
      element.SetAttribute("ImageUrl", objModule.ImageUrl);
      element.SetAttribute("ModuleLevel", objModule.ModuleLevel.ToString());
      element.SetAttribute("NavigateUrl", string.Format(format, (object) (objModule.ModuleID.ToString() + objCoteInfo.ID), (object) objModule.ImageUrl, (object) string.Format(str, (object) objCoteInfo.ID, (object) objCoteInfo.ParentID, list.Any<CoteInfo>((Func<CoteInfo, bool>) (s => s.ParentID == objCoteInfo.ID)) ? (object) "1" : (object) "0", (object) objCoteInfo.Name).EncryptModuleQuery(), (object) objModule.ModuleName));
      bool isCoteSuper = this.ParentIsCoteSupper(objCoteInfo, list, sysRolePowerList);
      this.CreateCoteChildMenuPowerXmlElement(xmlDocSource, isCoteSuper, sysRolePowerList, objCoteInfo.ID, element, list, str, objModule.ModuleLevel, objModule);
      return element;
    }

    public bool ParentIsCoteSupper(CoteInfo objCoteInfo, List<CoteInfo> objCoteInfoList, List<sys_rolepower> objCoteRolePowerList)
    {
      if (this.CurrentIsSuper || objCoteRolePowerList.Any<sys_rolepower>((Func<sys_rolepower, bool>) (s =>
      {
        if (s.CoteID == objCoteInfo.ID)
          return s.IsCoteSupper;
        return false;
      })))
        return true;
      CoteInfo objCoteInfo1 = objCoteInfoList.FirstOrDefault<CoteInfo>((Func<CoteInfo, bool>) (s => s.ID == objCoteInfo.ParentID));
      if (objCoteInfo1 == null)
        return false;
      return this.ParentIsCoteSupper(objCoteInfo1, objCoteInfoList, objCoteRolePowerList);
    }

    private void CreateCoteChildMenuPowerXmlElement(XmlDocument xmlDocSource, bool isCoteSuper, List<sys_rolepower> objCotePowerList, string ParentID, XmlElement objXmlElement, List<CoteInfo> objCoteInfoList, string coteUrl, int ModuleLevel, sys_module objModule)
    {
      bool flag = true;
      string format = "javascript:opentreemodule('{0}','{1}','{2}','{3}');";
      foreach (CoteInfo coteInfo in objCoteInfoList.Where<CoteInfo>((Func<CoteInfo, bool>) (s => s.ParentID == ParentID)))
      {
        CoteInfo objCoteInfo = coteInfo;
        if (flag)
        {
          if (!this.IsParentUrl)
            objXmlElement.SetNodeAttribute("NavigateUrl", "");
          else if (!isCoteSuper && objCotePowerList.Where<sys_rolepower>((Func<sys_rolepower, bool>) (s => s.CoteID == ParentID)).Count<sys_rolepower>() < 2)
            objXmlElement.SetNodeAttribute("NavigateUrl", "");
          ++ModuleLevel;
          flag = false;
        }
        XmlElement element = xmlDocSource.CreateElement("Module");
        element.SetAttribute("ModuleID", objCoteInfo.ID.ToString());
        element.SetAttribute("ModuleName", objCoteInfo.Name);
        element.SetAttribute("ToolTip", objCoteInfo.Name);
        element.SetAttribute("ImageUrl", objModule.ImageUrl);
        element.SetAttribute("ModuleLevel", ModuleLevel.ToString());
        element.SetAttribute("NavigateUrl", string.Format(format, (object) (objModule.ModuleID.ToString() + objCoteInfo.ID), (object) objModule.ImageUrl, (object) string.Format(coteUrl, (object) objCoteInfo.ID, (object) objCoteInfo.ParentID, objCoteInfoList.Any<CoteInfo>((Func<CoteInfo, bool>) (s => s.ParentID == objCoteInfo.ID)) ? (object) "1" : (object) "0", (object) objCoteInfo.Name).EncryptModuleQuery(), (object) objCoteInfo.Name));
        objXmlElement.AppendChild((XmlNode) element);
        isCoteSuper = this.ParentIsCoteSupper(objCoteInfo, objCoteInfoList, objCotePowerList);
        this.CreateCoteChildMenuPowerXmlElement(xmlDocSource, isCoteSuper, objCotePowerList, objCoteInfo.ID, element, objCoteInfoList, coteUrl, ModuleLevel, objModule);
      }
    }

    public XmlElement GetCotePowerXmlElement(XmlDocument xmlDocSource, string AuthorizeGroupID, sys_module objCoteModule, List<sys_module> objSys_ModuleList, List<sys_module> AddSys_ModuleList)
    {
      this.CurrentAuthorizeGroupID = AuthorizeGroupID;
      List<sys_authorizegrouppower> authorizegrouppowerList = (List<sys_authorizegrouppower>) null;
      List<CoteInfo> source;
      if (StringHelper.IsNull(AuthorizeGroupID))
      {
        source = this.GetAllCoteInfoList();
      }
      else
      {
        authorizegrouppowerList = this.GetAuthorizeGroupCotePower(AuthorizeGroupID, objCoteModule.ModuleID);
        if (authorizegrouppowerList.Count == 0)
          return (XmlElement) null;
        if (authorizegrouppowerList.Any<sys_authorizegrouppower>((Func<sys_authorizegrouppower, bool>) (s => s.IsCoteSupper)))
        {
          source = new List<CoteInfo>();
          foreach (string RootIDValue in authorizegrouppowerList.Where<sys_authorizegrouppower>((Func<sys_authorizegrouppower, bool>) (s => s.IsCoteSupper)).Select<sys_authorizegrouppower, string>((Func<sys_authorizegrouppower, string>) (s => s.CoteID)).Distinct<string>())
            source.AddRange((IEnumerable<CoteInfo>) this.GetAllCoteInfoList(RootIDValue));
          source.AddRange((IEnumerable<CoteInfo>) this.GetCoteInfoKeyList(authorizegrouppowerList.Where<sys_authorizegrouppower>((Func<sys_authorizegrouppower, bool>) (s => !s.IsCoteSupper)).Select<sys_authorizegrouppower, string>((Func<sys_authorizegrouppower, string>) (s => s.CoteID)).Distinct<string>().ToList<string>().ConvertListToString<string>()));
          ModuleRule moduleRule = new ModuleRule();
          string ModuleIDPath = moduleRule.Sys_Module.FirstOrDefault<sys_module>((Expression<Func<Sys_Module, bool>>) (s => s.ModuleID == objCoteModule.ModuleID)).ModuleIDPath;
          objSys_ModuleList.RemoveAll((Predicate<sys_module>) (s => s.ModuleIDPath.StartsWith(ModuleIDPath)));
          objSys_ModuleList.AddRange((IEnumerable<sys_module>) moduleRule.Sys_Module.Where<sys_module>((Expression<Func<Sys_Module, bool>>) (s => s.ModuleIDPath.StartsWith(ModuleIDPath) && s.IsPower == true && s.IsSupperPower == false)));
        }
        else
          source = this.GetCoteInfoKeyList(authorizegrouppowerList.Select<sys_authorizegrouppower, string>((Func<sys_authorizegrouppower, string>) (s => s.CoteID)).Distinct<string>().ToList<string>().ConvertListToString<string>());
      }
      List<CoteInfo> list = source.Distinct<CoteInfo>((IEqualityComparer<CoteInfo>) new CoteInfoComparer()).ToList<CoteInfo>();
      CoteInfo objCoteInfo = list.FirstOrDefault<CoteInfo>((Func<CoteInfo, bool>) (s => s.ID == this.RootIDValue));
      if (objCoteInfo == null)
        return (XmlElement) null;
      XmlElement element1 = xmlDocSource.CreateElement("Module");
      element1.SetAttribute("ModuleID", RolePowerKey.Create(objCoteModule.ModuleID, objCoteInfo.ID, objCoteModule.ModuleID, false).ToKey);
      element1.SetAttribute("ModuleName", objCoteModule.ModuleName);
      bool IsCoteSupper = false;
      if (StringHelper.IsNull(AuthorizeGroupID) || authorizegrouppowerList.Any<sys_authorizegrouppower>((Func<sys_authorizegrouppower, bool>) (s =>
      {
        if (s.CoteID == objCoteInfo.ID)
          return s.IsCoteSupper;
        return false;
      })))
      {
        IsCoteSupper = true;
        XmlElement element2 = xmlDocSource.CreateElement("Module");
        element2.SetAttribute("ModuleID", RolePowerKey.Create(objCoteModule.ModuleID, objCoteInfo.ID, objCoteModule.ModuleID, false, true).ToKey);
        element2.SetAttribute("ModuleName", "***" + objCoteModule.ModuleName + "***所有权限");
        element1.AppendChild((XmlNode) element2);
      }
      if (list.Any<CoteInfo>((Func<CoteInfo, bool>) (s => s.ParentID == objCoteInfo.ID)))
      {
        if (this.IsParentUrl)
          this.CreateEachModeuleXmlElement(xmlDocSource, objCoteInfo.ID, objCoteModule.ModuleID, IsCoteSupper, objCoteModule, element1, objSys_ModuleList, authorizegrouppowerList, AddSys_ModuleList);
      }
      else
        this.CreateEachModeuleXmlElement(xmlDocSource, objCoteInfo.ID, objCoteModule.ModuleID, IsCoteSupper, objCoteModule, element1, objSys_ModuleList, authorizegrouppowerList, AddSys_ModuleList);
      this.CreateCoteChildMenuPowerXmlElement(xmlDocSource, objCoteInfo.ID, objCoteModule, element1, list, objSys_ModuleList, authorizegrouppowerList, AddSys_ModuleList);
      return element1;
    }

    private void CreateCoteChildMenuPowerXmlElement(XmlDocument xmlDocSource, string ParentID, sys_module objCoteModule, XmlElement objXmlElement, List<CoteInfo> objCoteInfoList, List<sys_module> objSys_ModuleList, List<sys_authorizegrouppower> objCoteRolePowerList, List<sys_module> AddSys_ModuleList)
    {
      foreach (CoteInfo coteInfo in objCoteInfoList.Where<CoteInfo>((Func<CoteInfo, bool>) (s => s.ParentID == ParentID)))
      {
        CoteInfo objCoteInfo = coteInfo;
        XmlElement element1 = xmlDocSource.CreateElement("Module");
        element1.SetAttribute("ModuleID", RolePowerKey.Create(objCoteModule.ModuleID, objCoteInfo.ID, objCoteModule.ModuleID, false).ToKey);
        element1.SetAttribute("ModuleName", objCoteInfo.Name);
        objXmlElement.AppendChild((XmlNode) element1);
        bool IsCoteSupper = this.ParentIsCoteSupper(objCoteInfo, objCoteInfoList, objCoteRolePowerList);
        if (objCoteInfoList.Any<CoteInfo>((Func<CoteInfo, bool>) (s => s.ParentID == objCoteInfo.ID)))
        {
          if (StringHelper.IsNull(this.CurrentAuthorizeGroupID) || IsCoteSupper)
          {
            XmlElement element2 = xmlDocSource.CreateElement("Module");
            element2.SetAttribute("ModuleID", RolePowerKey.Create(objCoteModule.ModuleID, objCoteInfo.ID, objCoteModule.ModuleID, false, true).ToKey);
            element2.SetAttribute("ModuleName", "***" + objCoteInfo.Name + "***所有权限");
            element1.AppendChild((XmlNode) element2);
          }
          if (this.IsParentUrl)
            this.CreateEachModeuleXmlElement(xmlDocSource, objCoteInfo.ID, objCoteModule.ModuleID, IsCoteSupper, objCoteModule, element1, objSys_ModuleList, objCoteRolePowerList, AddSys_ModuleList);
        }
        else
          this.CreateEachModeuleXmlElement(xmlDocSource, objCoteInfo.ID, objCoteModule.ModuleID, IsCoteSupper, objCoteModule, element1, objSys_ModuleList, objCoteRolePowerList, AddSys_ModuleList);
        this.CreateCoteChildMenuPowerXmlElement(xmlDocSource, objCoteInfo.ID, objCoteModule, element1, objCoteInfoList, objSys_ModuleList, objCoteRolePowerList, AddSys_ModuleList);
      }
    }

    public bool ParentIsCoteSupper(CoteInfo objCoteInfo, List<CoteInfo> objCoteInfoList, List<sys_authorizegrouppower> objCoteRolePowerList)
    {
      if (StringHelper.IsNull(this.CurrentAuthorizeGroupID) || objCoteRolePowerList.Any<sys_authorizegrouppower>((Func<sys_authorizegrouppower, bool>) (s =>
      {
        if (s.CoteID == objCoteInfo.ID)
          return s.IsCoteSupper;
        return false;
      })))
        return true;
      CoteInfo objCoteInfo1 = objCoteInfoList.FirstOrDefault<CoteInfo>((Func<CoteInfo, bool>) (s => s.ID == objCoteInfo.ParentID));
      if (objCoteInfo1 == null)
        return false;
      return this.ParentIsCoteSupper(objCoteInfo1, objCoteInfoList, objCoteRolePowerList);
    }

    private void CreateEachModeuleXmlElement(XmlDocument xmlDocSource, string coteID, string CoteModuleID, bool IsCoteSupper, sys_module objSys_Module, XmlElement objXmlElement, List<sys_module> objSys_ModuleList, List<sys_authorizegrouppower> objCoteRolePowerList, List<sys_module> AddSys_ModuleList)
    {
      string SearchModuleID = objSys_Module.ModuleID;
      if (objSys_Module.IsEdit)
      {
        sys_module sysModule1 = objSys_ModuleList.FirstOrDefault<sys_module>((Func<sys_module, bool>) (s =>
        {
          if (!s.IsEdit && s.ParentModuleID == objSys_Module.ParentModuleID)
            return s.ModuleCode == objSys_Module.ModuleCode;
          return false;
        }));
        if (sysModule1 != null)
          SearchModuleID = sysModule1.ModuleID;
        else if (AddSys_ModuleList != null)
        {
          sys_module sysModule2 = AddSys_ModuleList.FirstOrDefault<sys_module>((Func<sys_module, bool>) (s =>
          {
            if (!s.IsEdit && s.ParentModuleID == objSys_Module.ParentModuleID)
              return s.ModuleCode == objSys_Module.ModuleCode;
            return false;
          }));
          if (sysModule2 != null)
            SearchModuleID = sysModule2.ModuleID;
        }
      }
      List<string> stringList = (List<string>) null;
      if (objCoteRolePowerList != null && !IsCoteSupper)
        stringList = objCoteRolePowerList.Where<sys_authorizegrouppower>((Func<sys_authorizegrouppower, bool>) (s => s.CoteID == coteID)).Select<sys_authorizegrouppower, string>((Func<sys_authorizegrouppower, string>) (s => s.ModuleID)).ToList<string>();
      foreach (Sys_Module objSys_Module1 in (IEnumerable<sys_module>) objSys_ModuleList.Where<sys_module>((Func<Sys_Module, bool>) (s => s.ParentModuleID == SearchModuleID)).OrderBy<Sys_Module, int>((Func<Sys_Module, int>) (p => p.SortIndex)))
      {
        if (stringList == null || stringList.Contains(objSys_Module1.ModuleID))
        {
          XmlElement element = xmlDocSource.CreateElement("Module");
          element.SetAttribute("ModuleID", RolePowerKey.Create(CoteModuleID, coteID, objSys_Module1.ModuleID, false).ToKey);
          element.SetAttribute("ModuleName", objSys_Module1.ModuleName);
          objXmlElement.AppendChild((XmlNode) element);
          this.CreateEachModeuleXmlElement(xmlDocSource, coteID, CoteModuleID, IsCoteSupper, objSys_Module1, element, objSys_ModuleList, objCoteRolePowerList, AddSys_ModuleList);
        }
      }
    }
  }
}

﻿// Decompiled with JetBrains decompiler
// Type: WTF.Power.PowerRule
// Assembly: WTF.Power, Version=1.0.5451.23978, Culture=neutral, PublicKeyToken=null
// MVID: ACB99369-F466-4579-86CC-C2D259CAF828
// Assembly location: C:\F盘\天棣互联\Gao7CMS\SevenFramework\SevenDLL\WTF.Power.dll

using WTF.Power.Entity;
using System;
using System.Collections.Generic;
using System.Data.Objects;
using System.Linq;
using System.Linq.Expressions;
using System.Xml;
using WTF.Framework;
using WTF.Logging;

namespace WTF.Power
{
  public class PowerRule
  {
    private ModuleEntities objCurrentEntities;

    public ModuleEntities CurrentEntities
    {
      get
      {
        if (this.objCurrentEntities == null)
          this.objCurrentEntities = new ModuleEntities(EntitiesHelper.GetConnectionString<ModuleEntities>("WTF.Power.ConnectionString"));
        return this.objCurrentEntities;
      }
    }

    public ObjectQuery<WTF.Power.Entity.sys_modulecote> Sys_ModuleCote
    {
      get
      {
        return (ObjectQuery<WTF.Power.Entity.sys_modulecote>) this.CurrentEntities.sys_modulecote;
      }
    }

    public ObjectQuery<WTF.Power.Entity.sys_module> Sys_Module
    {
      get
      {
        return (ObjectQuery<WTF.Power.Entity.sys_module>) this.CurrentEntities.sys_module;
      }
    }

    public ObjectQuery<WTF.Power.Entity.sys_modulecheckdata> Sys_ModuleCheckData
    {
      get
      {
        return (ObjectQuery<WTF.Power.Entity.sys_modulecheckdata>) this.CurrentEntities.sys_modulecheckdata;
      }
    }

    public ObjectQuery<WTF.Power.Entity.sys_moduletype> Sys_ModuleType
    {
      get
      {
        return (ObjectQuery<WTF.Power.Entity.sys_moduletype>) this.CurrentEntities.sys_moduletype;
      }
    }

    public ObjectQuery<WTF.Power.Entity.sys_moduledata> Sys_ModuleData
    {
      get
      {
        return (ObjectQuery<WTF.Power.Entity.sys_moduledata>) this.CurrentEntities.sys_moduledata;
      }
    }

    public ObjectQuery<WTF.Power.Entity.sys_modulehelp> Sys_ModuleHelp
    {
      get
      {
        return (ObjectQuery<WTF.Power.Entity.sys_modulehelp>) this.CurrentEntities.sys_modulehelp;
      }
    }

    private void CreatePowerChildElement(XmlDocument xmlDocSource, string AuthorizeGroupID, string ModuleID, string ParentModuleID, bool IsEdit, string ModuleCode, XmlElement objXmlElement, List<WTF.Power.Entity.sys_module> objSys_ModuleList, List<WTF.Power.Entity.sys_module> AddSys_ModuleList)
    {
      if (IsEdit)
      {
        WTF.Power.Entity.sys_module sysModule1 = objSys_ModuleList.FirstOrDefault<WTF.Power.Entity.sys_module>((Func<WTF.Power.Entity.sys_module, bool>) (s =>
        {
          if (!s.IsEdit && s.ParentModuleID == ParentModuleID)
            return s.ModuleCode == ModuleCode;
          return false;
        }));
        if (sysModule1 != null)
          ModuleID = sysModule1.ModuleID;
        else if (AddSys_ModuleList != null)
        {
          WTF.Power.Entity.sys_module sysModule2 = AddSys_ModuleList.FirstOrDefault<WTF.Power.Entity.sys_module>((Func<WTF.Power.Entity.sys_module, bool>) (s =>
          {
            if (!s.IsEdit && s.ParentModuleID == ParentModuleID)
              return s.ModuleCode == ModuleCode;
            return false;
          }));
          if (sysModule2 != null)
            ModuleID = sysModule2.ModuleID;
        }
      }
      foreach (WTF.Power.Entity.sys_module sysModule in (IEnumerable<WTF.Power.Entity.sys_module>) objSys_ModuleList.Where<WTF.Power.Entity.sys_module>((Func<WTF.Power.Entity.sys_module, bool>) (s => s.ParentModuleID == ModuleID)).OrderBy<WTF.Power.Entity.sys_module, int>((Func<WTF.Power.Entity.sys_module, int>) (p => p.SortIndex)))
      {
        WTF.Power.Entity.sys_module objModule = sysModule;
        if (objModule.ModuleCoteID > 0)
        {
          XmlElement coteModeule = this.CreateCoteModeule(xmlDocSource, AuthorizeGroupID, objModule, objSys_ModuleList.Where<WTF.Power.Entity.sys_module>((Func<WTF.Power.Entity.sys_module, bool>) (s => s.ModuleIDPath.StartsWith(objModule.ModuleIDPath))).ToList<WTF.Power.Entity.sys_module>(), AddSys_ModuleList);
          if (coteModeule != null)
            objXmlElement.AppendChild((XmlNode) coteModeule);
        }
        else
        {
          XmlElement element = xmlDocSource.CreateElement("Module");
          element.SetAttribute("ModuleID", RolePowerKey.Create(objModule.ModuleID).ToKey);
          element.SetAttribute("ModuleName", objModule.ModuleName);
          objXmlElement.AppendChild((XmlNode) element);
          if (StringHelper.IsNoNull(objModule.ShareModuleID))
            this.CreateChildShareModeuleXmlElement(xmlDocSource, objModule.ShareModuleID, objModule.ModuleID, objModule.ShareModuleID, objModule.ShareModuleID, objModule.IsEdit, objModule.ModuleCode, element, objSys_ModuleList, AddSys_ModuleList);
          else
            this.CreatePowerChildElement(xmlDocSource, AuthorizeGroupID, objModule.ModuleID, objModule.ParentModuleID, objModule.IsEdit, objModule.ModuleCode, element, objSys_ModuleList, AddSys_ModuleList);
        }
      }
    }

    private void CreateChildShareModeuleXmlElement(XmlDocument xmlDocSource, string ShareModuleID, string CoteID, string ModuleID, string ParentModuleID, bool IsEdit, string ModuleCode, XmlElement objXmlElement, List<WTF.Power.Entity.sys_module> objSys_ModuleList, List<WTF.Power.Entity.sys_module> AddSys_ModuleList)
    {
      if (IsEdit)
      {
        WTF.Power.Entity.sys_module sysModule1 = objSys_ModuleList.FirstOrDefault<WTF.Power.Entity.sys_module>((Func<WTF.Power.Entity.sys_module, bool>) (s =>
        {
          if (!s.IsEdit && s.ParentModuleID == ParentModuleID)
            return s.ModuleCode == ModuleCode;
          return false;
        }));
        if (sysModule1 != null)
          ModuleID = sysModule1.ModuleID;
        else if (AddSys_ModuleList != null)
        {
          WTF.Power.Entity.sys_module sysModule2 = AddSys_ModuleList.FirstOrDefault<WTF.Power.Entity.sys_module>((Func<WTF.Power.Entity.sys_module, bool>) (s =>
          {
            if (!s.IsEdit && s.ParentModuleID == ParentModuleID)
              return s.ModuleCode == ModuleCode;
            return false;
          }));
          if (sysModule2 != null)
            ModuleID = sysModule2.ModuleID;
        }
      }
      foreach (WTF.Power.Entity.sys_module sysModule in (IEnumerable<WTF.Power.Entity.sys_module>) objSys_ModuleList.Where<WTF.Power.Entity.sys_module>((Func<WTF.Power.Entity.sys_module, bool>) (s => s.ParentModuleID == ModuleID)).OrderBy<WTF.Power.Entity.sys_module, int>((Func<WTF.Power.Entity.sys_module, int>) (p => p.SortIndex)))
      {
        XmlElement element = xmlDocSource.CreateElement("Module");
        element.SetAttribute("ModuleID", RolePowerKey.Create(ShareModuleID, CoteID, sysModule.ModuleID, true).ToKey);
        element.SetAttribute("ModuleName", sysModule.ModuleName);
        objXmlElement.AppendChild((XmlNode) element);
        this.CreateChildShareModeuleXmlElement(xmlDocSource, ShareModuleID, CoteID, sysModule.ModuleID, sysModule.ParentModuleID, sysModule.IsEdit, sysModule.ModuleCode, element, objSys_ModuleList, AddSys_ModuleList);
      }
    }

    private XmlElement CreateCoteModeule(XmlDocument xmlDocSource, string AuthorizeGroupID, WTF.Power.Entity.sys_module objSys_Module, List<WTF.Power.Entity.sys_module> objSys_ModuleList, List<WTF.Power.Entity.sys_module> AddSys_ModuleList)
    {
      try
      {
        WTF.Power.Entity.sys_modulecote objSys_ModuleCote = this.Sys_ModuleCote.FirstOrDefault<WTF.Power.Entity.sys_moduleCote>((Expression<Func<WTF.Power.Entity.sys_modulecote, bool>>) (s => s.ModuleCoteID == objSys_Module.ModuleCoteID));
        if (objSys_ModuleCote == null || StringHelper.IsNull(objSys_ModuleCote.CoteTableName))
          return (XmlElement) null;
        if (StringHelper.IsNull(objSys_ModuleCote.ParentIDName) && StringHelper.IsNull(objSys_ModuleCote.RootIDValue) && StringHelper.IsNull(objSys_ModuleCote.IDPathName))
          return new PowerCotePower(objSys_ModuleCote, objSys_Module.ModuleTypeID).GetCotePowerXmlElement(xmlDocSource, AuthorizeGroupID, objSys_Module, objSys_ModuleList, AddSys_ModuleList);
        return new PowerCoteTreePower(objSys_ModuleCote, objSys_Module.ModuleTypeID).GetCotePowerXmlElement(xmlDocSource, AuthorizeGroupID, objSys_Module, objSys_ModuleList, AddSys_ModuleList);
      }
      catch (Exception ex)
      {
        LogHelper<LogModuleType>.Write(LogModuleType.ModuleLog, ex, "");
        return (XmlElement) null;
      }
    }

    public string GetPowerCoteTreeFunctionModuleXml(string moduleTypeID, string ModuleCode)
    {
      UserRule userRule = new UserRule();
      List<ModuleCoteInfo> moduleCoteInfoList = new List<ModuleCoteInfo>();
      List<WTF.Power.Entity.sys_module> list = this.CurrentEntities.GetPowerFunctionModuleByID(moduleTypeID, ModuleCode, userRule.CurrentUser.UserID, new bool?(true)).ToList<WTF.Power.Entity.sys_module>();
      WTF.Power.Entity.sys_module objSys_Module = this.CurrentEntities.sys_module.FirstOrDefault<WTF.Power.Entity.sys_module>((Expression<Func<WTF.Power.Entity.sys_module, bool>>) (s => s.ModuleTypeID == moduleTypeID && s.ModuleCode == ModuleCode));
      XmlDocument xmlDocSource = new XmlDocument();
      if (objSys_Module.ModuleCoteID > 0)
      {
        XmlElement cotePowerXmlElement = this.GetCotePowerXmlElement(xmlDocSource, objSys_Module, userRule.CurrentUser);
        if (cotePowerXmlElement != null)
        {
          xmlDocSource.AppendChild((XmlNode) cotePowerXmlElement);
        }
        else
        {
          XmlElement element = xmlDocSource.CreateElement("Module");
          element.SetAttribute("ModuleID", objSys_Module.ModuleID.ToString());
          element.SetAttribute("ModuleName", objSys_Module.ModuleName);
          element.SetAttribute("ToolTip", objSys_Module.ToolTip);
          element.SetAttribute("ImageUrl", objSys_Module.ImageUrl);
          element.SetAttribute("ModuleLevel", objSys_Module.ModuleLevel.ToString());
          element.SetAttribute("NavigateUrl", "");
          xmlDocSource.AppendChild((XmlNode) cotePowerXmlElement);
        }
      }
      else
      {
        XmlElement element = xmlDocSource.CreateElement("Module");
        element.SetAttribute("ModuleID", objSys_Module.ModuleID.ToString());
        element.SetAttribute("ModuleName", objSys_Module.ModuleName);
        element.SetAttribute("ToolTip", objSys_Module.ToolTip);
        element.SetAttribute("ImageUrl", objSys_Module.ImageUrl);
        element.SetAttribute("ModuleLevel", objSys_Module.ModuleLevel.ToString());
        element.SetAttribute("NavigateUrl", "");
        xmlDocSource.AppendChild((XmlNode) element);
        this.CreatePowerTreeXmlMenuElement(xmlDocSource, objSys_Module.ModuleID, element, list);
      }
      return xmlDocSource.InnerXml;
    }

    public IEnumerable<ModuleCoteInfo> GetPowerCoteTreeFunctionModule(string moduleTypeID)
    {
      UserRule userRule = new UserRule();
      List<ModuleCoteInfo> moduleCoteInfoList = new List<ModuleCoteInfo>();
      List<WTF.Power.Entity.sys_module> list = this.CurrentEntities.GetPowerFunctionModuleByID(moduleTypeID, "", userRule.CurrentUser.UserID, new bool?(true)).ToList<WTF.Power.Entity.sys_module>();
      foreach (WTF.Power.Entity.sys_module objSys_Module in (IEnumerable<WTF.Power.Entity.sys_module>) list.Where<WTF.Power.Entity.sys_module>((Func<WTF.Power.Entity.sys_module, bool>) (s => s.ParentModuleID == moduleTypeID)).OrderBy<WTF.Power.Entity.sys_module, int>((Func<WTF.Power.Entity.sys_module, int>) (s => s.SortIndex)))
      {
        ModuleCoteInfo moduleCoteInfo = new ModuleCoteInfo()
        {
          ModuleID = objSys_Module.ModuleID,
          ImageUrl = objSys_Module.ImageUrl,
          ModuleName = objSys_Module.ModuleName,
          PowXml = "",
          SortIndex = objSys_Module.SortIndex,
          ToolTip = objSys_Module.ToolTip
        };
        XmlDocument xmlDocSource = new XmlDocument();
        XmlElement element = xmlDocSource.CreateElement("Module");
        element.SetAttribute("ModuleID", moduleCoteInfo.ModuleID.ToString());
        element.SetAttribute("ModuleName", moduleCoteInfo.ModuleName);
        element.SetAttribute("ToolTip", moduleCoteInfo.ToolTip);
        element.SetAttribute("ImageUrl", moduleCoteInfo.ImageUrl);
        element.SetAttribute("ModuleLevel", objSys_Module.ModuleLevel.ToString());
        element.SetAttribute("NavigateUrl", "");
        xmlDocSource.AppendChild((XmlNode) element);
        if (objSys_Module.ModuleCoteID > 0)
        {
          XmlElement cotePowerXmlElement = this.GetCotePowerXmlElement(xmlDocSource, objSys_Module, userRule.CurrentUser);
          if (cotePowerXmlElement != null)
            element.AppendChild((XmlNode) cotePowerXmlElement);
        }
        else
          this.CreatePowerTreeXmlMenuElement(xmlDocSource, moduleCoteInfo.ModuleID, element, list);
        moduleCoteInfo.PowXml = xmlDocSource.InnerXml;
        moduleCoteInfoList.Add(moduleCoteInfo);
      }
      return (IEnumerable<ModuleCoteInfo>) moduleCoteInfoList;
    }

    public XmlElement GetCotePowerXmlElement(XmlDocument xmlDocSource, WTF.Power.Entity.sys_module objSys_Module, UserInfo objUserInfo)
    {
      try
      {
        WTF.Power.Entity.sys_modulecote objSys_ModuleCote = this.Sys_ModuleCote.FirstOrDefault<WTF.Power.Entity.sys_moduleCote>((Expression<Func<WTF.Power.Entity.sys_moduleCote, bool>>) (s => s.ModuleCoteID == objSys_Module.ModuleCoteID));
        if (objSys_ModuleCote == null || StringHelper.IsNull(objSys_ModuleCote.CoteTableName))
          return (XmlElement) null;
        if (StringHelper.IsNull(objSys_ModuleCote.ParentIDName) && StringHelper.IsNull(objSys_ModuleCote.RootIDValue) && StringHelper.IsNull(objSys_ModuleCote.IDPathName))
          return new PowerCotePower(objSys_ModuleCote, objSys_Module.ModuleTypeID).GetCotePowerMenuXmlElement(xmlDocSource, objUserInfo, objSys_Module);
        return new PowerCoteTreePower(objSys_ModuleCote, objSys_Module.ModuleTypeID).GetCotePowerMenuXmlElement(xmlDocSource, objUserInfo, objSys_Module);
      }
      catch (Exception ex)
      {
        LogHelper<LogModuleType>.Write(LogModuleType.ModuleLog, ex, "");
        return (XmlElement) null;
      }
    }

    private void CreatePowerTreeXmlMenuElement(XmlDocument xmlDocSource, string ModuleID, XmlElement objXmlElement, List<WTF.Power.Entity.sys_module> objSys_ModuleList)
    {
      string format = "javascript:opentreemodule('{0}','{1}','{2}','{3}');";
      foreach (WTF.Power.Entity.sys_module objSys_Module in (IEnumerable<WTF.Power.Entity.sys_module>) objSys_ModuleList.Where<WTF.Power.Entity.sys_module>((Func<WTF.Power.Entity.sys_module, bool>) (s => s.ParentModuleID == ModuleID)).OrderBy<WTF.Power.Entity.sys_module, int>((Func<WTF.Power.Entity.sys_module, int>) (p => p.SortIndex)))
      {
        if (objSys_Module.ModuleCoteID > 0)
        {
          UserRule userRule = new UserRule();
          XmlElement cotePowerXmlElement = this.GetCotePowerXmlElement(xmlDocSource, objSys_Module, userRule.CurrentUser);
          if (cotePowerXmlElement != null)
            objXmlElement.AppendChild((XmlNode) cotePowerXmlElement);
        }
        else
        {
          XmlElement element = xmlDocSource.CreateElement("Module");
          element.SetAttribute("ModuleID", objSys_Module.ModuleID.ToString());
          element.SetAttribute("ModuleName", objSys_Module.ModuleName);
          element.SetAttribute("ToolTip", objSys_Module.ToolTip);
          element.SetAttribute("ImageUrl", objSys_Module.ImageUrl);
          element.SetAttribute("ModuleLevel", objSys_Module.ModuleLevel.ToString());
          if (StringHelper.IsNull(objSys_Module.ShareModuleID))
          {
            string url = objSys_Module.CommandArgument + (objSys_Module.CommandArgument.IndexOf("?") >= 0 ? "&" : "?") + "PowerID=" + objSys_Module.ModuleID + "&PowerName=" + objSys_Module.ModuleName + (objSys_Module.CoteKeyID > 0 ? "&CoteKeyID=" + (object) objSys_Module.CoteKeyID : "");
            XmlElement xmlElement = element;
            string name = "NavigateUrl";
            string str;
            if (!StringHelper.IsNull(objSys_Module.CommandArgument))
              str = string.Format(format, (object) objSys_Module.ModuleID, (object) objSys_Module.ImageUrl, (object) url.EncryptModuleQuery(), (object) objSys_Module.ModuleName);
            else
              str = "";
            xmlElement.SetAttribute(name, str);
          }
          else
          {
            string url = objSys_Module.CommandArgument + (objSys_Module.CommandArgument.IndexOf("?") >= 0 ? "&" : "?") + "CoteID=" + objSys_Module.ModuleID + "&CoteModuleID=" + objSys_Module.ShareModuleID + "&PowerName=" + objSys_Module.ModuleName + (objSys_Module.CoteKeyID > 0 ? "&CoteKeyID=" + (object) objSys_Module.CoteKeyID : "");
            XmlElement xmlElement = element;
            string name = "NavigateUrl";
            string str;
            if (!StringHelper.IsNull(objSys_Module.CommandArgument))
              str = string.Format(format, (object) objSys_Module.ModuleID, (object) objSys_Module.ImageUrl, (object) url.EncryptModuleQuery(), (object) objSys_Module.ModuleName);
            else
              str = "";
            xmlElement.SetAttribute(name, str);
          }
          objXmlElement.AppendChild((XmlNode) element);
          this.CreatePowerTreeXmlMenuElement(xmlDocSource, objSys_Module.ModuleID, element, objSys_ModuleList);
        }
      }
    }

    public string GetPowerTreexXmlText(string moduleTypeID, bool isSupper = false)
    {
      UserRule userRule = new UserRule();
      XmlDocument xmlDocSource = new XmlDocument();
      WTF.Power.Entity.sys_moduletype sysModuleType = this.CurrentEntities.sys_moduletype.FirstOrDefault<WTF.Power.Entity.sys_moduletype>((Expression<Func<WTF.Power.Entity.sys_moduletype, bool>>) (s => s.ModuleTypeID == moduleTypeID));
      List<WTF.Power.Entity.sys_module> list;
      if (isSupper)
        list = this.CurrentEntities.sys_module.Where<WTF.Power.Entity.sys_module>((Expression<Func<WTF.Power.Entity.sys_module, bool>>) (s => s.ModuleTypeID == moduleTypeID && s.IsPower == true)).ToList<WTF.Power.Entity.sys_module>();
      else
        list = this.CurrentEntities.sys_module.Where<WTF.Power.Entity.sys_module>((Expression<Func<WTF.Power.Entity.sys_module, bool>>) (s => s.ModuleTypeID == moduleTypeID && s.IsPower == true && s.IsSupperPower == false)).ToList<WTF.Power.Entity.sys_module>();
      XmlElement element = xmlDocSource.CreateElement("Module");
      element.SetAttribute("ModuleID", RolePowerKey.Create(sysModuleType.ModuleTypeID).ToKey);
      element.SetAttribute("ModuleName", sysModuleType.ModuleTypeName);
      xmlDocSource.AppendChild((XmlNode) element);
      this.CreatePowerChildElement(xmlDocSource, "", sysModuleType.ModuleTypeID, Guid.Empty.ToString(), false, "", element, list, (List<WTF.Power.Entity.sys_module>) null);
      return xmlDocSource.InnerXml;
    }

    public string GetPowerTreexXmlText(string moduleTypeID, string AuthorizeGroupID)
    {
      UserRule userRule = new UserRule();
      XmlDocument xmlDocSource = new XmlDocument();
      WTF.Power.Entity.sys_moduletype sysModuleType = this.CurrentEntities.sys_moduletype.First<WTF.Power.Entity.sys_moduletype>((Expression<Func<WTF.Power.Entity.sys_moduletype, bool>>) (s => s.ModuleTypeID == moduleTypeID));
      XmlElement element = xmlDocSource.CreateElement("Module");
      element.SetAttribute("ModuleID", RolePowerKey.Create(sysModuleType.ModuleTypeID).ToKey);
      element.SetAttribute("ModuleName", sysModuleType.ModuleTypeName);
      xmlDocSource.AppendChild((XmlNode) element);
      List<WTF.Power.Entity.sys_module> list = this.CurrentEntities.GetAuthorizeGroupPowerModule(AuthorizeGroupID, moduleTypeID).ToList<WTF.Power.Entity.sys_module>();
      List<string> editModuleModuleList = list.Where<WTF.Power.Entity.sys_module>((Func<WTF.Power.Entity.sys_module, bool>) (s => s.IsEdit)).Select<WTF.Power.Entity.sys_module, string>((Func<WTF.Power.Entity.sys_module, string>) (s => s.ModuleCode)).ToList<string>();
      List<WTF.Power.Entity.sys_module> AddSys_ModuleList = new List<WTF.Power.Entity.sys_module>();
      if (editModuleModuleList.Count > 0)
        AddSys_ModuleList = this.CurrentEntities.sys_module.Where<WTF.Power.Entity.sys_module>((Expression<Func<WTF.Power.Entity.sys_module, bool>>) (s => editModuleModuleList.Contains(s.ModuleCode) && s.IsEdit == false)).ToList<WTF.Power.Entity.sys_module>();
      this.CreatePowerChildElement(xmlDocSource, AuthorizeGroupID, sysModuleType.ModuleTypeID, Guid.Empty.ToString(), false, "", element, list, AddSys_ModuleList);
      return xmlDocSource.InnerXml;
    }

    public void SaveChanges()
    {
      this.objCurrentEntities.SaveChanges();
    }
  }
}

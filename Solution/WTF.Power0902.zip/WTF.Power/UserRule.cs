﻿// Decompiled with JetBrains decompiler
// Type: WTF.Power.UserRule
// Assembly: WTF.Power, Version=1.0.5451.23978, Culture=neutral, PublicKeyToken=null
// MVID: ACB99369-F466-4579-86CC-C2D259CAF828
// Assembly location: C:\F盘\天棣互联\Gao7CMS\SevenFramework\SevenDLL\WTF.Power.dll

using WTF.Power.Entity;
using System;
using System.Collections.Generic;
using System.Data.Objects;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Web.Security;
using WTF.Framework;
using WTF.Logging;

namespace WTF.Power
{
    public class UserRule
    {
        private UserEntities objCurrentEntities;

        public ObjectQuery<WTF.Power.Entity.sys_authorizegroup> sys_authorizegroup
        {
            get
            {
                return (ObjectQuery<WTF.Power.Entity.sys_authorizegroup>)this.CurrentEntities.sys_authorizegroup;
            }
        }

        public ObjectQuery<WTF.Power.Entity.sys_authorizegrouppower> sys_authorizegrouppower
        {
            get
            {
                return (ObjectQuery<WTF.Power.Entity.sys_authorizegrouppower>)this.CurrentEntities.sys_authorizegrouppower;
            }
        }

        public UserInfo CurrentUser
        {
            get
            {
                if (SysVariable.CurrentContext.Request.IsAuthenticated)
                {
                    if (SysVariable.CurrentContext != null && SysVariable.CurrentContext.Session["CurrentUser"] == null)
                    {
                        this.LoginRule(SysVariable.CurrentContext.User.Identity.Name);
                        return (UserInfo)SysVariable.CurrentContext.Session["CurrentUser"];
                    }
                    if (SysVariable.CurrentContext != null && SysVariable.CurrentContext.Session["CurrentUser"] != null)
                    {
                        if (((UserInfo)SysVariable.CurrentContext.Session["CurrentUser"]).Account.ToLower() == SysVariable.CurrentContext.User.Identity.Name.ToLower())
                            return (UserInfo)SysVariable.CurrentContext.Session["CurrentUser"];
                        SysVariable.CurrentContext.Session.Clear();
                        this.LoginRule(SysVariable.CurrentContext.User.Identity.Name);
                        return (UserInfo)SysVariable.CurrentContext.Session["CurrentUser"];
                    }
                }
                UserInfo userInfo1 = new UserInfo();
                if (SysVariable.CurrentContext.Session["CurrentUser"] != null)
                {
                    UserInfo userInfo2 = (UserInfo)SysVariable.CurrentContext.Session["CurrentUser"];
                    if (userInfo2.UserID == Guid.Empty.ToString())
                        return userInfo2;
                }
                UserInfo userInfo3 = new UserInfo(Guid.Empty.ToString(), "Anonymous", "游客", "游客", 0, "", -1, "", RequestHelper.UserHostAddress, false, DateTime.Now);
                string ModuleTypeID = ((ModulePage)SysVariable.CurrentPage).ModuleTypeID.ToString();
                string GuidEmpty = Guid.Empty.ToString();
                userInfo3.RoleID = this.Sys_RoleUser.Where<WTF.Power.Entity.sys_roleuser>((Expression<Func<WTF.Power.Entity.sys_roleuser, bool>>)(s => s.UserID == GuidEmpty && s.Sys_Role.IsLockOut == false && s.Sys_Role.ModuleTypeID == ModuleTypeID)).OrderBy<WTF.Power.Entity.sys_roleuser, string>((Expression<Func<WTF.Power.Entity.sys_roleuser, string>>)(S => S.RoleID)).Select<WTF.Power.Entity.sys_roleuser, string>((Expression<Func<WTF.Power.Entity.sys_roleuser, string>>)(s => s.RoleID)).ToList<string>();
                SysVariable.CurrentContext.Session["CurrentUser"] = (object)userInfo3;
                SysVariable.CurrentContext.Session["SignatureID"] = (object)userInfo3.UserID;
                return userInfo3;
            }
        }

        public UserEntities CurrentEntities
        {
            get
            {
                if (this.objCurrentEntities == null)
                    this.objCurrentEntities = new UserEntities(EntitiesHelper.GetConnectionString<UserEntities>("WTF.Power.ConnectionString"));
                return this.objCurrentEntities;
            }
        }

        public ObjectQuery<WTF.Power.Entity.sys_user> Sys_User
        {
            get
            {
                return (ObjectQuery<WTF.Power.Entity.sys_user>)this.CurrentEntities.sys_user;
            }
        }

        public ObjectQuery<WTF.Power.Entity.sys_roleuser> Sys_RoleUser
        {
            get
            {
                return (ObjectQuery<WTF.Power.Entity.sys_roleuser>)this.CurrentEntities.sys_roleuser;
            }
        }

        public ObjectQuery<WTF.Power.Entity.sys_roledata> Sys_RoleData
        {
            get
            {
                return (ObjectQuery<WTF.Power.Entity.sys_roledata>)this.CurrentEntities.sys_roledata;
            }
        }

        public ObjectQuery<WTF.Power.Entity.sys_rolecote> Sys_RoleCote
        {
            get
            {
                return (ObjectQuery<WTF.Power.Entity.sys_rolecote>)this.CurrentEntities.sys_rolecote;
            }
        }

        public ObjectQuery<WTF.Power.Entity.sys_rolecotepower> Sys_RoleCotePower
        {
            get
            {
                return (ObjectQuery<WTF.Power.Entity.sys_rolecotepower>)this.CurrentEntities.sys_rolecotepower;
            }
        }

        public ObjectQuery<WTF.Power.Entity.sys_rolepower> Sys_RolePower
        {
            get
            {
                return (ObjectQuery<WTF.Power.Entity.sys_rolepower>)this.CurrentEntities.sys_rolepower;
            }
        }

        public ObjectQuery<WTF.Power.Entity.sys_modulerole> Sys_ModuleRole
        {
            get
            {
                return (ObjectQuery<WTF.Power.Entity.sys_modulerole>)this.CurrentEntities.sys_modulerole;
            }
        }

        public ObjectQuery<WTF.Power.Entity.sys_role> Sys_Role
        {
            get
            {
                return (ObjectQuery<WTF.Power.Entity.sys_role>)this.CurrentEntities.sys_role;
            }
        }

        public ObjectQuery<WTF.Power.Entity.sys_usertype> Sys_UserType
        {
            get
            {
                return (ObjectQuery<WTF.Power.Entity.sys_usertype>)this.CurrentEntities.sys_usertype;
            }
        }

        public void Insertauthorizegroup(WTF.Power.Entity.sys_authorizegroup objsys_authorizegroup)
        {
            objsys_authorizegroup.AuthorizeGroupName.CheckIsNull<string>("请输入授权组名", "ModuleLog");
            this.CurrentEntities.sys_authorizegroup.Add(objsys_authorizegroup);
            this.CurrentEntities.SaveChanges();
        }

        public void Updateauthorizegroup(WTF.Power.Entity.sys_authorizegroup objsys_authorizegroup)
        {
            objsys_authorizegroup.AuthorizeGroupName.CheckIsNull<string>("请输入授权组名", "ModuleLog");
            this.CurrentEntities.SaveChanges();
        }

        public void DeleteauthorizegroupByKey(string primaryKey)
        {
            this.CurrentEntities.sys_authorizegroup.DeleteDataPrimaryKey<WTF.Power.Entity.sys_authorizegroup>(primaryKey);
        }

        public void Insertauthorizegrouppower(WTF.Power.Entity.sys_authorizegrouppower objsys_authorizegrouppower)
        {
            this.CurrentEntities.sys_authorizegrouppower.Add(objsys_authorizegrouppower);
            this.CurrentEntities.SaveChanges();
        }

        public void Updateauthorizegrouppower(WTF.Power.Entity.sys_authorizegrouppower objsys_authorizegrouppower)
        {
            this.CurrentEntities.SaveChanges();
        }

        public void DeleteauthorizegrouppowerByKey(string primaryKey)
        {
            this.CurrentEntities.sys_authorizegrouppower.DeleteDataPrimaryKey<WTF.Power.Entity.sys_authorizegrouppower>(primaryKey);
        }

        public List<RolePowerKey> GetAuthorizeGroupPower(string AuthorizeGroupID)
        {
            ModuleRule moduleRule = new ModuleRule();
            return this.CurrentEntities.sys_authorizegrouppower.Where<WTF.Power.Entity.sys_authorizegrouppower>((Expression<Func<WTF.Power.Entity.sys_authorizegrouppower, bool>>)(s => s.AuthorizeGroupID == AuthorizeGroupID)).Select<WTF.Power.Entity.sys_authorizegrouppower, RolePowerKey>((Expression<Func<WTF.Power.Entity.sys_authorizegrouppower, RolePowerKey>>)(s => new RolePowerKey()
            {
                CoteID = s.CoteID,
                CoteModuleID = s.CoteModuleID,
                ModuleID = s.ModuleID,
                IsShare = s.IsShare,
                IsCoteSupper = s.IsCoteSupper
            })).Distinct<RolePowerKey>().ToList<RolePowerKey>();
        }

        public void RevertAuthorizeGroupPower(string AuthorizeGroupID)
        {
            this.CurrentEntities.ExecuteStoreCommand("  delete from sys_role where AuthorizeGroupID='" + AuthorizeGroupID + "'");
        }

        public void UpdateAuthorizeGroupPower(string AuthorizeGroupID, List<RolePowerKey> objRolePowerKeyList)
        {
            foreach (string str in objRolePowerKeyList.Where<RolePowerKey>((Func<RolePowerKey, bool>)(s =>
            {
                if (s.CoteModuleID != "")
                    return !s.IsShare;
                return false;
            })).Select<RolePowerKey, string>((Func<RolePowerKey, string>)(s => s.CoteModuleID)).Distinct<string>().ToList<string>())
            {
                string coteModuleID = str;
                if (!objRolePowerKeyList.Any<RolePowerKey>((Func<RolePowerKey, bool>)(s =>
                {
                    if (s.ModuleID == coteModuleID)
                        return s.CoteModuleID == "";
                    return false;
                })))
                    objRolePowerKeyList.Add(RolePowerKey.Create(coteModuleID));
            }
            List<RolePowerKey> source = new List<RolePowerKey>();
            ObjectSet<WTF.Power.Entity.sys_authorizegrouppower> authorizegrouppower1 = this.CurrentEntities.sys_authorizegrouppower;
            Expression<Func<WTF.Power.Entity.sys_authorizegrouppower, bool>> predicate = (Expression<Func<WTF.Power.Entity.sys_authorizegrouppower, bool>>)(s => s.AuthorizeGroupID == AuthorizeGroupID);
            foreach (WTF.Power.Entity.sys_authorizegrouppower authorizegrouppower2 in (IEnumerable<WTF.Power.Entity.sys_authorizegrouppower>)authorizegrouppower1.Where<WTF.Power.Entity.sys_authorizegrouppower>(predicate))
            {
                WTF.Power.Entity.sys_authorizegrouppower objgrouppower = authorizegrouppower2;
                RolePowerKey rolePowerKey = objRolePowerKeyList.FirstOrDefault<RolePowerKey>((Func<RolePowerKey, bool>)(s =>
                {
                    if (s.ModuleID == objgrouppower.ModuleID && s.CoteModuleID == objgrouppower.CoteModuleID && (s.CoteID == objgrouppower.CoteID && s.IsShare == objgrouppower.IsShare))
                        return s.IsCoteSupper == objgrouppower.IsCoteSupper;
                    return false;
                }));
                if (rolePowerKey != null)
                {
                    objRolePowerKeyList.Remove(rolePowerKey);
                }
                else
                {
                    this.CurrentEntities.DeleteObject((object)objgrouppower);
                    source.Add(RolePowerKey.Create(objgrouppower.CoteModuleID, objgrouppower.CoteID, objgrouppower.ModuleID, objgrouppower.IsShare, objgrouppower.IsCoteSupper));
                }
            }
            this.CurrentEntities.SaveChanges();
            foreach (RolePowerKey objRolePowerKey in objRolePowerKeyList)
                this.CurrentEntities.AddTosys_authorizegrouppower(new WTF.Power.Entity.sys_authorizegrouppower()
                {
                    AuthorizeGroupID = AuthorizeGroupID,
                    ModuleID = objRolePowerKey.ModuleID,
                    CoteID = objRolePowerKey.CoteID,
                    CoteModuleID = objRolePowerKey.CoteModuleID,
                    IsShare = objRolePowerKey.IsShare,
                    IsCoteSupper = objRolePowerKey.IsCoteSupper,
                    AuthorizeGroupPowerID = Guid.NewGuid().ToString()
                });
            this.CurrentEntities.SaveChanges();
            if (!this.sys_authorizegroup.First<WTF.Power.Entity.sys_authorizegroup>((Expression<Func<WTF.Power.Entity.sys_authorizegroup, bool>>)(s => s.AuthorizeGroupID == AuthorizeGroupID)).IsRevertPower)
                return;
            StringBuilder stringBuilder = new StringBuilder();
            if (source.Count > 0)
            {
                int num1 = 0;
                List<string> list1 = source.Where<RolePowerKey>((Func<RolePowerKey, bool>)(s =>
                {
                    if (s.CoteModuleID != "")
                        return s.IsCoteSupper;
                    return false;
                })).Select<RolePowerKey, string>((Func<RolePowerKey, string>)(s => s.CoteModuleID)).Distinct<string>().ToList<string>();
                source.Where<RolePowerKey>((Func<RolePowerKey, bool>)(s =>
                {
                    if (s.CoteModuleID != "")
                        return !s.IsShare;
                    return false;
                })).Select<RolePowerKey, string>((Func<RolePowerKey, string>)(s => s.CoteModuleID)).Distinct<string>().ToList<string>();
                List<string> CoteModuleIDSupperList = this.CurrentEntities.sys_authorizegrouppower.Where<WTF.Power.Entity.sys_authorizegrouppower>((Expression<Func<WTF.Power.Entity.sys_authorizegrouppower, bool>>)(s => s.CoteModuleID != "" && s.IsCoteSupper == true)).ToList<WTF.Power.Entity.sys_authorizegrouppower>().Select<WTF.Power.Entity.sys_authorizegrouppower, string>((Func<WTF.Power.Entity.sys_authorizegrouppower, string>)(s => s.CoteModuleID)).Distinct<string>().ToList<string>();
                source.RemoveAll((Predicate<RolePowerKey>)(s => CoteModuleIDSupperList.Contains(s.CoteModuleID)));
                list1.RemoveAll((Predicate<string>)(s => CoteModuleIDSupperList.Contains(s)));
                foreach (RolePowerKey rolePowerKey in source.Where<RolePowerKey>((Func<RolePowerKey, bool>)(s => s.CoteModuleID != "")))
                {
                    ++num1;
                    stringBuilder.AppendLine(" delete from sys_rolepower where ModuleID='" + rolePowerKey.ModuleID + "' and  CoteID='" + rolePowerKey.CoteID + "' and   CoteModuleID='" + rolePowerKey.CoteModuleID + "' and IsShare=" + (rolePowerKey.IsShare ? "1" : "0") + " and IsCoteSupper=" + (rolePowerKey.IsCoteSupper ? "1" : "0") + " and  Sys_RolePower.Roleid in (select Roleid from  Sys_Role where  Sys_Role.AuthorizeGroupID='" + AuthorizeGroupID + "');");
                    if (num1 == 50)
                    {
                        this.CurrentEntities.ExecuteStoreCommand(stringBuilder.ToString());
                        stringBuilder.Clear();
                        num1 = 0;
                    }
                }
                if (num1 > 0)
                    this.CurrentEntities.ExecuteStoreCommand(stringBuilder.ToString());
                if (list1.Count > 0)
                {
                    int num2 = 0;
                    foreach (string str in list1)
                    {
                        string CoteModuleID = str;
                        string commandText = "select sys_rolepower.*  from sys_rolepower where  sys_rolepower.CoteModuleID='" + CoteModuleID + "' and  sys_rolepower.RoleID IN ( select sys_role.RoleID  from sys_role where  sys_role.AuthorizeGroupID='" + AuthorizeGroupID + "')";
                        List<WTF.Power.Entity.sys_authorizegrouppower> list2 = this.CurrentEntities.sys_authorizegrouppower.Where<WTF.Power.Entity.sys_authorizegrouppower>((Expression<Func<WTF.Power.Entity.sys_authorizegrouppower, bool>>)(s => s.AuthorizeGroupID == AuthorizeGroupID && s.CoteModuleID == CoteModuleID)).ToList<WTF.Power.Entity.sys_authorizegrouppower>();
                        string inputString = "";
                        foreach (WTF.Power.Entity.sys_rolepower sysRolePower in this.CurrentEntities.ExecuteStoreQuery<WTF.Power.Entity.sys_rolepower>(commandText))
                        {
                            WTF.Power.Entity.sys_rolepower objSys_RolePower = sysRolePower;
                            if (!list2.Any<WTF.Power.Entity.sys_authorizegrouppower>((Func<WTF.Power.Entity.sys_authorizegrouppower, bool>)(s =>
                            {
                                if (s.CoteModuleID == objSys_RolePower.CoteModuleID && s.CoteID == objSys_RolePower.CoteID && (s.ModuleID == objSys_RolePower.ModuleID && s.IsShare == objSys_RolePower.IsShare))
                                    return s.IsCoteSupper == objSys_RolePower.IsCoteSupper;
                                return false;
                            })))
                            {
                                inputString = inputString + objSys_RolePower.RolePowerID.ToString() + ",";
                                ++num2;
                                if (num2 == 50)
                                {
                                    inputString = inputString.TrimEndComma();
                                    this.CurrentEntities.ExecuteStoreCommand("delete from sys_rolepower where RolePowerID in (" + inputString.ConvertStringID() + ")");
                                    inputString = "";
                                    num2 = 0;
                                }
                            }
                        }
                        if (num2 > 0 && StringHelper.IsNoNull(inputString))
                            this.CurrentEntities.ExecuteStoreCommand("delete from sys_rolepower where RolePowerID in (" + inputString.ConvertStringID() + ")");
                    }
                }
            }
            List<string> list = source.Where<RolePowerKey>((Func<RolePowerKey, bool>)(s => s.CoteModuleID == "")).Select<RolePowerKey, string>((Func<RolePowerKey, string>)(s => s.ModuleID)).ToList<string>();
            if (list.Count <= 0)
                return;
            int num = 0;
            foreach (string str in list)
            {
                ++num;
                stringBuilder.AppendLine(" delete from sys_rolepower where ModuleID='" + str + "' and    CoteModuleID=''   and  Sys_RolePower.Roleid in (select Roleid from  Sys_Role where  Sys_Role.AuthorizeGroupID='" + AuthorizeGroupID + "');");
                if (num == 50)
                {
                    this.CurrentEntities.ExecuteStoreCommand(stringBuilder.ToString());
                    stringBuilder.Clear();
                    num = 0;
                }
            }
            if (num <= 0)
                return;
            this.CurrentEntities.ExecuteStoreCommand(stringBuilder.ToString());
        }

        public ObjectQuery<WTF.Power.Entity.sys_modulerole> GetUserTypeRole(string UserID)
        {
            return this.CurrentEntities.sys_modulerole.Where("it.UserType like '%" + this.CurrentEntities.sys_user.First<WTF.Power.Entity.sys_user>((Expression<Func<WTF.Power.Entity.sys_user, bool>>)(s => s.UserID == UserID)).UserTypeCID.ToString() + "%'");
        }

        public IQueryable<sys_moduletype> GetUserModuleType(string UserID)
        {
            string UserTypeCID = this.CurrentEntities.sys_user.First<WTF.Power.Entity.sys_user>((Expression<Func<WTF.Power.Entity.sys_user, bool>>)(s => s.UserID == UserID)).UserTypeCID.ToString();
            return new ModuleRule().Sys_ModuleType.Where<sys_moduletype>((Expression<Func<sys_moduletype, bool>>)(s => s.UserType.Contains(UserTypeCID)));
        }

        public List<string> GetUserModuleTypeID(string UserID)
        {
            string UserTypeCID = this.CurrentEntities.sys_user.First<WTF.Power.Entity.sys_user>((Expression<Func<WTF.Power.Entity.sys_user, bool>>)(s => s.UserID == UserID)).UserTypeCID.ToString();
            return new ModuleRule().Sys_ModuleType.Where<sys_moduletype>((Expression<Func<sys_moduletype, bool>>)(s => s.UserType.Contains(UserTypeCID))).Select<sys_moduletype, string>((Expression<Func<sys_moduletype, string>>)(s => s.ModuleTypeID)).ToList<string>();
        }

        public ObjectQuery<WTF.Power.Entity.sys_role> GetUserModuleTypeRole(string UserID)
        {
            List<string> userModuleTypeId = this.GetUserModuleTypeID(UserID);
            if (userModuleTypeId.Count<string>() == 0)
                return this.CurrentEntities.sys_role.Where(o => o.ModuleTypeID=="");
            return this.CurrentEntities.sys_role.Where(o => userModuleTypeId.ConvertStringID<string>().Contains("'"+o.ModuleTypeID+"'"));
        }

        public string GetRoleModuleTypeUserType(string roleID)
        {
            return this.CurrentEntities.sys_modulerole.FirstOrDefault<WTF.Power.Entity.sys_modulerole>((Expression<Func<WTF.Power.Entity.sys_modulerole, bool>>)(s => s.RoleID == roleID)).UserType;
        }

        public ObjectQuery<WTF.Power.Entity.sys_user> GetUserTypeUser(string UserTypeCID)
        {
            return this.CurrentEntities.sys_user.Where("it.UserTypeCID in {" + UserTypeCID + "}");
        }

        public void InsertRole(WTF.Power.Entity.sys_role objRule)
        {
            objRule.UserID = this.CurrentUser.UserID.ToString();
            objRule.CreateDate = DateTime.Now;
            SysAssert.CheckIsNull(objRule.RoleName, "请输入角色名称", LogModuleType.UserLog);
            this.CurrentEntities.sys_role.Add(objRule);
            this.CurrentEntities.SaveChanges();
        }

        public void DeleteRole(string roleIDString)
        {
            foreach (object entity in (IEnumerable<WTF.Power.Entity.sys_role>)this.Sys_Role.Where("it.RoleID IN {" + roleIDString.ConvertStringID() + "}"))
                this.CurrentEntities.DeleteObject(entity);
            this.CurrentEntities.SaveChanges();
        }

        public List<string> GetRolePower(string roleID)
        {
            return this.CurrentEntities.sys_rolepower.Where<WTF.Power.Entity.sys_rolepower>((Expression<Func<WTF.Power.Entity.sys_rolepower, bool>>)(s => s.RoleID == roleID)).Select<WTF.Power.Entity.sys_rolepower, string>((Expression<Func<WTF.Power.Entity.sys_rolepower, string>>)(s => s.ModuleID)).ToList<string>();
        }

        public void UpdateRoleCote(string ModuleID, string CoteID, string RoleID, string moduleIDString)
        {
            List<string> stringList = moduleIDString.ConvertListString();
            string roleCoteID = this.CurrentEntities.sys_rolecote.First<WTF.Power.Entity.sys_rolecote>((Expression<Func<WTF.Power.Entity.sys_rolecote, bool>>)(s => s.ModuleID == ModuleID && s.RoleID == RoleID && s.CoteID == CoteID)).RoleCoteID;
            string str1 = "";
            ObjectSet<WTF.Power.Entity.sys_rolecotepower> sysRolecotepower = this.CurrentEntities.sys_rolecotepower;
            Expression<Func<WTF.Power.Entity.sys_rolecotepower, bool>> predicate = (Expression<Func<WTF.Power.Entity.sys_rolecotepower, bool>>)(s => s.RoleCoteID == roleCoteID);
            foreach (WTF.Power.Entity.sys_rolecotepower sysRoleCotePower in (IEnumerable<WTF.Power.Entity.sys_rolecotepower>)sysRolecotepower.Where<WTF.Power.Entity.sys_rolecotepower>(predicate))
            {
                if (!stringList.Contains(sysRoleCotePower.ModuleID))
                {
                    this.CurrentEntities.DeleteObject((object)sysRoleCotePower);
                    str1 = str1 + sysRoleCotePower.ModuleID + ",";
                }
                else
                    stringList.Remove(sysRoleCotePower.ModuleID);
            }
            this.CurrentEntities.SaveChanges();
            foreach (string str2 in stringList)
                this.CurrentEntities.AddTosys_rolecotepower(new WTF.Power.Entity.sys_rolecotepower()
                {
                    ModuleID = str2,
                    RoleCoteID = roleCoteID,
                    RoleCotePowerID = Guid.NewGuid().ToString()
                });
            this.CurrentEntities.SaveChanges();
            string inputString = str1.TrimEndComma();
            WTF.Power.Entity.sys_role sysRole = this.CurrentEntities.sys_role.First<WTF.Power.Entity.sys_role>((Expression<Func<WTF.Power.Entity.sys_role, bool>>)(s => s.RoleID == RoleID));
            if (!StringHelper.IsNoNull(inputString) || !sysRole.IsSystem)
                return;
            this.CurrentEntities.ExecuteStoreCommand(string.Format("delete  from Sys_RoleCotePower where \r\nSys_RoleCotePower.ModuleID in ({1}) and \r\nSys_RoleCotePower.RoleCoteID in \r\n(\r\nselect  RoleCoteID from  Sys_RoleCote,Sys_Role\r\n where Sys_RoleCote.ModuleID='{0}'\r\n AND Sys_RoleCote.CoteID='{2}' \r\n AND  Sys_RoleCote.RoleID=Sys_Role.RoleID\r\n AND Sys_Role.IsSystem=0 AND  Sys_Role.ModuleTypeID='{3}'\r\n)", (object)ModuleID, (object)inputString.ConvertStringID(), (object)CoteID, (object)sysRole.ModuleTypeID));
        }

        public void InsertRoleCote(string roleID, string moduleID, string InsertID, string rightID)
        {
            WTF.Power.Entity.sys_rolecote sys_RoleCote = new WTF.Power.Entity.sys_rolecote()
            {
                RoleID = roleID,
                CoteID = InsertID,
                ModuleID = moduleID,
                RoleCoteID = Guid.NewGuid().ToString()
            };
            this.CurrentEntities.sys_rolecote.Add(sys_RoleCote);
            if (StringHelper.IsNoNull(rightID))
            {
                IQueryable<sys_rolecoteinfo> source = this.CurrentEntities.sys_rolecoteinfo.Where<sys_rolecoteinfo>((Expression<Func<sys_rolecoteinfo, bool>>)(s => s.RoleID == roleID && s.CoteModuleID == moduleID && s.CoteID == rightID));
                Expression<Func<sys_rolecoteinfo, string>> selector = (Expression<Func<sys_rolecoteinfo, string>>)(s => s.ModuleID);
                foreach (string str in (IEnumerable<string>)source.Select<sys_rolecoteinfo, string>(selector))
                    sys_RoleCote.Sys_RoleCotePower.Add(new WTF.Power.Entity.sys_rolecotepower()
                    {
                        ModuleID = str,
                        RoleCotePowerID = Guid.NewGuid().ToString(),
                        RoleCoteID = sys_RoleCote.RoleCoteID
                    });
            }
            this.CurrentEntities.SaveChanges();
        }

        public void UpdateRoleCote(string roleID, string moduleID, List<string> coteIDString)
        {
            string str1 = "";
            ObjectSet<WTF.Power.Entity.sys_rolecote> sysRolecote = this.CurrentEntities.sys_rolecote;
            Expression<Func<WTF.Power.Entity.sys_rolecote, bool>> predicate = (Expression<Func<WTF.Power.Entity.sys_rolecote, bool>>)(s => s.RoleID == roleID && s.ModuleID == moduleID);
            foreach (WTF.Power.Entity.sys_rolecote sysRoleCote in (IEnumerable<WTF.Power.Entity.sys_rolecote>)sysRolecote.Where<WTF.Power.Entity.sys_rolecote>(predicate))
            {
                if (!coteIDString.Contains(sysRoleCote.CoteID))
                {
                    this.CurrentEntities.DeleteObject((object)sysRoleCote);
                    str1 = str1 + sysRoleCote.CoteID + ",";
                }
                else
                    coteIDString.Remove(sysRoleCote.CoteID);
            }
            this.CurrentEntities.SaveChanges();
            foreach (string str2 in coteIDString)
                this.CurrentEntities.AddTosys_rolecote(new WTF.Power.Entity.sys_rolecote()
                {
                    RoleID = roleID,
                    CoteID = str2,
                    ModuleID = moduleID,
                    RoleCoteID = Guid.NewGuid().ToString()
                });
            this.CurrentEntities.SaveChanges();
            string inputString = str1.TrimEndComma();
            WTF.Power.Entity.sys_role sysRole = this.CurrentEntities.sys_role.First<WTF.Power.Entity.sys_role>((Expression<Func<WTF.Power.Entity.sys_role, bool>>)(s => s.RoleID == roleID));
            if (!StringHelper.IsNoNull(inputString) || !sysRole.IsSystem)
                return;
            this.CurrentEntities.ExecuteStoreCommand(string.Format("DELETE FROM  Sys_RoleCote where  \r\nModuleID='{0}' and Sys_RoleCote.CoteID IN ({1}) and \r\n Sys_RoleCote.Roleid in (select Roleid from \r\n Sys_Role where Sys_Role.IsSystem=0 and\r\n Sys_Role.ModuleTypeID='{2}')", (object)moduleID, (object)inputString.ConvertStringID(), (object)sysRole.ModuleTypeID));
        }

        public string GetUserRole(string userID)
        {
            SysAssert.CheckIsNull(userID, "请输入用户标识", LogModuleType.UserLog);
            return this.CurrentEntities.sys_roleuser.Where<WTF.Power.Entity.sys_roleuser>((Expression<Func<WTF.Power.Entity.sys_roleuser, bool>>)(s => s.UserID == userID)).Select<WTF.Power.Entity.sys_roleuser, string>((Expression<Func<WTF.Power.Entity.sys_roleuser, string>>)(s => s.RoleID)).ConvertListToString<string>();
        }

        public string GetRoleUser(string roleID)
        {
            SysAssert.CheckIsNull(roleID, "请输入角色标识", LogModuleType.UserLog);
            return this.CurrentEntities.sys_roleuser.Where<WTF.Power.Entity.sys_roleuser>((Expression<Func<WTF.Power.Entity.sys_roleuser, bool>>)(p => p.RoleID == roleID)).Select<WTF.Power.Entity.sys_roleuser, string>((Expression<Func<WTF.Power.Entity.sys_roleuser, string>>)(s => s.UserID)).ConvertListToString<string>();
        }

        public string GetRoleUser(string roleID, string createUserID)
        {
            SysAssert.CheckIsNull(roleID, "请输入角色标识", LogModuleType.UserLog);
            string str1 = "";
            IQueryable<WTF.Power.Entity.sys_roleuser> source = this.CurrentEntities.sys_roleuser.Where<WTF.Power.Entity.sys_roleuser>((Expression<Func<WTF.Power.Entity.sys_roleuser, bool>>)(s => s.RoleID == roleID && s.Sys_Role.UserID == createUserID));
            Expression<Func<WTF.Power.Entity.sys_roleuser, string>> selector = (Expression<Func<WTF.Power.Entity.sys_roleuser, string>>)(s => s.UserID);
            foreach (string str2 in (IEnumerable<string>)source.Select<WTF.Power.Entity.sys_roleuser, string>(selector))
                str1 = str1 + str2.ToString() + ",";
            if (!StringHelper.IsNoNull(str1))
                return "";
            return str1.TrimEndComma();
        }

        public void SaveChanges()
        {
            this.CurrentEntities.SaveChanges();
        }

        public bool CheckIsHaveAccount(string account)
        {
            SysAssert.CheckIsNull(account, "请输入要查询的帐号", LogModuleType.UserLog);
            if (ConfigHelper.GetValue("ObligateAccount", "").ToLower().IndexOf(account.ToLower()) != -1)
                return true;
            return this.CurrentEntities.sys_user.Where<WTF.Power.Entity.sys_user>((Expression<Func<WTF.Power.Entity.sys_user, bool>>)(p => p.Account == account)).Count<WTF.Power.Entity.sys_user>() > 0;
        }

        public bool CheckIsHaveEmail(string email)
        {
            return this.CurrentEntities.sys_user.Where<WTF.Power.Entity.sys_user>((Expression<Func<WTF.Power.Entity.sys_user, bool>>)(p => p.Email == email)).Count<WTF.Power.Entity.sys_user>() > 0;
        }

        public void DeleteUser(string UserIDString)
        {
            foreach (var entity in (IEnumerable<WTF.Power.Entity.sys_user>)this.CurrentEntities.sys_user.Where(o => UserIDString.ConvertStringID().Contains("'" + o.UserID + "'")))
                this.CurrentEntities.sys_user.Remove(entity);
            this.CurrentEntities.SaveChanges();
            foreach (var entity in (IEnumerable<WTF.Power.Entity.sys_role>)this.CurrentEntities.sys_role.Where(o => UserIDString.ConvertStringID().Contains("'" + o.RefUserID + "'") && o.IsUserRole == true))
                this.CurrentEntities.sys_role.Remove(entity);
            this.CurrentEntities.SaveChanges();
        }

        public bool CheckUserAnswer(string account, string answer)
        {
            SysAssert.CheckIsNull(account, "请输入用户帐号", LogModuleType.UserLog);
            SysAssert.CheckIsNull(answer, "请输入提示问题的答案", LogModuleType.UserLog);
            answer = answer.MD5Encrypt();
            WTF.Power.Entity.sys_user sysUser = this.CurrentEntities.sys_user.First<WTF.Power.Entity.sys_user>((Expression<Func<WTF.Power.Entity.sys_user, bool>>)(p => p.Account == account));
            string passwordAnswer = sysUser.PasswordAnswer;
            if (passwordAnswer != answer)
            {
                sysUser.FaildAnswerAttemptStart = new DateTime?(DateTime.Now);
                sysUser.FaildAnswerAttemptCount = sysUser.FaildAnswerAttemptCount + 1;
                this.CurrentEntities.SaveChanges();
            }
            return passwordAnswer == answer;
        }

        public bool ReSetPassword(string userID, string newPassword)
        {
            if (StringHelper.IsNull(userID))
                SysAssert.ArgumentAssert<LogModuleType>("请选择需要修改的用户", LogModuleType.UserLog);
            if (string.IsNullOrEmpty(newPassword))
                SysAssert.ArgumentAssert<LogModuleType>("请输入新密码", LogModuleType.UserLog);
            newPassword = newPassword.MD5Encrypt();
            WTF.Power.Entity.sys_user sysUser = this.CurrentEntities.sys_user.First<WTF.Power.Entity.sys_user>((Expression<Func<WTF.Power.Entity.sys_user, bool>>)(p => p.UserID == userID));
            sysUser.Password = newPassword;
            sysUser.LastPasswordChangeDate = DateTime.Now;
            this.CurrentEntities.SaveChanges();
            return true;
        }

        public bool ReSetPasswordByAcction(string account, string newPassword)
        {
            SysAssert.CheckIsNull(account, "请输入要修改密码的用户帐号", LogModuleType.UserLog);
            SysAssert.CheckIsNull(newPassword, "请输入新密码", LogModuleType.UserLog);
            newPassword = newPassword.MD5Encrypt();
            WTF.Power.Entity.sys_user sysUser = this.CurrentEntities.sys_user.First<WTF.Power.Entity.sys_user>((Expression<Func<WTF.Power.Entity.sys_user, bool>>)(p => p.Account == account));
            sysUser.Password = newPassword;
            sysUser.LastPasswordChangeDate = DateTime.Now;
            this.CurrentEntities.SaveChanges();
            return true;
        }

        public bool ReSetPassword(string userID, string oldPassword, string newPassword)
        {
            if (userID == Guid.Empty.ToString())
                SysAssert.ArgumentAssert<LogModuleType>("请选择需要修改的用户", LogModuleType.UserLog);
            oldPassword = oldPassword.MD5Encrypt();
            if (this.CurrentEntities.sys_user.First<WTF.Power.Entity.sys_user>((Expression<Func<WTF.Power.Entity.sys_user, bool>>)(p => p.UserID == userID)).Password != oldPassword)
                SysAssert.ArgumentAssert<LogModuleType>("输入的旧密码不正确请重新输入", LogModuleType.UserLog);
            this.ReSetPassword(userID, newPassword);
            return true;
        }

        public bool SetQuestionAnswer(string userID, string question, string answer)
        {
            if (userID == Guid.Empty.ToString())
                SysAssert.ArgumentAssert<LogModuleType>("请选择需要修改的用户", LogModuleType.UserLog);
            SysAssert.CheckIsNull(question, "提示问题不为空", LogModuleType.UserLog);
            SysAssert.CheckIsNull(answer, "答案不为空", LogModuleType.UserLog);
            answer = answer.MD5Encrypt();
            WTF.Power.Entity.sys_user sysUser = this.CurrentEntities.sys_user.First<WTF.Power.Entity.sys_user>((Expression<Func<WTF.Power.Entity.sys_user, bool>>)(p => p.UserID == userID));
            sysUser.PasswordQuestion = question;
            sysUser.PasswordAnswer = answer;
            this.CurrentEntities.SaveChanges();
            return true;
        }

        public bool SetUserLock(string userIDString, bool isLockOut)
        {
            foreach (WTF.Power.Entity.sys_user sysUser in (IEnumerable<WTF.Power.Entity.sys_user>)this.CurrentEntities.sys_user.Where("it.UserID in {" + userIDString.ConvertStringID() + "}"))
            {
                sysUser.IsLockOut = isLockOut;
                sysUser.LastLockOutDate = DateTime.Now;
            }
            this.CurrentEntities.SaveChanges();
            return true;
        }

        public bool SetUserActivation(string userIDString, bool isActivation)
        {
            foreach (WTF.Power.Entity.sys_user sysUser in (IEnumerable<WTF.Power.Entity.sys_user>)this.CurrentEntities.sys_user.Where("it.UserID in {" + userIDString.ConvertStringID() + "}"))
                sysUser.IsActivation = isActivation;
            this.CurrentEntities.SaveChanges();
            return true;
        }

        public bool SetUserApprove(string[] userID, bool isApprove)
        {
            ObjectSet<WTF.Power.Entity.sys_user> sysUser1 = this.CurrentEntities.sys_user;
            Expression<Func<WTF.Power.Entity.sys_user, bool>> predicate = (Expression<Func<WTF.Power.Entity.sys_user, bool>>)(p => userID.Contains<string>(p.UserID));
            foreach (WTF.Power.Entity.sys_user sysUser2 in (IEnumerable<WTF.Power.Entity.sys_user>)sysUser1.Where<WTF.Power.Entity.sys_user>(predicate))
                sysUser2.IsApproved = isApprove;
            this.CurrentEntities.SaveChanges();
            return true;
        }

        public void UpdateRoleLock(string roleIDString, bool isLockOut)
        {
            foreach (WTF.Power.Entity.sys_role sysRole in (IEnumerable<WTF.Power.Entity.sys_role>)this.CurrentEntities.sys_role.Where("it.RoleID in {" + roleIDString.ConvertStringID() + "}"))
                sysRole.IsLockOut = isLockOut;
            this.CurrentEntities.SaveChanges();
        }

        public void UpdateAccount(string userID, string account)
        {
            SysAssert.CheckIsNull(account, "请输入帐号", LogModuleType.UserLog);
            SysAssert.CheckCondition(this.CurrentEntities.sys_user.Where<WTF.Power.Entity.sys_user>((Expression<Func<WTF.Power.Entity.sys_user, bool>>)(p => p.UserID != userID && p.Account == account)).Count<WTF.Power.Entity.sys_user>() > 0, "输入的帐号系统已经存在", LogModuleType.UserLog);
            this.CurrentEntities.sys_user.First<WTF.Power.Entity.sys_user>((Expression<Func<WTF.Power.Entity.sys_user, bool>>)(p => p.UserID == userID)).Account = account;
            this.CurrentEntities.SaveChanges();
        }

        public void UpdateSuppportUser(string nickName, string jobNo, string userName, string account, bool isApprove, string email, string userID)
        {
            SysAssert.CheckIsNull(account, "请输入帐号", LogModuleType.UserLog);
            SysAssert.CheckCondition(this.CurrentEntities.sys_user.Where<WTF.Power.Entity.sys_user>((Expression<Func<WTF.Power.Entity.sys_user, bool>>)(p => p.UserID != userID && p.Account == account)).Count<WTF.Power.Entity.sys_user>() > 0, "输入的帐号系统已经存在", LogModuleType.UserLog);
            if (!string.IsNullOrEmpty(email))
                SysAssert.CheckCondition(this.CurrentEntities.sys_user.Where<WTF.Power.Entity.sys_user>((Expression<Func<WTF.Power.Entity.sys_user, bool>>)(p => p.UserID != userID && p.Email == email.Trim())).Count<WTF.Power.Entity.sys_user>() > 0, "输入的Email系统已经存在", LogModuleType.UserLog);
            WTF.Power.Entity.sys_user sysUser = this.CurrentEntities.sys_user.First<WTF.Power.Entity.sys_user>((Expression<Func<WTF.Power.Entity.sys_user, bool>>)(p => p.UserID == userID));
            sysUser.Account = account;
            sysUser.Email = email;
            sysUser.UserName = userName;
            sysUser.IsApproved = isApprove;
            sysUser.NickName = nickName;
            sysUser.JobNo = jobNo;
            this.CurrentEntities.SaveChanges();
        }

        public void InsertRoleData(WTF.Power.Entity.sys_roledata objSys_RoleData)
        {
            this.CurrentEntities.AddTosys_roledata(objSys_RoleData);
            this.CurrentEntities.SaveChanges();
        }

        public void UpdateRoleData(WTF.Power.Entity.sys_roledata objSys_RoleData)
        {
            this.CurrentEntities.SaveChanges();
        }

        public void DeleteRoleDataByKey(string primaryKey)
        {
            this.CurrentEntities.sys_roledata.DeleteDataPrimaryKey<WTF.Power.Entity.sys_roledata>(primaryKey);
        }

        public void DeleteRoleData(string condition)
        {
            this.CurrentEntities.sys_roledata.DeleteData<WTF.Power.Entity.sys_roledata>(condition, new ObjectParameter[0]);
        }

        public void InsertUserType(WTF.Power.Entity.sys_usertype objSys_UserType)
        {
            objSys_UserType.UserTypeName.CheckIsNull<string>("请输入用户类型名称", "UserLog");
            objSys_UserType.Remark.CheckIsNull<string>("请输入备注", "UserLog");
            this.CurrentEntities.sys_usertype.Add(objSys_UserType);
            this.CurrentEntities.SaveChanges();
        }

        public void UpdateUserType(WTF.Power.Entity.sys_usertype objSys_UserType)
        {
            objSys_UserType.UserTypeName.CheckIsNull<string>("请输入用户类型名称", "UserLog");
            objSys_UserType.Remark.CheckIsNull<string>("请输入备注", "UserLog");
            this.CurrentEntities.SaveChanges();
        }

        public void DeleteUserTypeByKey(string primaryKey)
        {
            this.CurrentEntities.sys_usertype.DeleteDataPrimaryKey<WTF.Power.Entity.sys_usertype>(primaryKey);
        }

        public void DeleteUserType(string condition)
        {
            this.CurrentEntities.sys_usertype.DeleteData<WTF.Power.Entity.sys_usertype>(condition, new ObjectParameter[0]);
        }

        public LoginInfo LoginRule(string account, string password, bool isAuthenticated, bool isSetAuthCookie, List<int> objUserTypeList)
        {
            SysAssert.CheckIsNull(account, "请输入登录帐号", LogModuleType.UserLog);
            if (!isAuthenticated)
                SysAssert.CheckIsNull(password, "请输入登录密码", LogModuleType.UserLog);
            WTF.Power.Entity.sys_user objUser = this.CurrentEntities.sys_user.FirstOrDefault<WTF.Power.Entity.sys_user>((Expression<Func<WTF.Power.Entity.sys_user, bool>>)(p => p.Account == account));
            SysAssert.InfoHintAssert(objUser.IsNull(), "输入的用户帐号系统不存在");
            if (!isAuthenticated && objUser.Password != password.MD5Encrypt())
            {
                objUser.FaildPasswordAttemptCount = objUser.FaildPasswordAttemptCount;
                objUser.FaildPasswordAttemptStart = DateTime.Now;
                this.CurrentEntities.SaveChanges();
                SysAssert.InfoHintAssert("请输入正确的密码");
            }
            if (objUserTypeList != null && objUserTypeList.Count<int>() > 0)
                SysAssert.InfoHintAssert(!objUserTypeList.Contains(objUser.UserTypeCID), "输入的用户帐号系统不存在");
            if (isAuthenticated && (!objUser.IsApproved || objUser.IsLockOut || !objUser.IsActivation))
                FormsAuthentication.SignOut();
            SysAssert.InfoHintAssert(!objUser.IsApproved, "对不起你的用户帐号未审核通过");
            SysAssert.InfoHintAssert(objUser.IsLockOut, "对不起你的用户帐号已经被系统锁住");
            SysAssert.InfoHintAssert(!objUser.IsActivation, "对不起你的用户帐号未激活");
            UserInfo userInfo = new UserInfo(objUser.UserID, objUser.Account, objUser.UserName, objUser.NickName, objUser.ID, objUser.JobNo, objUser.UserTypeCID, objUser.AccountTypeID, RequestHelper.UserHostAddress, objUser.IsSuper, DateTime.Now);
            userInfo.RoleID = this.Sys_RoleUser.Where<WTF.Power.Entity.sys_roleuser>((Expression<Func<WTF.Power.Entity.sys_roleuser, bool>>)(s => s.UserID == objUser.UserID && s.Sys_Role.IsLockOut == false)).OrderBy<WTF.Power.Entity.sys_roleuser, string>((Expression<Func<WTF.Power.Entity.sys_roleuser, string>>)(S => S.RoleID)).Select<WTF.Power.Entity.sys_roleuser, string>((Expression<Func<WTF.Power.Entity.sys_roleuser, string>>)(s => s.RoleID)).ToList<string>();
            SysVariable.CurrentContext.Session["CurrentUser"] = (object)userInfo;
            SysVariable.CurrentContext.Session["SignatureID"] = (object)userInfo.UserID;
            if (!isAuthenticated)
                FormsAuthentication.SetAuthCookie(account, isSetAuthCookie);
            return new LoginInfo()
            {
                UserTypeCID = objUser.UserTypeCID,
                UserID = objUser.UserID
            };
        }

        public LoginInfo LoginRule(string account, string password, bool isSetAuthCookie, List<int> objUserTypeList)
        {
            return this.LoginRule(account, password, false, isSetAuthCookie, objUserTypeList);
        }

        public LoginInfo LoginRule(string account)
        {
            return this.LoginRule(account, "", true, false, (List<int>)null);
        }

        public void SystemExitRule()
        {
            FormsAuthentication.SignOut();
            SysVariable.CurrentContext.Session.Clear();
        }

        public UserInfo GetCurrentUser(string ModuleTypeID)
        {
            if (SysVariable.CurrentContext.Request.IsAuthenticated)
            {
                if (SysVariable.CurrentContext != null && SysVariable.CurrentContext.Session["CurrentUser"] == null)
                {
                    this.LoginRule(SysVariable.CurrentContext.User.Identity.Name);
                    return (UserInfo)SysVariable.CurrentContext.Session["CurrentUser"];
                }
                if (SysVariable.CurrentContext != null && SysVariable.CurrentContext.Session["CurrentUser"] != null)
                {
                    if (((UserInfo)SysVariable.CurrentContext.Session["CurrentUser"]).Account == SysVariable.CurrentContext.User.Identity.Name)
                        return (UserInfo)SysVariable.CurrentContext.Session["CurrentUser"];
                    SysVariable.CurrentContext.Session.Clear();
                    this.LoginRule(SysVariable.CurrentContext.User.Identity.Name);
                    return (UserInfo)SysVariable.CurrentContext.Session["CurrentUser"];
                }
            }
            UserInfo userInfo1 = new UserInfo();
            if (SysVariable.CurrentContext.Session["CurrentUser"] != null)
            {
                UserInfo userInfo2 = (UserInfo)SysVariable.CurrentContext.Session["CurrentUser"];
                if (userInfo2.UserID == Guid.Empty.ToString())
                    return userInfo2;
            }
            UserInfo userInfo3 = new UserInfo(Guid.Empty.ToString(), "Anonymous", "旅客", "旅客", 0, "", -1, "", RequestHelper.UserHostAddress, false, DateTime.Now);
            string GuidEmpty = Guid.Empty.ToString();
            userInfo3.RoleID = this.Sys_RoleUser.Where<WTF.Power.Entity.sys_roleuser>((Expression<Func<WTF.Power.Entity.sys_roleuser, bool>>)(s => s.UserID == GuidEmpty && s.Sys_Role.IsLockOut == false && s.Sys_Role.ModuleTypeID == ModuleTypeID)).OrderBy<WTF.Power.Entity.sys_roleuser, string>((Expression<Func<WTF.Power.Entity.sys_roleuser, string>>)(S => S.RoleID)).Select<WTF.Power.Entity.sys_roleuser, string>((Expression<Func<WTF.Power.Entity.sys_roleuser, string>>)(s => s.RoleID)).ToList<string>();
            SysVariable.CurrentContext.Session["CurrentUser"] = (object)userInfo3;
            return userInfo3;
        }

        private string InsertUser(int userTypeCID, string accountTypeID, bool isSuper, string nickName, string jobNo, string userName, string account, string password, string email, string passwordQuestion, string passwordAnswer, bool isApproved, bool isActivation, bool isAdmin = false)
        {
            account = account.Trim();
            password = password.Trim();
            SysAssert.CheckIsNull(account, "请输入用户帐号", LogModuleType.UserLog);
            SysAssert.CheckIsNull(password, "请输入用户密码", LogModuleType.UserLog);
            SysAssert.CheckIsNull(accountTypeID, "请输入帐户归属", LogModuleType.UserLog);
            SysAssert.InfoHintAssert(this.CheckIsHaveAccount(account), "输入的帐号系统已经存在");
            if (!StringHelper.IsNull(email))
                SysAssert.InfoHintAssert(this.CheckIsHaveEmail(email), "输入的Email系统已经存在");
            if (!string.IsNullOrEmpty(passwordQuestion))
            {
                SysAssert.CheckCondition(string.IsNullOrEmpty(passwordAnswer), "请输入提示答案", LogModuleType.UserLog);
                passwordAnswer = passwordAnswer.MD5Encrypt();
            }
            string userHostAddress = RequestHelper.UserHostAddress;
            Guid.NewGuid();
            password = password.MD5Encrypt();
            WTF.Power.Entity.sys_user sys_User = new WTF.Power.Entity.sys_user();
            sys_User.UserID = Guid.NewGuid().ToString();
            sys_User.UserTypeCID = userTypeCID;
            sys_User.IsSuper = isSuper;
            sys_User.AccountTypeID = accountTypeID;
            sys_User.Account = account;
            sys_User.Password = password;
            sys_User.Email = email;
            sys_User.LoginIP = userHostAddress;
            sys_User.PasswordQuestion = passwordQuestion;
            sys_User.PasswordAnswer = passwordAnswer;
            sys_User.IsApproved = isApproved;
            sys_User.IsActivation = isActivation;
            sys_User.IsAdmin = isAdmin;
            sys_User.UserName = userName;
            sys_User.JobNo = jobNo;
            sys_User.NickName = nickName;
            if (sys_User.IsApproved)
                sys_User.ApprovedDate = new DateTime?(DateTime.Now);
            if (sys_User.IsActivation)
                sys_User.ActivationDate = new DateTime?(DateTime.Now);
            sys_User.IsLockOut = false;
            sys_User.CreateDate = DateTime.Now;
            sys_User.FaildAnswerAttemptCount = 0;
            sys_User.FaildPasswordAttemptStart = "1753-01-01".ConvertDateTime();
            sys_User.LastPasswordChangeDate = "1753-01-01".ConvertDateTime();
            sys_User.LastLockOutDate = "1753-01-01".ConvertDateTime();
            sys_User.FaildAnswerAttemptStart = new DateTime?("1753-01-01".ConvertDateTime());
            sys_User.FaildPasswordAttemptCount = 0;
            this.CurrentEntities.AddTosys_user(sys_User);
            this.CurrentEntities.SaveChanges();
            return sys_User.UserID;
        }

        public string InsertClientUser(int userTypeCID, string accountTypeID, string nickName, string jobNo, string userName, string account, string password, string email, string passwordQuestion, string passwordAnswer, bool isApproved, bool isActivation, bool isAdmin = false)
        {
            return this.InsertUser(userTypeCID, accountTypeID, false, nickName, jobNo, userName, account, password, email, passwordQuestion, passwordQuestion, isApproved, isActivation, isAdmin);
        }

        public string InsertUser(int userTypeCID, string accountTypeID, bool isSuper, string nickName, string jobNo, string userName, string account, string password, string email, bool isAdmin = false)
        {
            return this.InsertUser(userTypeCID, accountTypeID, isSuper, nickName, jobNo, userName, account, password, email, "", "", true, true, isAdmin);
        }

        private string ValueFormant(string value, int FileDataType)
        {
            if (FileDataType != 1)
            {
                if (FileDataType == 2)
                    value = value.ConvertStringID();
                else if (FileDataType != 3 && FileDataType == 4)
                    value = value.ConvertGuidID();
            }
            return value;
        }

        private string ValueDefaultFormant(int FileDataType)
        {
            if (FileDataType == 1)
                return int.MinValue.ToString();
            if (FileDataType == 2)
                return "'" + Guid.NewGuid().ToString() + "'";
            if (FileDataType == 3)
                return "False";
            if (FileDataType == 4)
                return "Guid'" + Guid.NewGuid().ToString() + "'";
            return "";
        }

        public string CheckPowerDataCondition(string moduleTypeID, string pageName, string userID)
        {
            List<sys_moduledata> checkPageModuleData = new ModuleRule().GetCheckPageModuleData(moduleTypeID, pageName);
            if (checkPageModuleData.Count == 0)
                return "";
            Dictionary<string, string> dictionary = new Dictionary<string, string>();
            foreach (sys_moduledata sysModuleData in checkPageModuleData)
            {
                if (!dictionary.ContainsKey(sysModuleData.FieldName))
                    dictionary.Add(sysModuleData.FieldName, this.ValueDefaultFormant(sysModuleData.FieldType));
            }
            List<sys_roledata_info> list = this.CurrentEntities.GetPowerDataModule(moduleTypeID, pageName, userID).ToList<sys_roledata_info>();
            if (list.Count > 0)
            {
                foreach (sys_roledata_info sysRoleDataInfo in list)
                    dictionary.Remove(sysRoleDataInfo.FieldName);
                foreach (sys_roledata_info sysRoleDataInfo in list)
                {
                    if (dictionary.ContainsKey(sysRoleDataInfo.FieldName))
                        dictionary[sysRoleDataInfo.FieldName] = dictionary[sysRoleDataInfo.FieldName] + "," + this.ValueFormant(sysRoleDataInfo.DataSelect, sysRoleDataInfo.FieldType);
                    else
                        dictionary.Add(sysRoleDataInfo.FieldName, this.ValueFormant(sysRoleDataInfo.DataSelect, sysRoleDataInfo.FieldType));
                }
            }
            string str = "";
            foreach (string key in dictionary.Keys)
                str = str + "and it." + key + " in {" + dictionary[key] + "} ";
            return str.Substring(3);
        }

        public string CheckPowerFieldData(string moduleTypeID, string pageName, string fieldNameSource, string fieldName, string userID)
        {
            List<Sys_ModuleData> pageFieldModuleData = new ModuleRule().GetCheckPageFieldModuleData(moduleTypeID, pageName, fieldName);
            if (pageFieldModuleData.Count == 0)
                return "";
            Dictionary<string, string> dictionary = new Dictionary<string, string>();
            foreach (Sys_ModuleData sysModuleData in pageFieldModuleData)
            {
                if (!dictionary.ContainsKey(sysModuleData.FieldName))
                    dictionary.Add(sysModuleData.FieldName, this.ValueDefaultFormant(sysModuleData.FieldType));
            }
            List<sys_roledata_info> list = this.CurrentEntities.GetPowerDataModule(moduleTypeID, pageName, userID).ToList<sys_roledata_info>().Where<sys_roledata_info>((Func<Sys_RoleData_Info, bool>)(s => s.FieldName == fieldName)).ToList<sys_roledata_info>();
            if (list.Count > 0)
            {
                foreach (sys_roledata_info sysRoleDataInfo in list)
                    dictionary.Remove(sysRoleDataInfo.FieldName);
                foreach (sys_roledata_info sysRoleDataInfo in list)
                {
                    if (dictionary.ContainsKey(sysRoleDataInfo.FieldName))
                        dictionary[sysRoleDataInfo.FieldName] = dictionary[sysRoleDataInfo.FieldName] + "," + this.ValueFormant(sysRoleDataInfo.DataSelect, sysRoleDataInfo.FieldType);
                    else
                        dictionary.Add(sysRoleDataInfo.FieldName, this.ValueFormant(sysRoleDataInfo.DataSelect, sysRoleDataInfo.FieldType));
                }
            }
            string str = "";
            foreach (string key in dictionary.Keys)
                str = str + "and it." + fieldNameSource + " in {" + dictionary[key] + "} ";
            return str.Substring(3);
        }

        public bool CheckPowerFrame(string moduleTypeID, string UserID)
        {
            return this.CurrentEntities.CheckPowerFrameByID(UserID, moduleTypeID).First<int?>().Value > 0;
        }

        public bool CheckPowerPage(string moduleTypeID, string pageName, string userID)
        {
            return this.CurrentEntities.CheckPowerPageByID(userID, pageName, moduleTypeID).First<int?>().Value > 0;
        }

        public bool CheckPowerPage(string moduleTypeID, string coteModuleID, string coteID, string pageName, string userID)
        {
            return this.CurrentEntities.CheckPowerCotePageByID(userID, coteModuleID, coteID, pageName, moduleTypeID).First<int?>().Value > 0;
        }

        public bool CheckControllerAction(string moduleCodeType, string controllerName, string actionName)
        {
            if (this.CurrentUser.IsSuper)
                return true;
            ModuleRule moduleRule = new ModuleRule();
            return false;
        }

        public List<string> GetCoteOperateModule(string userID, string voteID, string moduleID)
        {
            return this.CurrentEntities.ExecuteStoreQuery<string>(string.Format("SELECT  Sys_RoleCotePower.ModuleID\r\n  FROM  Sys_RoleUser \r\n , Sys_RoleCote,Sys_RoleCotePower WHERE Sys_RoleUser.UserID='{0}' and  Sys_RoleUser.RoleID=Sys_RoleCote.RoleID\r\n AND Sys_RoleCote.ModuleID='{1}' and   Sys_RoleCote.CoteID='{2}' AND Sys_RoleCote.RoleCoteID=Sys_RoleCotePower.RoleCoteID", (object)userID, (object)moduleID, (object)voteID)).ToList<string>();
        }

        public List<RolePowerKey> GetRoleKeyPower(string roleID)
        {
            return this.CurrentEntities.sys_rolepower.Where<WTF.Power.Entity.sys_rolepower>((Expression<Func<WTF.Power.Entity.sys_rolepower, bool>>)(s => s.RoleID == roleID)).Select<WTF.Power.Entity.sys_rolepower, RolePowerKey>((Expression<Func<WTF.Power.Entity.sys_rolepower, RolePowerKey>>)(s => new RolePowerKey()
            {
                CoteID = s.CoteID,
                CoteModuleID = s.CoteModuleID,
                ModuleID = s.ModuleID,
                IsShare = s.IsShare,
                IsCoteSupper = s.IsCoteSupper
            })).Distinct<RolePowerKey>().ToList<RolePowerKey>();
        }

        public void UpdateRolePower(string roleID, List<RolePowerKey> objRolePowerKeyList)
        {
            foreach (string str in objRolePowerKeyList.Where<RolePowerKey>((Func<RolePowerKey, bool>)(s =>
            {
                if (s.CoteModuleID != "")
                    return !s.IsShare;
                return false;
            })).Select<RolePowerKey, string>((Func<RolePowerKey, string>)(s => s.CoteModuleID)).Distinct<string>().ToList<string>())
            {
                string coteModuleID = str;
                if (!objRolePowerKeyList.Any<RolePowerKey>((Func<RolePowerKey, bool>)(s =>
                {
                    if (s.ModuleID == coteModuleID)
                        return s.CoteModuleID == "";
                    return false;
                })))
                    objRolePowerKeyList.Add(RolePowerKey.Create(coteModuleID));
            }
            List<RolePowerKey> rolePowerKeyList = new List<RolePowerKey>();
            ObjectSet<WTF.Power.Entity.sys_rolepower> sysRolepower = this.CurrentEntities.sys_rolepower;
            Expression<Func<WTF.Power.Entity.sys_rolepower, bool>> predicate = (Expression<Func<WTF.Power.Entity.sys_rolepower, bool>>)(s => s.RoleID == roleID);
            foreach (WTF.Power.Entity.sys_rolepower sysRolePower in (IEnumerable<WTF.Power.Entity.sys_rolepower>)sysRolepower.Where<WTF.Power.Entity.sys_rolepower>(predicate))
            {
                WTF.Power.Entity.sys_rolepower objRolePower = sysRolePower;
                RolePowerKey rolePowerKey = objRolePowerKeyList.FirstOrDefault<RolePowerKey>((Func<RolePowerKey, bool>)(s =>
                {
                    if (s.ModuleID == objRolePower.ModuleID && s.CoteModuleID == objRolePower.CoteModuleID && (s.CoteID == objRolePower.CoteID && s.IsShare == objRolePower.IsShare))
                        return s.IsCoteSupper == objRolePower.IsCoteSupper;
                    return false;
                }));
                if (rolePowerKey != null)
                {
                    objRolePowerKeyList.Remove(rolePowerKey);
                }
                else
                {
                    this.CurrentEntities.DeleteObject((object)objRolePower);
                    rolePowerKeyList.Add(RolePowerKey.Create(objRolePower.CoteModuleID, objRolePower.CoteID, objRolePower.ModuleID, objRolePower.IsShare, objRolePower.IsCoteSupper));
                }
            }
            this.CurrentEntities.SaveChanges();
            this.CurrentEntities.sys_role.First<WTF.Power.Entity.sys_role>((Expression<Func<WTF.Power.Entity.sys_role, bool>>)(s => s.RoleID == roleID));
            foreach (RolePowerKey objRolePowerKey in objRolePowerKeyList)
                this.CurrentEntities.AddTosys_rolepower(new WTF.Power.Entity.sys_rolepower()
                {
                    RoleID = roleID,
                    ModuleID = objRolePowerKey.ModuleID,
                    CoteID = objRolePowerKey.CoteID,
                    CoteModuleID = objRolePowerKey.CoteModuleID,
                    IsShare = objRolePowerKey.IsShare,
                    IsCoteSupper = objRolePowerKey.IsCoteSupper,
                    RolePowerID = Guid.NewGuid().ToString()
                });
            this.CurrentEntities.SaveChanges();
        }

        public void RemoveRoleUser(string roleID, string userIDString)
        {
            if (!StringHelper.IsNoNull(userIDString))
                return;
            foreach (object entity in (IEnumerable<WTF.Power.Entity.sys_roleuser>)this.CurrentEntities.sys_roleuser.Where(" it.RoleID=='" + roleID.ToString() + "' AND  it.UserID in{" + userIDString.ConvertStringID() + "}"))
                this.CurrentEntities.DeleteObject(entity);
            this.CurrentEntities.SaveChanges();
        }

        public void UpdateRoleUser(string roleID, string userIDString)
        {
            List<string> stringList = userIDString.ConvertListString();
            ObjectSet<WTF.Power.Entity.sys_roleuser> sysRoleuser = this.CurrentEntities.sys_roleuser;
            Expression<Func<WTF.Power.Entity.sys_roleuser, bool>> predicate = (Expression<Func<WTF.Power.Entity.sys_roleuser, bool>>)(s => s.RoleID == roleID);
            foreach (WTF.Power.Entity.sys_roleuser sysRoleUser in (IEnumerable<WTF.Power.Entity.sys_roleuser>)sysRoleuser.Where<WTF.Power.Entity.sys_roleuser>(predicate))
            {
                if (stringList.Contains(sysRoleUser.UserID))
                    stringList.Remove(sysRoleUser.UserID);
                else
                    this.CurrentEntities.DeleteObject((object)sysRoleUser);
            }
            this.CurrentEntities.SaveChanges();
            if (stringList.Count <= 0)
                return;
            foreach (string str in stringList)
                this.CurrentEntities.AddTosys_roleuser(new WTF.Power.Entity.sys_roleuser()
                {
                    UserID = str,
                    RoleID = roleID,
                    RoleUserID = Guid.NewGuid().ToString()
                });
            this.CurrentEntities.SaveChanges();
        }

        public void UpdateRoleUser(string roleID, string userIDString, string userIDNoString)
        {
            List<string> stringList1 = userIDString.ConvertListString();
            List<string> stringList2 = userIDNoString.ConvertListString();
            ObjectSet<WTF.Power.Entity.sys_roleuser> sysRoleuser = this.CurrentEntities.sys_roleuser;
            Expression<Func<WTF.Power.Entity.sys_roleuser, bool>> predicate = (Expression<Func<WTF.Power.Entity.sys_roleuser, bool>>)(s => s.RoleID == roleID);
            foreach (WTF.Power.Entity.sys_roleuser sysRoleUser in (IEnumerable<WTF.Power.Entity.sys_roleuser>)sysRoleuser.Where<WTF.Power.Entity.sys_roleuser>(predicate))
            {
                if (stringList1.Contains(sysRoleUser.UserID))
                    stringList1.Remove(sysRoleUser.UserID);
                else if (stringList2.Contains(sysRoleUser.UserID))
                    this.CurrentEntities.DeleteObject((object)sysRoleUser);
            }
            this.CurrentEntities.SaveChanges();
            if (stringList1.Count <= 0)
                return;
            foreach (string str in stringList1)
                this.CurrentEntities.AddTosys_roleuser(new WTF.Power.Entity.sys_roleuser()
                {
                    UserID = str,
                    RoleID = roleID,
                    RoleUserID = Guid.NewGuid().ToString()
                });
            this.CurrentEntities.SaveChanges();
        }

        public void AddRoleUser(string roleID, string userIDString)
        {
            if (!StringHelper.IsNoNull(userIDString))
                return;
            List<string> stringList = userIDString.ConvertListString();
            foreach (WTF.Power.Entity.sys_roleuser sysRoleUser in (IEnumerable<WTF.Power.Entity.sys_roleuser>)this.CurrentEntities.sys_roleuser.Where(" it.RoleID=='" + roleID.ToString() + "' AND  it.UserID in{" + userIDString.ConvertStringID() + "}"))
                stringList.Remove(sysRoleUser.UserID);
            if (stringList.Count <= 0)
                return;
            foreach (string str in stringList)
                this.CurrentEntities.sys_roleuser.Add(new WTF.Power.Entity.sys_roleuser()
              {
                  RoleID = roleID,
                  UserID = str,
                  RoleUserID = Guid.NewGuid().ToString()
              });
            this.CurrentEntities.SaveChanges();
        }

        public List<RolePowerKey> GetUserKeyPower(string userid, string ModuleTypeID, string AuthorizeGroupID)
        {
            WTF.Power.Entity.sys_role objSys_Role = this.CurrentEntities.sys_role.FirstOrDefault<WTF.Power.Entity.sys_role>((Expression<Func<WTF.Power.Entity.sys_role, bool>>)(s => s.RefUserID == userid && s.ModuleTypeID == ModuleTypeID && s.AuthorizeGroupID == AuthorizeGroupID && s.IsUserRole == true));
            if (objSys_Role == null)
                return new List<RolePowerKey>();
            return this.CurrentEntities.sys_rolepower.Where<WTF.Power.Entity.sys_rolepower>((Expression<Func<WTF.Power.Entity.sys_rolepower, bool>>)(s => s.RoleID == objSys_Role.RoleID)).Select<WTF.Power.Entity.sys_rolepower, RolePowerKey>((Expression<Func<WTF.Power.Entity.sys_rolepower, RolePowerKey>>)(s => new RolePowerKey()
            {
                CoteID = s.CoteID,
                CoteModuleID = s.CoteModuleID,
                ModuleID = s.ModuleID,
                IsShare = s.IsShare,
                IsCoteSupper = s.IsCoteSupper
            })).ToList<RolePowerKey>();
        }

        public List<RolePowerKey> GetUserAllKeyPower(string userid)
        {
            List<string> userRoleList = this.CurrentEntities.sys_roleuser.Where<WTF.Power.Entity.sys_roleuser>((Expression<Func<WTF.Power.Entity.sys_roleuser, bool>>)(s => s.UserID == userid)).Select<WTF.Power.Entity.sys_roleuser, string>((Expression<Func<WTF.Power.Entity.sys_roleuser, string>>)(s => s.RoleID)).ToList<string>();
            if (userRoleList.Count == 0)
                return new List<RolePowerKey>();
            return this.CurrentEntities.sys_rolepower.Where<WTF.Power.Entity.sys_rolepower>((Expression<Func<WTF.Power.Entity.sys_rolepower, bool>>)(s => userRoleList.Contains(s.RoleID))).Select<WTF.Power.Entity.sys_rolepower, RolePowerKey>((Expression<Func<WTF.Power.Entity.sys_rolepower, RolePowerKey>>)(s => new RolePowerKey()
            {
                CoteID = s.CoteID,
                CoteModuleID = s.CoteModuleID,
                ModuleID = s.ModuleID,
                IsShare = s.IsShare,
                IsCoteSupper = s.IsCoteSupper
            })).ToList<RolePowerKey>();
        }

        public void RevertUserPower(string userID, string AuthorizeGroupIDString)
        {
            string commandText;
            if (string.IsNullOrWhiteSpace(AuthorizeGroupIDString))
                commandText = " delete from sys_roleuser where  UserID='" + userID + "'; delete from sys_role where IsUserRole=1 and  RefUserID='" + userID + "';";
            else
                commandText = " delete from sys_roleuser where  sys_roleuser.UserID='" + userID + "' and  sys_roleuser.RoleID in (select sys_role.RoleID from  sys_role  where sys_role.AuthorizeGroupID in (" + AuthorizeGroupIDString.ConvertStringID() + ") ); delete from sys_role where IsUserRole=1 and AuthorizeGroupID in (" + AuthorizeGroupIDString.ConvertStringID() + ") and  RefUserID='" + userID + "';";
            this.CurrentEntities.ExecuteStoreCommand(commandText);
        }

        public WTF.Power.Entity.sys_role GetUserSelfAuthorizeGroupRole(string AuthorizeGroupID, string UserID, string ModuleTypeID)
        {
            WTF.Power.Entity.sys_role objRule = this.Sys_Role.FirstOrDefault<WTF.Power.Entity.sys_role>((Expression<Func<WTF.Power.Entity.sys_role, bool>>)(s => s.AuthorizeGroupID == AuthorizeGroupID && s.ModuleTypeID == ModuleTypeID && s.RefUserID == UserID && s.IsUserRole == true));
            if (objRule == null)
            {
                WTF.Power.Entity.sys_user sysUser = this.Sys_User.FirstOrDefault<WTF.Power.Entity.sys_user>((Expression<Func<WTF.Power.Entity.sys_user, bool>>)(s => s.UserID == UserID));
                if (sysUser == null)
                    SysAssert.InfoHintAssert("对不起，找不到此用户");
                string str = "平台虚拟组权限";
                bool flag;
                if (AuthorizeGroupID != Guid.Empty.ToString())
                {
                    WTF.Power.Entity.sys_authorizegroup sysAuthorizegroup = this.sys_authorizegroup.FirstOrDefault<WTF.Power.Entity.sys_authorizegroup>((Expression<Func<WTF.Power.Entity.sys_authorizegroup, bool>>)(s => s.AuthorizeGroupID == AuthorizeGroupID));
                    if (sysAuthorizegroup == null)
                        SysAssert.InfoHintAssert("对不起，找不到此授权组");
                    flag = false;
                    str = sysAuthorizegroup.AuthorizeGroupName;
                }
                else
                    flag = true;
                if (this.CurrentUser.UserTypeCID == -1)
                    SysAssert.InfoHintAssert("对不起，你未登录无法设置");
                objRule = new WTF.Power.Entity.sys_role();
                objRule.RoleID = Guid.NewGuid().ToString();
                objRule.AuthorizeGroupID = AuthorizeGroupID;
                objRule.RefUserID = UserID;
                objRule.IsUserRole = true;
                objRule.UserID = this.CurrentUser.UserID;
                objRule.RoleName = (sysUser.Account + "|角色私有").CutWord(20);
                objRule.RoleCode = objRule.RoleName.ConvertChineseSpell(false, ' ');
                objRule.Remark = (sysUser.Account + "|" + str).CutWord(90);
                objRule.IsLockOut = false;
                objRule.ModuleTypeID = ModuleTypeID;
                objRule.RoleGroupID = "";
                objRule.IsSystem = flag;
                objRule.AccountTypeID = this.CurrentUser.AccountTypeID;
                this.InsertRole(objRule);
                this.AddRoleUser(objRule.RoleID, UserID);
            }
            return objRule;
        }

        public void UpdateUserRole(string userID, string roleIDString)
        {
            List<string> stringList = roleIDString.ConvertListString();
            ObjectSet<WTF.Power.Entity.sys_roleuser> sysRoleuser = this.CurrentEntities.sys_roleuser;
            Expression<Func<WTF.Power.Entity.sys_roleuser, bool>> predicate = (Expression<Func<WTF.Power.Entity.sys_roleuser, bool>>)(s => s.UserID == userID);
            foreach (WTF.Power.Entity.sys_roleuser sysRoleUser in (IEnumerable<WTF.Power.Entity.sys_roleuser>)sysRoleuser.Where<WTF.Power.Entity.sys_roleuser>(predicate))
            {
                if (stringList.Contains(sysRoleUser.RoleID))
                    stringList.Remove(sysRoleUser.RoleID);
                else
                    this.CurrentEntities.DeleteObject((object)sysRoleUser);
            }
            this.CurrentEntities.SaveChanges();
            if (stringList.Count <= 0)
                return;
            foreach (string str in stringList)
                this.CurrentEntities.AddTosys_roleuser(new WTF.Power.Entity.sys_roleuser()
                {
                    UserID = userID,
                    RoleID = str,
                    RoleUserID = Guid.NewGuid().ToString()
                });
            this.CurrentEntities.SaveChanges();
        }

        public void CopyUserPower(string SourceuserID, string targetUserID, string AuthorizeGroupID)
        {
            List<string> copyRoleIDList = this.Sys_RoleUser.Where<WTF.Power.Entity.sys_roleuser>((Expression<Func<WTF.Power.Entity.sys_roleuser, bool>>)(s => s.UserID == targetUserID)).Select<WTF.Power.Entity.sys_roleuser, string>((Expression<Func<WTF.Power.Entity.sys_roleuser, string>>)(s => s.RoleID)).ToList<string>();
            IQueryable<WTF.Power.Entity.sys_role> source = this.Sys_Role.Where<WTF.Power.Entity.sys_role>((Expression<Func<WTF.Power.Entity.sys_role, bool>>)(s => copyRoleIDList.Contains(s.RoleID)));
            if (!string.IsNullOrWhiteSpace(AuthorizeGroupID))
                source = source.Where<WTF.Power.Entity.sys_role>((Expression<Func<WTF.Power.Entity.sys_role, bool>>)(s => s.AuthorizeGroupID == AuthorizeGroupID));
            List<WTF.Power.Entity.sys_role> list1 = source.ToList<WTF.Power.Entity.sys_role>();
            this.UpdateUserRole(SourceuserID, list1.Where<WTF.Power.Entity.sys_role>((Func<WTF.Power.Entity.sys_role, bool>)(s =>
            {
                if (!s.IsUserRole)
                    return !s.IsSystem;
                return false;
            })).Select<WTF.Power.Entity.sys_role, string>((Func<WTF.Power.Entity.sys_role, string>)(s => s.RoleID)).ToList<string>().ConvertListToString<string>(), "");
            foreach (WTF.Power.Entity.sys_role sysRole in list1.Where<WTF.Power.Entity.sys_role>((Func<WTF.Power.Entity.sys_role, bool>)(s =>
            {
                if (s.IsUserRole && s.AuthorizeGroupID != Guid.Empty.ToString())
                    return !s.IsSystem;
                return false;
            })))
            {
                WTF.Power.Entity.sys_role objSys_Role = sysRole;
                WTF.Power.Entity.sys_role objSelfRole = this.GetUserSelfAuthorizeGroupRole(objSys_Role.AuthorizeGroupID, SourceuserID, objSys_Role.ModuleTypeID);
                List<WTF.Power.Entity.sys_rolepower> list2 = this.Sys_RolePower.Where<WTF.Power.Entity.sys_rolepower>((Expression<Func<WTF.Power.Entity.sys_rolepower, bool>>)(s => s.RoleID == objSelfRole.RoleID)).ToList<WTF.Power.Entity.sys_rolepower>();
                ObjectQuery<WTF.Power.Entity.sys_rolepower> sysRolePower1 = this.Sys_RolePower;
                Expression<Func<WTF.Power.Entity.sys_rolepower, bool>> predicate = (Expression<Func<WTF.Power.Entity.sys_rolepower, bool>>)(s => s.RoleID == objSys_Role.RoleID);
                foreach (WTF.Power.Entity.sys_rolepower sysRolePower2 in (IEnumerable<WTF.Power.Entity.sys_rolepower>)sysRolePower1.Where<WTF.Power.Entity.sys_rolepower>(predicate))
                {
                    WTF.Power.Entity.sys_rolepower copyPower = sysRolePower2;
                    if (!list2.Any<WTF.Power.Entity.sys_rolepower>((Func<WTF.Power.Entity.sys_rolepower, bool>)(s =>
                    {
                        if (s.ModuleID == copyPower.ModuleID && s.CoteID == copyPower.CoteID && (s.CoteModuleID == copyPower.CoteModuleID && s.IsShare == copyPower.IsShare))
                            return s.IsCoteSupper == copyPower.IsCoteSupper;
                        return false;
                    })))
                        this.CurrentEntities.AddTosys_rolepower(new WTF.Power.Entity.sys_rolepower()
                        {
                            RolePowerID = Guid.NewGuid().ToString(),
                            IsShare = copyPower.IsShare,
                            CoteModuleID = copyPower.CoteModuleID,
                            CoteID = copyPower.CoteID,
                            ModuleID = copyPower.ModuleID,
                            IsCoteSupper = copyPower.IsCoteSupper,
                            RoleID = objSelfRole.RoleID
                        });
                }
            }
            this.CurrentEntities.SaveChanges();
        }

        public void UpdateUserRole(string userID, string roleIDString, string roleIDNoString)
        {
            List<string> stringList1 = roleIDString.ConvertListString();
            List<string> stringList2 = roleIDNoString.ConvertListString();
            ObjectSet<WTF.Power.Entity.sys_roleuser> sysRoleuser = this.CurrentEntities.sys_roleuser;
            Expression<Func<WTF.Power.Entity.sys_roleuser, bool>> predicate = (Expression<Func<WTF.Power.Entity.sys_roleuser, bool>>)(s => s.UserID == userID);
            foreach (WTF.Power.Entity.sys_roleuser sysRoleUser in (IEnumerable<WTF.Power.Entity.sys_roleuser>)sysRoleuser.Where<WTF.Power.Entity.sys_roleuser>(predicate))
            {
                if (stringList1.Contains(sysRoleUser.RoleID))
                    stringList1.Remove(sysRoleUser.RoleID);
                else if (stringList2.Contains(sysRoleUser.RoleID))
                    this.CurrentEntities.DeleteObject((object)sysRoleUser);
            }
            this.CurrentEntities.SaveChanges();
            if (stringList1.Count <= 0)
                return;
            foreach (string str in stringList1)
                this.CurrentEntities.AddTosys_roleuser(new WTF.Power.Entity.sys_roleuser()
                {
                    UserID = userID,
                    RoleID = str,
                    RoleUserID = Guid.NewGuid().ToString()
                });
            this.CurrentEntities.SaveChanges();
        }

        public void AddUserRole(string userID, string roleIDString)
        {
            if (!StringHelper.IsNoNull(roleIDString))
                return;
            List<string> stringList = roleIDString.ConvertListString();
            foreach (WTF.Power.Entity.sys_roleuser sysRoleUser in (IEnumerable<WTF.Power.Entity.sys_roleuser>)this.CurrentEntities.sys_roleuser.Where(" it.UserID =='" + userID.ToString() + "' AND it.RoleID in{" + roleIDString.ConvertStringID() + "}"))
                stringList.Remove(sysRoleUser.RoleID);
            if (stringList.Count <= 0)
                return;
            foreach (string str in stringList)
                this.CurrentEntities.AddTosys_roleuser(new WTF.Power.Entity.sys_roleuser()
                {
                    RoleID = str,
                    UserID = userID,
                    RoleUserID = Guid.NewGuid().ToString()
                });
            this.CurrentEntities.SaveChanges();
        }

        public void RemoveUserRole(string userID, string roleIDString)
        {
            if (!StringHelper.IsNoNull(roleIDString))
                return;
            foreach (object entity in (IEnumerable<WTF.Power.Entity.sys_roleuser>)this.CurrentEntities.sys_roleuser.Where(" it.UserID =='" + userID.ToString() + "' AND it.RoleID in{" + roleIDString.ConvertStringID() + "}"))
                this.CurrentEntities.DeleteObject(entity);
            this.CurrentEntities.SaveChanges();
        }
    }
}
